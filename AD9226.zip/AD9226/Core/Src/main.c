/* USER CODE BEGIN Header */
/**
  * @file    main.c
  * @brief   STM32F407ZGT6 + AD9226 并行ADC采集
  *          TIM8触发DMA读取GPIOD->IDR，VOFA+ FireWater协议输出
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
#define ADC_SAMPLE_LEN    1024       // 采样缓冲区长度
#define ADC_DATA_MASK     0x0FFF     // 12位掩码
#define ADC_VREF          5.0f       // 参考电压，根据实际电路修改

uint16_t adc_buffer[ADC_SAMPLE_LEN]; // DMA采集缓冲区
volatile uint8_t dma_complete_flag = 0;
// 新增这两行，声明tim.c里的外部变量
extern TIM_HandleTypeDef htim8;
extern DMA_HandleTypeDef hdma_tim8_up;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void AD9226_GPIO_Init(void);
void AD9226_StartSampling(void);
void AD9226_StopSampling(void);
void SendData_JustFloat(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/**
* @brief 配置GPIOD PD0~PD11为输入，读取AD9226的12位并行数据
 */
void AD9226_GPIO_Init(void)
{
    __HAL_RCC_GPIOD_CLK_ENABLE();

    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 |
                          GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7 |
                          GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
}


/**
 * @brief 启动一次采样
 */
void AD9226_StartSampling(void)
{
    dma_complete_flag = 0;

    // 停止TIM8
    TIM8->CR1 &= ~TIM_CR1_CEN;

    // 直接配置DMA寄存器
    DMA2_Stream1->CR &= ~DMA_SxCR_EN;
    while (DMA2_Stream1->CR & DMA_SxCR_EN);

    // 清除中断标志
    DMA2->LIFCR = 0x3D << 6;

    // 设置地址和长度
    DMA2_Stream1->PAR  = (uint32_t)&GPIOD->IDR;
    DMA2_Stream1->M0AR = (uint32_t)adc_buffer;
    DMA2_Stream1->NDTR = ADC_SAMPLE_LEN;

    // 使能DMA传输完成中断
    DMA2_Stream1->CR |= DMA_SxCR_TCIE;

    // 使能DMA
    DMA2_Stream1->CR |= DMA_SxCR_EN;

    // 使能TIM8 UPDATE触发DMA
    TIM8->DIER |= TIM_DIER_UDE;

    // 清除SR，启动TIM8
    TIM8->SR = 0;
    TIM8->CR1 |= TIM_CR1_CEN;
}
/**
 * @brief 停止采样
 */
void AD9226_StopSampling(void)
{
    TIM8->CR1 &= ~TIM_CR1_CEN;         // 停止TIM8
    DMA2_Stream1->CR &= ~DMA_SxCR_EN;  // 禁止DMA
}

/**
 * @brief DMA2 Stream1 全局中断 (传输完成)
 */

/**
 * @brief 通过串口发送数据，VOFA+ FireWater协议
 *        格式: "float_value\n"  (每行一个数据点，\n结尾)
 * @param sample_freq_hz 当前采样频率(Hz)，用于开头打印信息
 */
void SendData_JustFloat(void)
{
    static const uint8_t tail[4] = {0x00, 0x00, 0x80, 0x7F};
    
    for (uint16_t i = 4; i < ADC_SAMPLE_LEN; i++)
    {
        float voltage = ((float)(adc_buffer[i] & ADC_DATA_MASK) - 2048.0f)
                        * (-5.0f) / 2048.0f;
        // 每个点单独发一帧（1个float + 帧尾）
        HAL_UART_Transmit(&huart1, (uint8_t*)&voltage, 4, 10);
        HAL_UART_Transmit(&huart1, (uint8_t*)tail, 4, 10);
}
	}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM8_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */

    AD9226_GPIO_Init();
    HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_1);

    uint32_t arr_val = 83;
    uint32_t sample_freq = 168000000UL / (arr_val + 1);
    char info[80];
    snprintf(info, sizeof(info), "AD9226 Init OK. Fs = %lu Hz\r\n", sample_freq);
    HAL_UART_Transmit(&huart1, (uint8_t *)info, strlen(info), 100);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
while (1)
{
   
     AD9226_StartSampling();

    uint32_t timeout = HAL_GetTick();
    while (!dma_complete_flag)
    {
        if (HAL_GetTick() - timeout > 1000)
        {
            AD9226_StopSampling();
            HAL_UART_Transmit(&huart1, (uint8_t*)"timeout\r\n", 9, 100);
            break;
        }
    }

    if (dma_complete_flag)
    {
        SendData_JustFloat();
		HAL_Delay(100);  // ← 加这行，每100ms发一帧
    }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
