/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    ad603.h
  * @brief   AD603 VCA gain control via DAC
  ******************************************************************************
  */
/* USER CODE END Header */

#ifndef __AD603_H__
#define __AD603_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* -------------------------------------------------------------------------- */
/* AD603 Module Parameters                                                    */
/* -------------------------------------------------------------------------- */
#define AD603_GAIN_MIN      (-20.0f)   /* min gain in dB                     */
#define AD603_GAIN_MAX      (60.0f)    /* max gain in dB                     */
#define AD603_VCTRL_MIN     (0.4f)     /* min control voltage in V           */
#define AD603_VCTRL_MAX     (1.446f)   /* max control voltage in V           */

/* Gain formula: G(dB) = 76.4812 * V - 50.592                                */
/* Reverse:      V = (G + 50.592) / 76.4812                                  */
#define AD603_SLOPE         (76.4812f)
#define AD603_INTERCEPT     (50.592f)

/* DAC reference voltage (mV)                                                */
#define AD603_VREF_MV       (3300U)

/* -------------------------------------------------------------------------- */
/* Public API                                                                 */
/* -------------------------------------------------------------------------- */

/**
 * @brief  Initialize DAC for AD603 DC control voltage output.
 * @note   Reconfigures DAC channel 1 for software trigger (DC mode).
 *         Call once after MX_DAC_Init().
 */
void AD603_Init(void);

/**
 * @brief  Set amplifier gain in dB.
 * @param  gain_db  Desired gain (-20.0 to 60.0 dB), clamped if out of range.
 * @note   Formula: V_ctrl = (G + 50.592) / 76.4812
 *         Typical V_ctrl range: ~0.43V (-20dB) to ~1.43V (+60dB)
 */
void AD603_SetGain(float gain_db);

/**
 * @brief  Set control voltage directly in millivolts.
 * @param  mv  Control voltage in mV (0 ~ VREF_MV), clamped to valid range.
 */
void AD603_SetVoltage(uint16_t mv);

/**
 * @brief  Get current DAC output code (0-4095).
 * @retval 12-bit DAC code
 */
uint16_t AD603_GetCode(void);

/**
 * @brief  Sweep gain from start to end at given step.
 * @param  start_db   Starting gain in dB
 * @param  end_db     Ending gain in dB
 * @param  step_db    Step size in dB
 * @param  delay_ms   Delay between steps in ms
 * @note   Blocks until sweep completes. Uses HAL_Delay().
 */
void AD603_GainSweep(float start_db, float end_db, float step_db, uint32_t delay_ms);

/**
 * @brief  Convert gain (dB) to DAC code.
 * @param  gain_db  Gain in dB
 * @retval 12-bit DAC code (0-4095)
 */
uint16_t AD603_GainToCode(float gain_db);

/**
 * @brief  Convert DAC code to gain (dB).
 * @param  code  12-bit DAC code
 * @retval Estimated gain in dB
 */
float AD603_CodeToGain(uint16_t code);

#ifdef __cplusplus
}
#endif

#endif /* __AD603_H__ */
