/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    ad603.c
  * @brief   AD603 VCA gain control via STM32F4 DAC
  *
  *          Hardware connection:
  *            STM32 PA4 (DAC OUT1)  →  AD603 module GPOS pin
  *            STM32 GND             →  AD603 module GND
  *            External ±5.3V supply →  AD603 module V+ / V-
  *
  *          Control principle:
  *            The AD603 module has GNEG fixed at ~0.93V via an onboard divider.
  *            Applying a voltage to GPOS sets Vg = V_GPOS - 0.93V.
  *            Gain follows: G(dB) = 76.4812 × V_GPOS - 50.592
  *            Valid V_GPOS range: ~0.4V ~ 1.446V → -20dB ~ +60dB
  *
  *          DAC: 12-bit, Vref = 3.3V
  *            code = V_GPOS / 3.3 × 4096
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "ad603.h"
#include "dac.h"
#include <math.h>

/* Private variables ---------------------------------------------------------*/
static uint16_t ad603_current_code = 0;

/* -------------------------------------------------------------------------- */
/* Initialize DAC for AD603 DC voltage output                                 */
/* -------------------------------------------------------------------------- */
void AD603_Init(void)
{
    /* 重配置DAC通道1为无触发模式（DHR写入后自动更新DOR，无需触发信号）*/
    DAC_ChannelConfTypeDef sConfig = {0};
    sConfig.DAC_Trigger      = DAC_TRIGGER_NONE;
    sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;

    HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_1);

    /* Start DAC channel */
    HAL_DAC_Start(&hdac, DAC_CHANNEL_1);

    /* Default: 0 dB gain → V = (0 + 50.592) / 76.4812 ≈ 0.662V */
    AD603_SetGain(0.0f);
}

/* -------------------------------------------------------------------------- */
/* Set amplifier gain in dB                                                   */
/* -------------------------------------------------------------------------- */
void AD603_SetGain(float gain_db)
{
    /* Clamp to valid range */
    if (gain_db < AD603_GAIN_MIN) gain_db = AD603_GAIN_MIN;
    if (gain_db > AD603_GAIN_MAX) gain_db = AD603_GAIN_MAX;

    /* G(dB) = 76.4812 × V - 50.592  →  V = (G + 50.592) / 76.4812 */
    float v_ctrl = (gain_db + AD603_INTERCEPT) / AD603_SLOPE;

    /* Clamp voltage to module's tested valid range */
    if (v_ctrl < AD603_VCTRL_MIN) v_ctrl = AD603_VCTRL_MIN;
    if (v_ctrl > AD603_VCTRL_MAX) v_ctrl = AD603_VCTRL_MAX;

    /* Convert to DAC code: code = V / Vref × 4096 */
    uint16_t code = (uint16_t)((v_ctrl * 4096.0f) / (float)(AD603_VREF_MV / 1000.0f) + 0.5f);
    if (code > 4095U) code = 4095U;

    ad603_current_code = code;

    /* Write to DAC and trigger update */
    HAL_DAC_SetValue(&hdac, DAC_CHANNEL_1, DAC_ALIGN_12B_R, code);
}

/* -------------------------------------------------------------------------- */
/* Set control voltage directly in millivolts                                 */
/* -------------------------------------------------------------------------- */
void AD603_SetVoltage(uint16_t mv)
{
    if (mv > AD603_VREF_MV) mv = AD603_VREF_MV;

    ad603_current_code = (uint16_t)(((uint32_t)mv * 4096UL + AD603_VREF_MV / 2U)
                                    / AD603_VREF_MV);
    if (ad603_current_code > 4095U) ad603_current_code = 4095U;

    HAL_DAC_SetValue(&hdac, DAC_CHANNEL_1, DAC_ALIGN_12B_R, ad603_current_code);
}

/* -------------------------------------------------------------------------- */
/* Get current DAC output code                                                */
/* -------------------------------------------------------------------------- */
uint16_t AD603_GetCode(void)
{
    return ad603_current_code;
}

/* -------------------------------------------------------------------------- */
/* Sweep gain from start_db to end_db by step_db                              */
/* -------------------------------------------------------------------------- */
void AD603_GainSweep(float start_db, float end_db, float step_db, uint32_t delay_ms)
{
    /* Clamp parameters */
    if (start_db < AD603_GAIN_MIN) start_db = AD603_GAIN_MIN;
    if (start_db > AD603_GAIN_MAX) start_db = AD603_GAIN_MAX;
    if (end_db   < AD603_GAIN_MIN) end_db   = AD603_GAIN_MIN;
    if (end_db   > AD603_GAIN_MAX) end_db   = AD603_GAIN_MAX;
    if (step_db  < 0.1f)          step_db  = 0.1f;

    if (start_db <= end_db)
    {
        /* Sweep upward */
        for (float g = start_db; g <= end_db; g += step_db)
        {
            AD603_SetGain(g);
            HAL_Delay(delay_ms);
        }
    }
    else
    {
        /* Sweep downward */
        for (float g = start_db; g >= end_db; g -= step_db)
        {
            AD603_SetGain(g);
            HAL_Delay(delay_ms);
        }
    }
    /* Ensure final value is exact */
    AD603_SetGain(end_db);
}

/* -------------------------------------------------------------------------- */
/* Convert gain (dB) to DAC code                                              */
/* -------------------------------------------------------------------------- */
uint16_t AD603_GainToCode(float gain_db)
{
    if (gain_db < AD603_GAIN_MIN) gain_db = AD603_GAIN_MIN;
    if (gain_db > AD603_GAIN_MAX) gain_db = AD603_GAIN_MAX;

    float v = (gain_db + AD603_INTERCEPT) / AD603_SLOPE;
    uint16_t code = (uint16_t)((v * 4096.0f) / ((float)AD603_VREF_MV / 1000.0f) + 0.5f);
    return (code > 4095U) ? 4095U : code;
}

/* -------------------------------------------------------------------------- */
/* Convert DAC code to estimated gain (dB)                                    */
/* -------------------------------------------------------------------------- */
float AD603_CodeToGain(uint16_t code)
{
    if (code > 4095U) code = 4095U;
    float v = (float)code * (float)AD603_VREF_MV / 1000.0f / 4096.0f;
    float g = AD603_SLOPE * v - AD603_INTERCEPT;
    return g;
}
