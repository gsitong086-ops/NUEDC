/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    dac.c
  * @brief   This file provides code for the configuration
  *          of the DAC instances.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "dac.h"

/* USER CODE BEGIN 0 */
#include <math.h>

#ifndef M_PI
#define M_PI  3.14159265358979323846
#endif

#define WAVE_BUF_SIZE   512U    /* power of 2, smoother waveform          */
#define DAC_MAX         4095U
#define TIM4_CLK        84000000UL

/* -------------------------------------------------------------------------- */
/* Calibration — tune these to match your board's actual output               */
/* -------------------------------------------------------------------------- */
#define VREF_MV         3300U   /* DAC reference voltage (measure VDDA pin)  */
#define CAL_OFFSET_MV   900       /* DC offset trim: +900 = shift output up    */

/* mV to DAC code: code = mv * 4096 / VREF_MV (with rounding) */
#define MV_TO_DAC(mv)  ((uint16_t)(((uint32_t)(mv) * 4096UL + VREF_MV / 2U) / VREF_MV))

static uint16_t wave_buf[WAVE_BUF_SIZE];

/* amp_pp = peak-to-peak amplitude in DAC codes, offs = DC offset in codes */
static void WaveGen_FillTable(uint16_t amp_pp, uint16_t offs)
{
    uint16_t amp_pk = amp_pp / 2U;
    for (uint16_t i = 0; i < WAVE_BUF_SIZE; i++) {
        double phase = 2.0 * M_PI * i / WAVE_BUF_SIZE;
        int16_t v = (int16_t)(amp_pk * sin(phase) + 0.5);  /* round to nearest */
        wave_buf[i] = offs + v;
    }
}

/* USER CODE END 0 */

DAC_HandleTypeDef hdac;
DMA_HandleTypeDef hdma_dac1;

/* DAC init function */
void MX_DAC_Init(void)
{

  /* USER CODE BEGIN DAC_Init 0 */

  /* USER CODE END DAC_Init 0 */

  DAC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN DAC_Init 1 */

  /* USER CODE END DAC_Init 1 */

  /** DAC Initialization
  */
  hdac.Instance = DAC;
  if (HAL_DAC_Init(&hdac) != HAL_OK)
  {
    Error_Handler();
  }

  /** DAC channel OUT1 config
  */
  sConfig.DAC_Trigger = DAC_TRIGGER_T4_TRGO;
  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  if (HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DAC_Init 2 */

  /* USER CODE END DAC_Init 2 */

}

void HAL_DAC_MspInit(DAC_HandleTypeDef* dacHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(dacHandle->Instance==DAC)
  {
  /* USER CODE BEGIN DAC_MspInit 0 */

  /* USER CODE END DAC_MspInit 0 */
    /* DAC clock enable */
    __HAL_RCC_DAC_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**DAC GPIO Configuration
    PA4     ------> DAC_OUT1
    */
    GPIO_InitStruct.Pin = GPIO_PIN_4;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* DAC DMA Init */
    /* DAC1 Init */
    hdma_dac1.Instance = DMA1_Stream5;
    hdma_dac1.Init.Channel = DMA_CHANNEL_7;
    hdma_dac1.Init.Direction = DMA_MEMORY_TO_PERIPH;
    hdma_dac1.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_dac1.Init.MemInc = DMA_MINC_ENABLE;
    hdma_dac1.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    hdma_dac1.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    hdma_dac1.Init.Mode = DMA_CIRCULAR;
    hdma_dac1.Init.Priority = DMA_PRIORITY_LOW;
    hdma_dac1.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    if (HAL_DMA_Init(&hdma_dac1) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(dacHandle,DMA_Handle1,hdma_dac1);

  /* USER CODE BEGIN DAC_MspInit 1 */

  /* USER CODE END DAC_MspInit 1 */
  }
}

void HAL_DAC_MspDeInit(DAC_HandleTypeDef* dacHandle)
{

  if(dacHandle->Instance==DAC)
  {
  /* USER CODE BEGIN DAC_MspDeInit 0 */

  /* USER CODE END DAC_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_DAC_CLK_DISABLE();

    /**DAC GPIO Configuration
    PA4     ------> DAC_OUT1
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_4);

    /* DAC DMA DeInit */
    HAL_DMA_DeInit(dacHandle->DMA_Handle1);
  /* USER CODE BEGIN DAC_MspDeInit 1 */

  /* USER CODE END DAC_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */

/**
 * @brief  Start sine wave output.
 * @param  freq_hz    Frequency in Hz (e.g. 100)
 * @param  amp_mv     Peak-to-peak amplitude in mV (0 ~ VREF_MV, e.g. 2900)
 * @param  offset_mv  DC offset in mV (0 ~ VREF_MV, e.g. 1650 for mid-rail)
 */
void WaveGen_Start(uint32_t freq_hz, uint16_t amp_mv, uint16_t offset_mv)
{
    extern TIM_HandleTypeDef htim4;

    /* ---------- mV to DAC codes (with calibration trim) ---------- */
    uint16_t amp_pp  = MV_TO_DAC(amp_mv);
    uint16_t offs    = MV_TO_DAC(offset_mv + CAL_OFFSET_MV);
    uint16_t amp_pk  = amp_pp / 2U;

    /* ---------- clamp to valid range ---------- */
    if (amp_pp > DAC_MAX) amp_pp = DAC_MAX;
    if (offs < amp_pk) offs = amp_pk;
    if (offs > DAC_MAX - amp_pk) offs = DAC_MAX - amp_pk;
    if (freq_hz == 0U) freq_hz = 1U;

    /* ---------- fill wave table ---------- */
    WaveGen_FillTable(amp_pp, offs);

    /* ---------- stop running peripherals ---------- */
    HAL_TIM_Base_Stop(&htim4);
    HAL_DAC_Stop_DMA(&hdac, DAC_CHANNEL_1);

    /* ---------- TIM4 timing ---------- */
    uint32_t sample_rate = freq_hz * WAVE_BUF_SIZE;
    uint32_t clk_div = TIM4_CLK / sample_rate;
    uint32_t psc = 0U, arr;

    if (clk_div == 0U) clk_div = 1U;
    while (clk_div / (psc + 1U) > 65536U) { psc++; }
    arr = clk_div / (psc + 1U) - 1U;
    if (arr > 65535U) arr = 65535U;

    __HAL_TIM_SET_PRESCALER(&htim4, psc);
    __HAL_TIM_SET_AUTORELOAD(&htim4, arr);

    /* ---------- start DAC DMA + timer ---------- */
    HAL_DAC_Start_DMA(&hdac, DAC_CHANNEL_1,
                      (uint32_t *)wave_buf, WAVE_BUF_SIZE,
                      DAC_ALIGN_12B_R);
    HAL_TIM_Base_Start(&htim4);
}

void WaveGen_Stop(void)
{
    extern TIM_HandleTypeDef htim4;
    HAL_TIM_Base_Stop(&htim4);
    HAL_DAC_Stop_DMA(&hdac, DAC_CHANNEL_1);
}

/* USER CODE END 1 */

