clk0输出10.7MHz
clk1扫频1M-100MHz

1.修改clk0输出频率（原来10.7M）
在si5351.c中
#define SI5351_PLLA_CLOCK0_HZ  898800000UL和SI5351_SetMultiSynth(SI5351_CHANNEL_0, 84U, 0U, 1U, 0U);
计算关系CLK0 = PLLA频率 ÷ MS0分频数
     = 898.8 MHz ÷ 84
     = 10.7 MHz
例如：改成10 MHz：
#define SI5351_PLLA_CLOCK0_HZ  900000000UL
SI5351_SetMultiSynth(SI5351_CHANNEL_0, 90U, 0U, 1U, 0U);
结果：900 MHz ÷ 90 = 10 MHz

2.修改扫频范围（原1MHz-100Mhz）
（1）main.c中
  #define CLK1_SWEEP_START_HZ          8000UL
#define CLK1_SWEEP_STOP_HZ      100000000UL
#define CLK1_SWEEP_STEP_HZ          10000UL
#define CLK1_SWEEP_DWELL_MS             20U
START：起始频率
STOP ：终止频率
STEP ：每次增加的频率
DWELL：每个频点停留时间，单位ms

例如从1 MHz扫到20 MHz，每次增加10 kHz，每点停留50 ms：
#define CLK1_SWEEP_START_HZ       1000000UL
#define CLK1_SWEEP_STOP_HZ       20000000UL
#define CLK1_SWEEP_STEP_HZ          10000UL
#define CLK1_SWEEP_DWELL_MS             50U

例如从10 MHz扫到100 MHz，每次增加100 kHz：
#define CLK1_SWEEP_START_HZ      10000000UL
#define CLK1_SWEEP_STOP_HZ      100000000UL
#define CLK1_SWEEP_STEP_HZ         100000UL
#define CLK1_SWEEP_DWELL_MS             20U

例如在10.6～10.8 MHz附近细扫，每次增加1 kHz：
#define CLK1_SWEEP_START_HZ      10600000UL
#define CLK1_SWEEP_STOP_HZ       10800000UL
#define CLK1_SWEEP_STEP_HZ           1000UL
#define CLK1_SWEEP_DWELL_MS            100U

注意必须满足：
8000 Hz ≤ START < STOP ≤ 100000000 Hz
STEP > 0
STEP ≤ STOP - START

（2）8kHz的写法需要另外修改，本代码中未提供