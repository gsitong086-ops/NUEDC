#include "si5351.h"

#define SI5351_REG_DEVICE_STATUS       0U
#define SI5351_REG_OUTPUT_ENABLE       3U
#define SI5351_REG_CLK0_CONTROL       16U
#define SI5351_REG_PLLA_PARAMETERS    26U
#define SI5351_REG_MS0_PARAMETERS     42U
#define SI5351_REG_PLL_RESET         177U
#define SI5351_REG_XTAL_LOAD         183U

#define SI5351_PLL_MIN_HZ      600000000UL
#define SI5351_PLL_MAX_HZ      900000000UL
#define SI5351_FREQ_MIN_HZ          8000UL
#define SI5351_FREQ_MAX_HZ     160000000UL
#define SI5351_MS_MIN_DIVIDER            4UL
#define SI5351_MS_MAX_DIVIDER          900UL

static I2C_HandleTypeDef *si5351_i2c;

static HAL_StatusTypeDef SI5351_Write(uint8_t reg, uint8_t value)
{
  return HAL_I2C_Mem_Write(si5351_i2c, SI5351_I2C_ADDRESS, reg,
                           I2C_MEMADD_SIZE_8BIT, &value, 1U, 100U);
}

static HAL_StatusTypeDef SI5351_Read(uint8_t reg, uint8_t *value)
{
  return HAL_I2C_Mem_Read(si5351_i2c, SI5351_I2C_ADDRESS, reg,
                          I2C_MEMADD_SIZE_8BIT, value, 1U, 100U);
}

static HAL_StatusTypeDef SI5351_WriteBlock(uint8_t start_reg,
                                           uint8_t *data,
                                           uint16_t length)
{
  return HAL_I2C_Mem_Write(si5351_i2c, SI5351_I2C_ADDRESS, start_reg,
                           I2C_MEMADD_SIZE_8BIT, data, length, 100U);
}

static HAL_StatusTypeDef SI5351_SetPLL(uint32_t pll_hz)
{
  uint32_t a;
  uint32_t b;
  uint32_t c = 1048575UL;
  uint32_t floor_value;
  uint32_t p1;
  uint32_t p2;
  uint32_t p3;
  uint32_t remainder;
  uint8_t data[8];

  a = pll_hz / SI5351_XTAL_FREQUENCY_HZ;
  remainder = pll_hz % SI5351_XTAL_FREQUENCY_HZ;
  b = (uint32_t)((((uint64_t)remainder * c) +
                  (SI5351_XTAL_FREQUENCY_HZ / 2UL)) /
                 SI5351_XTAL_FREQUENCY_HZ);

  if (b >= c)
  {
    a++;
    b = 0U;
  }

  floor_value = (uint32_t)(((uint64_t)128U * b) / c);
  p1 = 128U * a + floor_value - 512U;
  p2 = 128U * b - c * floor_value;
  p3 = c;

  data[0] = (uint8_t)((p3 >> 8) & 0xFFU);
  data[1] = (uint8_t)(p3 & 0xFFU);
  data[2] = (uint8_t)((p1 >> 16) & 0x03U);
  data[3] = (uint8_t)((p1 >> 8) & 0xFFU);
  data[4] = (uint8_t)(p1 & 0xFFU);
  data[5] = (uint8_t)(((p3 >> 12) & 0xF0U) |
                      ((p2 >> 16) & 0x0FU));
  data[6] = (uint8_t)((p2 >> 8) & 0xFFU);
  data[7] = (uint8_t)(p2 & 0xFFU);

  return SI5351_WriteBlock(SI5351_REG_PLLA_PARAMETERS, data, 8U);
}

static HAL_StatusTypeDef SI5351_SetMultiSynth(uint8_t channel,
                                              uint32_t divider,
                                              uint8_t r_div_code)
{
  uint32_t p1 = 128U * divider - 512U;
  uint8_t data[8];
  uint8_t base_reg = (uint8_t)(SI5351_REG_MS0_PARAMETERS + channel * 8U);

  data[0] = 0x00U;
  data[1] = 0x01U;
  data[2] = (uint8_t)(((p1 >> 16) & 0x03U) |
                      ((r_div_code & 0x07U) << 4));
  data[3] = (uint8_t)((p1 >> 8) & 0xFFU);
  data[4] = (uint8_t)(p1 & 0xFFU);
  data[5] = 0x00U;
  data[6] = 0x00U;
  data[7] = 0x00U;

  return SI5351_WriteBlock(base_reg, data, 8U);
}

HAL_StatusTypeDef SI5351_OutputEnable(uint8_t channel, uint8_t enable)
{
  uint8_t output_enable;
  HAL_StatusTypeDef status;

  if ((si5351_i2c == NULL) || (channel > SI5351_CHANNEL_2))
  {
    return HAL_ERROR;
  }

  status = SI5351_Read(SI5351_REG_OUTPUT_ENABLE, &output_enable);
  if (status != HAL_OK)
  {
    return status;
  }

  if (enable != 0U)
  {
    output_enable &= (uint8_t)~(1U << channel);
  }
  else
  {
    output_enable |= (uint8_t)(1U << channel);
  }

  return SI5351_Write(SI5351_REG_OUTPUT_ENABLE, output_enable);
}

HAL_StatusTypeDef SI5351_Init(I2C_HandleTypeDef *hi2c)
{
  HAL_StatusTypeDef status;
  uint8_t device_status;
  uint32_t timeout;
  uint8_t reg;

  if (hi2c == NULL)
  {
    return HAL_ERROR;
  }

  si5351_i2c = hi2c;

  status = HAL_I2C_IsDeviceReady(si5351_i2c, SI5351_I2C_ADDRESS, 3U, 100U);
  if (status != HAL_OK)
  {
    return status;
  }

  timeout = HAL_GetTick() + 100U;
  do
  {
    status = SI5351_Read(SI5351_REG_DEVICE_STATUS, &device_status);
    if (status != HAL_OK)
    {
      return status;
    }
    if ((device_status & 0x80U) == 0U)
    {
      break;
    }
  } while (HAL_GetTick() < timeout);

  if ((device_status & 0x80U) != 0U)
  {
    return HAL_TIMEOUT;
  }

  status = SI5351_Write(SI5351_REG_OUTPUT_ENABLE, 0xFFU);
  if (status != HAL_OK)
  {
    return status;
  }

  for (reg = 16U; reg <= 23U; reg++)
  {
    status = SI5351_Write(reg, 0x80U);
    if (status != HAL_OK)
    {
      return status;
    }
  }

  /* 25 MHz crystal, nominal 10 pF internal crystal load setting. */
  return SI5351_Write(SI5351_REG_XTAL_LOAD, 0xD2U);
}

HAL_StatusTypeDef SI5351_SetFrequency(uint8_t channel, uint32_t frequency_hz)
{
  uint32_t r_divider = 1U;
  uint8_t r_div_code = 0U;
  uint32_t ms_frequency;
  uint32_t ms_divider;
  uint32_t pll_frequency;
  HAL_StatusTypeDef status;

  if ((si5351_i2c == NULL) ||
      (channel > SI5351_CHANNEL_2) ||
      (frequency_hz < SI5351_FREQ_MIN_HZ) ||
      (frequency_hz > SI5351_FREQ_MAX_HZ))
  {
    return HAL_ERROR;
  }

  while ((r_divider < 128U) &&
         (((uint64_t)frequency_hz * r_divider *
           SI5351_MS_MAX_DIVIDER) < SI5351_PLL_MIN_HZ))
  {
    r_divider <<= 1;
    r_div_code++;
  }

  ms_frequency = frequency_hz * r_divider;
  ms_divider = SI5351_PLL_MAX_HZ / ms_frequency;

  if (ms_divider > SI5351_MS_MAX_DIVIDER)
  {
    ms_divider = SI5351_MS_MAX_DIVIDER;
  }
  if ((ms_divider & 1U) != 0U)
  {
    ms_divider--;
  }

  if (ms_divider < SI5351_MS_MIN_DIVIDER)
  {
    return HAL_ERROR;
  }

  pll_frequency = ms_frequency * ms_divider;
  if ((pll_frequency < SI5351_PLL_MIN_HZ) ||
      (pll_frequency > SI5351_PLL_MAX_HZ))
  {
    return HAL_ERROR;
  }

  status = SI5351_OutputEnable(channel, 0U);
  if (status != HAL_OK)
  {
    return status;
  }

  status = SI5351_SetPLL(pll_frequency);
  if (status != HAL_OK)
  {
    return status;
  }

  status = SI5351_SetMultiSynth(channel, ms_divider, r_div_code);
  if (status != HAL_OK)
  {
    return status;
  }

  /* Integer mode, PLLA source, MultiSynth source, non-inverted, 8 mA drive. */
  status = SI5351_Write((uint8_t)(SI5351_REG_CLK0_CONTROL + channel), 0x4FU);
  if (status != HAL_OK)
  {
    return status;
  }

  status = SI5351_Write(SI5351_REG_PLL_RESET, 0x20U);
  if (status != HAL_OK)
  {
    return status;
  }

  return SI5351_OutputEnable(channel, 1U);
}
