#include "si5351.h"

#define SI5351_REG_DEVICE_STATUS       0U
#define SI5351_REG_OUTPUT_ENABLE       3U
#define SI5351_REG_CLK0_CONTROL       16U
#define SI5351_REG_CLK1_CONTROL       17U
#define SI5351_REG_PLLA_PARAMETERS    26U
#define SI5351_REG_PLLB_PARAMETERS    34U
#define SI5351_REG_MS0_PARAMETERS     42U
#define SI5351_REG_PLL_RESET         177U
#define SI5351_REG_XTAL_LOAD         183U

#define SI5351_PLLA_CLOCK0_HZ  898800000UL
#define SI5351_PLLB_SWEEP_HZ   900000000UL
#define SI5351_FRACTION_MAX      1048575UL
#define SI5351_MS_MIN_DIVIDER          8UL
#define SI5351_MS_MAX_DIVIDER        900UL

static I2C_HandleTypeDef *si5351_i2c;
static uint8_t clock1_sweep_ready;

static HAL_StatusTypeDef SI5351_Write(uint8_t reg, uint8_t value)
{
  return HAL_I2C_Mem_Write(si5351_i2c, SI5351_I2C_ADDRESS, reg,
                           I2C_MEMADD_SIZE_8BIT, &value, 1U, 100U);
}

static HAL_StatusTypeDef SI5351_Read(uint8_t reg, uint8_t *value)
{
  return HAL_I2C_Mem_Read(si5351_i2c, SI5351_I2C_ADDRESS, reg,
                          I2C_MEMADD_SIZE_8BIT, value, 1U, 100U);
}

static HAL_StatusTypeDef SI5351_WriteBlock(uint8_t start_reg,
                                           uint8_t *data,
                                           uint16_t length)
{
  return HAL_I2C_Mem_Write(si5351_i2c, SI5351_I2C_ADDRESS, start_reg,
                           I2C_MEMADD_SIZE_8BIT, data, length, 100U);
}

static uint32_t SI5351_Gcd(uint32_t a, uint32_t b)
{
  uint32_t remainder;

  while (b != 0U)
  {
    remainder = a % b;
    a = b;
    b = remainder;
  }
  return a;
}

static void SI5351_MakeFraction(uint32_t numerator,
                                uint32_t denominator,
                                uint32_t *b,
                                uint32_t *c)
{
  uint32_t gcd;

  if (numerator == 0U)
  {
    *b = 0U;
    *c = 1U;
    return;
  }

  gcd = SI5351_Gcd(numerator, denominator);
  *b = numerator / gcd;
  *c = denominator / gcd;

  if (*c > SI5351_FRACTION_MAX)
  {
    *c = SI5351_FRACTION_MAX;
    *b = (uint32_t)((((uint64_t)numerator * (*c)) +
                     (denominator / 2U)) / denominator);
    if (*b >= *c)
    {
      *b = *c - 1U;
    }
  }
}

static HAL_StatusTypeDef SI5351_WriteSynthParameters(uint8_t base_reg,
                                                     uint32_t a,
                                                     uint32_t b,
                                                     uint32_t c,
                                                     uint8_t r_div_code)
{
  uint32_t floor_value;
  uint32_t p1;
  uint32_t p2;
  uint32_t p3;
  uint8_t data[8];

  floor_value = (uint32_t)(((uint64_t)128U * b) / c);
  p1 = 128U * a + floor_value - 512U;
  p2 = 128U * b - c * floor_value;
  p3 = c;

  data[0] = (uint8_t)((p3 >> 8) & 0xFFU);
  data[1] = (uint8_t)(p3 & 0xFFU);
  data[2] = (uint8_t)(((p1 >> 16) & 0x03U) |
                      ((r_div_code & 0x07U) << 4));
  data[3] = (uint8_t)((p1 >> 8) & 0xFFU);
  data[4] = (uint8_t)(p1 & 0xFFU);
  data[5] = (uint8_t)(((p3 >> 12) & 0xF0U) |
                      ((p2 >> 16) & 0x0FU));
  data[6] = (uint8_t)((p2 >> 8) & 0xFFU);
  data[7] = (uint8_t)(p2 & 0xFFU);

  return SI5351_WriteBlock(base_reg, data, 8U);
}

static HAL_StatusTypeDef SI5351_SetPLL(uint8_t base_reg, uint32_t pll_hz)
{
  uint32_t a;
  uint32_t b;
  uint32_t c;
  uint32_t remainder;

  a = pll_hz / SI5351_XTAL_FREQUENCY_HZ;
  remainder = pll_hz % SI5351_XTAL_FREQUENCY_HZ;
  SI5351_MakeFraction(remainder, SI5351_XTAL_FREQUENCY_HZ, &b, &c);

  return SI5351_WriteSynthParameters(base_reg, a, b, c, 0U);
}

static HAL_StatusTypeDef SI5351_SetMultiSynth(uint8_t channel,
                                              uint32_t a,
                                              uint32_t b,
                                              uint32_t c,
                                              uint8_t r_div_code)
{
  uint8_t base_reg = (uint8_t)(SI5351_REG_MS0_PARAMETERS + channel * 8U);

  return SI5351_WriteSynthParameters(base_reg, a, b, c, r_div_code);
}

HAL_StatusTypeDef SI5351_OutputEnable(uint8_t channel, uint8_t enable)
{
  uint8_t output_enable;
  HAL_StatusTypeDef status;

  if ((si5351_i2c == NULL) || (channel > SI5351_CHANNEL_2))
  {
    return HAL_ERROR;
  }

  status = SI5351_Read(SI5351_REG_OUTPUT_ENABLE, &output_enable);
  if (status != HAL_OK)
  {
    return status;
  }

  if (enable != 0U)
  {
    output_enable &= (uint8_t)~(1U << channel);
  }
  else
  {
    output_enable |= (uint8_t)(1U << channel);
  }

  return SI5351_Write(SI5351_REG_OUTPUT_ENABLE, output_enable);
}

HAL_StatusTypeDef SI5351_Init(I2C_HandleTypeDef *hi2c)
{
  HAL_StatusTypeDef status;
  uint8_t device_status = 0x80U;
  uint32_t start_tick;
  uint8_t reg;

  if (hi2c == NULL)
  {
    return HAL_ERROR;
  }

  si5351_i2c = hi2c;
  clock1_sweep_ready = 0U;

  status = HAL_I2C_IsDeviceReady(si5351_i2c, SI5351_I2C_ADDRESS, 3U, 100U);
  if (status != HAL_OK)
  {
    return status;
  }

  start_tick = HAL_GetTick();
  do
  {
    status = SI5351_Read(SI5351_REG_DEVICE_STATUS, &device_status);
    if (status != HAL_OK)
    {
      return status;
    }
    if ((device_status & 0x80U) == 0U)
    {
      break;
    }
  } while ((HAL_GetTick() - start_tick) < 100U);

  if ((device_status & 0x80U) != 0U)
  {
    return HAL_TIMEOUT;
  }

  status = SI5351_Write(SI5351_REG_OUTPUT_ENABLE, 0xFFU);
  if (status != HAL_OK)
  {
    return status;
  }

  for (reg = 16U; reg <= 23U; reg++)
  {
    status = SI5351_Write(reg, 0x80U);
    if (status != HAL_OK)
    {
      return status;
    }
  }

  /* Common SI5351A module: 25 MHz crystal and nominal 10 pF load. */
  return SI5351_Write(SI5351_REG_XTAL_LOAD, 0xD2U);
}

HAL_StatusTypeDef SI5351_ConfigureClock0_10M7(void)
{
  HAL_StatusTypeDef status;

  if (si5351_i2c == NULL)
  {
    return HAL_ERROR;
  }

  status = SI5351_OutputEnable(SI5351_CHANNEL_0, 0U);
  if (status != HAL_OK)
  {
    return status;
  }

  /* PLLA = 898.8 MHz and MS0 = 84 give exactly 10.7 MHz. */
  status = SI5351_SetPLL(SI5351_REG_PLLA_PARAMETERS, SI5351_PLLA_CLOCK0_HZ);
  if (status != HAL_OK)
  {
    return status;
  }

  status = SI5351_SetMultiSynth(SI5351_CHANNEL_0, 84U, 0U, 1U, 0U);
  if (status != HAL_OK)
  {
    return status;
  }

  /* Integer mode, PLLA, MultiSynth source, 8 mA drive. */
  status = SI5351_Write(SI5351_REG_CLK0_CONTROL, 0x4FU);
  if (status != HAL_OK)
  {
    return status;
  }

  status = SI5351_Write(SI5351_REG_PLL_RESET, 0x20U);
  if (status != HAL_OK)
  {
    return status;
  }

  return SI5351_OutputEnable(SI5351_CHANNEL_0, 1U);
}

HAL_StatusTypeDef SI5351_PrepareClock1Sweep(void)
{
  HAL_StatusTypeDef status;

  if (si5351_i2c == NULL)
  {
    return HAL_ERROR;
  }

  status = SI5351_OutputEnable(SI5351_CHANNEL_1, 0U);
  if (status != HAL_OK)
  {
    return status;
  }

  status = SI5351_SetPLL(SI5351_REG_PLLB_PARAMETERS, SI5351_PLLB_SWEEP_HZ);
  if (status != HAL_OK)
  {
    return status;
  }

  status = SI5351_Write(SI5351_REG_PLL_RESET, 0x80U);
  if (status == HAL_OK)
  {
    clock1_sweep_ready = 1U;
  }
  return status;
}

HAL_StatusTypeDef SI5351_SetClock1Frequency(uint32_t frequency_hz)
{
  uint32_t r_divider = 1U;
  uint8_t r_div_code = 0U;
  uint32_t multisynth_input_hz;
  uint32_t a;
  uint32_t b;
  uint32_t c;
  uint32_t remainder;
  uint8_t clock_control;
  HAL_StatusTypeDef status;

  if ((si5351_i2c == NULL) ||
      (clock1_sweep_ready == 0U) ||
      (frequency_hz < SI5351_CLK1_MIN_HZ) ||
      (frequency_hz > SI5351_CLK1_MAX_HZ))
  {
    return HAL_ERROR;
  }

  while ((r_divider < 128U) &&
         ((uint64_t)SI5351_PLLB_SWEEP_HZ >
          ((uint64_t)frequency_hz * r_divider *
           SI5351_MS_MAX_DIVIDER)))
  {
    r_divider <<= 1;
    r_div_code++;
  }

  multisynth_input_hz = frequency_hz * r_divider;
  a = SI5351_PLLB_SWEEP_HZ / multisynth_input_hz;
  remainder = SI5351_PLLB_SWEEP_HZ % multisynth_input_hz;

  if ((a < SI5351_MS_MIN_DIVIDER) || (a > SI5351_MS_MAX_DIVIDER))
  {
    return HAL_ERROR;
  }

  SI5351_MakeFraction(remainder, multisynth_input_hz, &b, &c);

  status = SI5351_OutputEnable(SI5351_CHANNEL_1, 0U);
  if (status != HAL_OK)
  {
    return status;
  }

  status = SI5351_SetMultiSynth(SI5351_CHANNEL_1, a, b, c, r_div_code);
  if (status != HAL_OK)
  {
    return status;
  }

  /* PLLB, MultiSynth source, 8 mA drive; integer mode only when legal. */
  clock_control = 0x2FU;
  if ((b == 0U) && ((a & 1U) == 0U))
  {
    clock_control |= 0x40U;
  }

  status = SI5351_Write(SI5351_REG_CLK1_CONTROL, clock_control);
  if (status != HAL_OK)
  {
    return status;
  }

  return SI5351_OutputEnable(SI5351_CHANNEL_1, 1U);
}
