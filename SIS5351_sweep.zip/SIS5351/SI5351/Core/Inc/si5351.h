#ifndef __SI5351_H
#define __SI5351_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f4xx_hal.h"

#define SI5351_I2C_ADDRESS        (0x60U << 1)
#define SI5351_XTAL_FREQUENCY_HZ  25000000UL

#define SI5351_CHANNEL_0          0U
#define SI5351_CHANNEL_1          1U
#define SI5351_CHANNEL_2          2U

#define SI5351_CLK1_MIN_HZ        8000UL
#define SI5351_CLK1_MAX_HZ        100000000UL

HAL_StatusTypeDef SI5351_Init(I2C_HandleTypeDef *hi2c);
HAL_StatusTypeDef SI5351_ConfigureClock0_10M7(void);
HAL_StatusTypeDef SI5351_PrepareClock1Sweep(void);
HAL_StatusTypeDef SI5351_SetClock1Frequency(uint32_t frequency_hz);
HAL_StatusTypeDef SI5351_OutputEnable(uint8_t channel, uint8_t enable);

#ifdef __cplusplus
}
#endif

#endif
