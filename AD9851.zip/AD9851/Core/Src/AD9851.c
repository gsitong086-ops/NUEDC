/**
 ******************************************************************************
 * @file    AD9851.c
 * @brief   AD9851 DDS waveform generator driver
 * @note    Adapted from vendor example code (康威电子 V0.7) for STM32F4 HAL.
 *
 *          Serial protocol (proven by vendor — module ships with this):
 *            Byte order:  W4 → W3 → W2 → W1 → W0
 *            Bit order:   LSB first within each byte
 *            Data pin:    D7 (PC7)
 *            Mode pins:   D0=1, D1=1, D2=0 (asserted at init)
 *
 *          Parallel protocol:
 *            Byte order:  W0 → W1 → W2 → W3 → W4 (datasheet order)
 *            Data pins:   D0-D7 (PC0-PC7), 8-bit parallel load
 *            One W_CLK pulse per byte, then FQ_UD pulse to commit
 *
 *          Reference: vendor example code V0.7 (2023-06)
 *                    https://kvdz.taobao.com/
 ******************************************************************************
 */

#include "AD9851.h"

/*============================================================================*/
/* Internal state variables                                                   */
/*============================================================================*/

static AD9851_Mode  AD9851_LoadMode;             /* Parallel or serial */
static uint8_t      AD9851_Multiplier;            /* 1× or 6× PLL */
static uint8_t      AD9851_CurrPhase = 0;         /* Last written phase value */

/*============================================================================*/
/* GPIO initialization                                                        */
/*============================================================================*/

/**
 * @brief  Initialize all GPIO pins needed for AD9851
 * @note   PA3=FQ_UD, PA4=W_CLK, PA6=RST — push-pull outputs.
 *         PC0-PC7 — push-pull outputs for the 8-bit data bus.
 *         After init, all data bus pins are set HIGH (matches vendor init).
 */
static void AD9851_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    /* Enable clock for GPIOA and GPIOC */
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();

    /* ---- PA3 (FQ_UD), PA4 (W_CLK), PA6 (RST) as push-pull outputs ---- */
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    GPIO_InitStruct.Pin   = AD9851_FQ_PIN | AD9851_CLK_PIN | AD9851_RST_PIN;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* ---- PC0-PC7 (D0-D7) as push-pull outputs ---- */
    GPIO_InitStruct.Pin   = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3
                          | GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* Set all data bus pins HIGH initially (matches vendor: AD985x_DataBus=0xFFFF0000) */
    AD9851_DATA_PORT->BSRR = 0x000000FF;         /* Set PC0-PC7 HIGH (lower 8 bits of BSRR) */

    /* Set control pins to idle levels */
    AD9851_CLK_L();                              /* W_CLK idle = low */
    AD9851_FQ_L();                               /* FQ_UD idle = low */
    AD9851_RST_L();                              /* RST initially low */
}

/*============================================================================*/
/* Reset sequences (identical to vendor code)                                 */
/*============================================================================*/

/**
 * @brief  Reset AD9851 in parallel mode
 */
static void AD9851_ResetParallel(void)
{
    AD9851_CLK_L();
    AD9851_FQ_L();

    /* Reset pulse: RST low → high → low */
    AD9851_RST_L();
    AD9851_RST_H();
    AD9851_RST_L();
}

/**
 * @brief  Reset AD9851 in serial mode
 * @note   After standard reset, extra W_CLK + FQ_UD pulses put chip into
 *         serial mode (datasheet serial initialization sequence).
 */
static void AD9851_ResetSerial(void)
{
    AD9851_CLK_L();
    AD9851_FQ_L();

    /* RST pulse */
    AD9851_RST_L();
    AD9851_RST_H();
    AD9851_RST_L();

    /* W_CLK pulse (serial mode entry) */
    AD9851_CLK_L();
    AD9851_CLK_H();
    AD9851_CLK_L();

    /* FQ_UD pulse (serial mode entry) */
    AD9851_FQ_L();
    AD9851_FQ_H();
    AD9851_FQ_L();
}

/*============================================================================*/
/* Frequency conversion (identical to vendor code)                            */
/*============================================================================*/

/**
 * @brief  Convert real frequency (Hz) to 32-bit frequency tuning word
 * @param  freq: desired frequency in Hz
 * @retval 32-bit frequency tuning word
 * @note   FREQ_WORD = (freq × 2^32) / SYSCLK
 *         SYSCLK = 180 MHz (30 MHz crystal × 6× PLL)
 *         Factor = 2^32 / 180000000 = 23.860929422
 */
uint32_t AD9851_ConvertFreq(double freq)
{
    return (uint32_t)(freq * AD9851_FREQ_FACTOR);
}

/*============================================================================*/
/* Parallel mode: write 5 bytes (datasheet order: W0→W1→W2→W3→W4)           */
/*============================================================================*/

/**
 * @brief  Write frequency + phase to AD9851 in parallel mode
 * @note   Matches vendor's AD985x_wr_parrel() exactly:
 *          - W0 (control): phase<<3 | multiplier
 *          - W1-W4: freq[31:24], [23:16], [15:8], [7:0]
 *          - Data written to D0-D7 via BSRR, one W_CLK pulse per byte
 *          - FQ_UD pulse commits all data
 */
static void AD9851_WriteParallel(uint32_t freq_word, uint8_t phase)
{
    uint8_t w;

    /* ---- W0: control byte ---- */
    w = (uint8_t)((phase << 3) | AD9851_Multiplier);
    AD9851_DataBus(w);
    AD9851_CLK_H();
    AD9851_CLK_L();

    /* ---- W1: freq[31:24] ---- */
    w = (uint8_t)(freq_word >> 24);
    AD9851_DataBus(w);
    AD9851_CLK_H();
    AD9851_CLK_L();

    /* ---- W2: freq[23:16] ---- */
    w = (uint8_t)(freq_word >> 16);
    AD9851_DataBus(w);
    AD9851_CLK_H();
    AD9851_CLK_L();

    /* ---- W3: freq[15:8] ---- */
    w = (uint8_t)(freq_word >> 8);
    AD9851_DataBus(w);
    AD9851_CLK_H();
    AD9851_CLK_L();

    /* ---- W4: freq[7:0] ---- */
    w = (uint8_t)(freq_word);
    AD9851_DataBus(w);
    AD9851_CLK_H();
    AD9851_CLK_L();

    /* ---- FQ_UD pulse → commit ---- */
    AD9851_FQ_H();
    AD9851_FQ_L();
}

/*============================================================================*/
/* Serial mode: write 5 bytes (vendor order: W4→W3→W2→W1→W0, LSB first)    */
/*============================================================================*/

/**
 * @brief  Write frequency + phase to AD9851 in serial mode
 * @note   Matches vendor's AD985x_wr_serial() exactly:
 *          - Byte order:  W4 → W3 → W2 → W1 → W0
 *          - Bit order:   LSB first within each byte
 *          - Data shifted on D7 (PC7)
 *          - W_CLK toggles H→L per bit, FQ_UD pulse after all 40 bits
 *
 *          This is the PROVEN protocol that ships with the module.
 *          It differs from the datasheet but works with these modules.
 */
static void AD9851_WriteSerial(uint32_t freq_word, uint8_t phase)
{
    uint8_t i, byte_data;

    /*
     * Build the 5 bytes to send in vendor order: W4, W3, W2, W1, W0
     */
    uint8_t w4 = (uint8_t)(freq_word);           /* Freq [7:0]    — LSB */
    uint8_t w3 = (uint8_t)(freq_word >> 8);      /* Freq [15:8]   */
    uint8_t w2 = (uint8_t)(freq_word >> 16);     /* Freq [23:16]  */
    uint8_t w1 = (uint8_t)(freq_word >> 24);     /* Freq [31:24]  — MSB */
    uint8_t w0 = (uint8_t)((phase << 3) | AD9851_Multiplier);  /* Control */

    /*
     * Send each byte LSB-first, bit-by-bit on D7.
     * Bit i of byte_data goes out as: (byte_data >> i) & 0x01
     * This is EXACTLY how the vendor code does it.
     */

    /* ---- W4: freq[7:0] ---- */
    byte_data = w4;
    for (i = 0; i < 8; i++)
    {
        if ((byte_data >> i) & 0x01)
            AD9851_D7_H();
        else
            AD9851_D7_L();
        AD9851_CLK_H();
        AD9851_CLK_L();
    }

    /* ---- W3: freq[15:8] ---- */
    byte_data = w3;
    for (i = 0; i < 8; i++)
    {
        if ((byte_data >> i) & 0x01)
            AD9851_D7_H();
        else
            AD9851_D7_L();
        AD9851_CLK_H();
        AD9851_CLK_L();
    }

    /* ---- W2: freq[23:16] ---- */
    byte_data = w2;
    for (i = 0; i < 8; i++)
    {
        if ((byte_data >> i) & 0x01)
            AD9851_D7_H();
        else
            AD9851_D7_L();
        AD9851_CLK_H();
        AD9851_CLK_L();
    }

    /* ---- W1: freq[31:24] ---- */
    byte_data = w1;
    for (i = 0; i < 8; i++)
    {
        if ((byte_data >> i) & 0x01)
            AD9851_D7_H();
        else
            AD9851_D7_L();
        AD9851_CLK_H();
        AD9851_CLK_L();
    }

    /* ---- W0: control byte (phase + 6× PLL) ---- */
    byte_data = w0;
    for (i = 0; i < 8; i++)
    {
        if ((byte_data >> i) & 0x01)
            AD9851_D7_H();
        else
            AD9851_D7_L();
        AD9851_CLK_H();
        AD9851_CLK_L();
    }

    /* ---- FQ_UD pulse → commit all 40 bits ---- */
    AD9851_FQ_H();
    AD9851_FQ_L();
}

/*============================================================================*/
/* Public API                                                                 */
/*============================================================================*/

/**
 * @brief  Initialize AD9851: GPIO setup and chip reset
 * @param  mode: AD9851_MODE_PARALLEL (8-bit bus) or AD9851_MODE_SERIAL (3-wire)
 * @note   - AD9851 always uses 6× PLL (180 MHz system clock from 30 MHz crystal)
 *         - Serial mode: D0=1, D1=1, D2=0 asserted before reset (matches vendor)
 *         - After this call, the chip is ready — data can be written immediately
 */
void AD9851_Init(AD9851_Mode mode)
{
    AD9851_LoadMode   = mode;
    AD9851_Multiplier = AD9851_MUL_6X;           /* AD9851 always uses 6× PLL */
    AD9851_CurrPhase  = 0;

    AD9851_GPIO_Init();

    if (mode == AD9851_MODE_PARALLEL)
    {
        AD9851_ResetParallel();
    }
    else /* AD9851_MODE_SERIAL */
    {
        /*
         * Assert D0=1, D1=1, D2=0 BEFORE reset.
         * This configures the chip for serial operation
         * (identical to vendor code: D0=1; D1=1; D2=0; AD985x_reset_serial();)
         */
        AD9851_D0_H();
        AD9851_D1_H();
        AD9851_D2_L();
        AD9851_ResetSerial();
    }
}

/**
 * @brief  Set output frequency (Hz) and phase offset
 * @param  freq:  desired frequency in Hz (double, up to ~70 MHz practical)
 * @param  phase: phase offset (0-31), each step = 11.25°
 */
void AD9851_SetFreq_Phase(double freq, uint8_t phase)
{
    uint32_t freq_word;

    if (phase > 31) phase = 31;
    AD9851_CurrPhase = phase;

    freq_word = AD9851_ConvertFreq(freq);

    if (AD9851_LoadMode == AD9851_MODE_PARALLEL)
    {
        AD9851_WriteParallel(freq_word, phase);
    }
    else
    {
        AD9851_WriteSerial(freq_word, phase);
    }
}

/**
 * @brief  Set output frequency only (phase = 0)
 * @param  freq: desired frequency in Hz
 */
void AD9851_SetFrequency(double freq)
{
    AD9851_SetFreq_Phase(freq, 0);
}
