/**
 ******************************************************************************
 * @file    AD9851.h
 * @brief   AD9851 DDS waveform generator driver header
 * @note    AD9851 is a high-speed DDS chip from Analog Devices.
 *          - 180 MHz system clock (30 MHz crystal × built-in 6× PLL)
 *          - 32-bit frequency tuning word
 *          - 5-bit phase modulation (0-31, 11.25° per step)
 *          - Supports both parallel (8-bit) and serial (1-bit) data loading
 *
 *          Frequency formula:
 *            f_out = (FREQ_WORD × SYSCLK) / 2^32
 *            FREQ_WORD = (f_out × 2^32) / SYSCLK
 *
 *          Reference: vendor example code from 康威电子 (kvdz.taobao.com)
 ******************************************************************************
 */

#ifndef __AD9851_H
#define __AD9851_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/*============================================================================*/
/* User-configurable pin mapping                                              */
/*============================================================================*/

/* ---- Control pins ---- */
#define AD9851_RST_PORT         GPIOA
#define AD9851_RST_PIN          GPIO_PIN_6       /* PA6  — RESET  */

#define AD9851_CLK_PORT         GPIOA
#define AD9851_CLK_PIN          GPIO_PIN_4       /* PA4  — W_CLK  (write clock) */

#define AD9851_FQ_PORT          GPIOA
#define AD9851_FQ_PIN           GPIO_PIN_3       /* PA3  — FQ_UD  (frequency update) */

/* ---- 8-bit parallel data bus (PC0-PC7) ---- */
#define AD9851_DATA_PORT        GPIOC
/* PC0 = D0 (LSB), PC1 = D1, ..., PC7 = D7 (MSB, also used as serial data pin) */

/* ---- Pin-level macros (bit-band style via BSRR) ---- */
#define AD9851_RST_H()          (AD9851_RST_PORT->BSRR = AD9851_RST_PIN)
#define AD9851_RST_L()          (AD9851_RST_PORT->BSRR = (uint32_t)AD9851_RST_PIN << 16U)
#define AD9851_CLK_H()          (AD9851_CLK_PORT->BSRR = AD9851_CLK_PIN)
#define AD9851_CLK_L()          (AD9851_CLK_PORT->BSRR = (uint32_t)AD9851_CLK_PIN << 16U)
#define AD9851_FQ_H()           (AD9851_FQ_PORT->BSRR = AD9851_FQ_PIN)
#define AD9851_FQ_L()           (AD9851_FQ_PORT->BSRR = (uint32_t)AD9851_FQ_PIN << 16U)

/* ---- Parallel data bus write macro (write 8-bit value to PC0-PC7) ---- */
/* Uses BRR to reset low 8 bits first, then BSRR to set the new value */
#define AD9851_DataBus(w)       (AD9851_DATA_PORT->BSRR = ((uint32_t)((uint8_t)(w)) | \
                                                            ((uint32_t)((uint8_t)((w) ^ 0xFF)) << 16U)))

/* Macro to set only D7 bit (for serial mode) */
#define AD9851_D7_H()           (AD9851_DATA_PORT->BSRR = GPIO_PIN_7)
#define AD9851_D7_L()           (AD9851_DATA_PORT->BSRR = (uint32_t)GPIO_PIN_7 << 16U)

/* ---- D2/D1/D0 pins (must be set to 110 for serial mode) ---- */
#define AD9851_D0_H()           (AD9851_DATA_PORT->BSRR = GPIO_PIN_0)
#define AD9851_D0_L()           (AD9851_DATA_PORT->BSRR = (uint32_t)GPIO_PIN_0 << 16U)
#define AD9851_D1_H()           (AD9851_DATA_PORT->BSRR = GPIO_PIN_1)
#define AD9851_D1_L()           (AD9851_DATA_PORT->BSRR = (uint32_t)GPIO_PIN_1 << 16U)
#define AD9851_D2_H()           (AD9851_DATA_PORT->BSRR = GPIO_PIN_2)
#define AD9851_D2_L()           (AD9851_DATA_PORT->BSRR = (uint32_t)GPIO_PIN_2 << 16U)

/*============================================================================*/
/* AD9851 system constants                                                    */
/*============================================================================*/

#define AD9851_CLKIN            30000000UL       /* Onboard crystal: 30 MHz */
#define AD9851_SYSCLK           180000000UL      /* System clock after 6× PLL */

/* Frequency conversion factor: 2^32 / SYSCLK */
#define AD9851_FREQ_FACTOR      23.860929422

/* PLL multiplier settings */
#define AD9851_MUL_1X           0x00             /* 1× (bypass PLL — use for AD9850) */
#define AD9851_MUL_6X           0x01             /* 6× (default for AD9851) */

/*============================================================================*/
/* Data loading mode                                                           */
/*============================================================================*/

typedef enum
{
    AD9851_MODE_PARALLEL = 0,                    /* 8-bit parallel loading (faster) */
    AD9851_MODE_SERIAL   = 1                     /* 1-bit serial loading (fewer pins) */
} AD9851_Mode;

/*============================================================================*/
/* Function prototypes                                                        */
/*============================================================================*/

/**
 * @brief  Initialize AD9851 GPIO and reset the chip
 * @param  mode: parallel (AD9851_MODE_PARALLEL) or serial (AD9851_MODE_SERIAL)
 * @retval None
 */
void AD9851_Init(AD9851_Mode mode);

/**
 * @brief  Set output frequency (Hz) and phase offset
 * @param  freq:  desired frequency in Hz (0 to ~AD9851_SYSCLK/2)
 * @param  phase: phase offset (0-31), each step = 11.25°
 * @retval None
 * @note   Phase example: phase=8 means 8×11.25° = 90°
 */
void AD9851_SetFreq_Phase(double freq, uint8_t phase);

/**
 * @brief  Set output frequency only (phase unchanged as 0)
 * @param  freq: desired frequency in Hz
 * @retval None
 */
void AD9851_SetFrequency(double freq);

/**
 * @brief  Convert real frequency (Hz) to 32-bit frequency tuning word
 * @param  freq: frequency in Hz
 * @retval 32-bit frequency tuning word
 */
uint32_t AD9851_ConvertFreq(double freq);

#ifdef __cplusplus
}
#endif

#endif /* __AD9851_H */
