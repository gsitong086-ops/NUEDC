单独配置一路信号：
CLK0输出10.7M建议连接方法
SI5351A CLK0
      ↓
22～33 Ω串联电阻
      ↓
缓冲/放大（根据混频器要求决定）
      ↓
10.7 MHz低通或带通滤波器
      ↓
混频器LO

示波器输入：1 MΩ
探头：×10
耦合：DC

/* main.c 里,把 CHANNEL_0 换成想要的通道 */
切换其他通道修改SI5351_SetFrequency(SI5351_CHANNEL_0, 10700000UL);为SI5351_SetFrequency(SI5351_CHANNEL_1, 10700000UL);