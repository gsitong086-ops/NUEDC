/**
 * @file    oled.h
 * @brief   OLED 0.96" I2C 128x64 SSD1306 driver header
 * @note    Adapted for STM32F4 with I2C2 (hi2c2)
 */

#ifndef __OLED_H__
#define __OLED_H__

#include "main.h"
#include <stdlib.h>

/* ======================== OLED 参数 ======================== */
#define OLED_ADDR       0x78
#define OLED_WIDTH      128
#define OLED_HEIGHT     64
#define OLED_PAGES      8

/* ======================== 全局显存 ======================== */
extern uint8_t OLED_GRAM[OLED_WIDTH][OLED_PAGES];

/* ======================== 基础函数 ======================== */
void OLED_Init(void);
void OLED_Write_Command(uint8_t cData);
void OLED_Write_Data(uint8_t bData);
void OLED_Clear(void);
void OLED_Display_On(void);
void OLED_Display_Off(void);
void OLED_Set_Pos(uint8_t x, uint8_t y);
void OLED_Refresh(void);
uint32_t OLED_Pow(uint8_t m, uint8_t n);

/* ======================== 字符/字符串显示 ======================== */
void OLED_ShowChar(uint8_t x, uint8_t y, uint8_t chr, uint8_t char_size);
void OLED_ShowString(uint8_t x, uint8_t y, uint8_t *chr, uint8_t char_size);
int  OLED_ShowNum(uint8_t x, uint8_t y, uint32_t num, uint32_t len, uint8_t size2);
void OLED_ShowChinese(uint8_t x, uint8_t y, uint8_t no);

/* ======================== 像素级绘图函数 ======================== */
void OLED_DrawPoint(uint8_t x, uint8_t y, uint8_t mode);
void OLED_DrawLine(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1);

/* ======================== 坐标轴 & 曲线 ======================== */
void OLED_DrawAxis(uint8_t x, uint8_t y, uint8_t w, uint8_t h);
void OLED_DrawCurve(uint8_t *data, uint8_t len,
                    uint8_t x, uint8_t y, uint8_t w, uint8_t h,
                    uint8_t y_max);

/* ======================== 启动画面 ======================== */
void OLED_ShowStartup(void);

#endif /* __OLED_H__ */
