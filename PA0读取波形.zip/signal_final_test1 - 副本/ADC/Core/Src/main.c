/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define ADC_BUFFER_SIZE  2048     // DMA 双缓冲（2 × 1024）
#define HALF_BUF_SIZE    1024     // 半缓冲大小
#define ADC_REF_VOLTAGE  3.3f     // ADC 参考电压
#define ADC_MAX_VALUE    4095.0f  // 12 位 ADC 最大值

// ---- VOFA+ FireWater 波形输出 ----
// VOFA+ 设置：协议 = FireWater，波特率 = 115200
#define VOFA_BATCH_SIZE  150      // 每帧点数（150点≈900字节，适合115200）
#define VOFA_BUF_SIZE    1200     // 发送缓冲区
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
volatile uint8_t halfReady = 0;                   // 前半缓冲就绪标志
volatile uint8_t fullReady = 0;                   // 后半缓冲就绪标志
uint16_t adc_raw[ADC_BUFFER_SIZE] = {0};           // DMA 双缓冲
uint16_t adc_safe[HALF_BUF_SIZE];                  // 安全拷贝区（防止 DMA 撕裂）
char vofa_buf[VOFA_BUF_SIZE];                      // VOFA+ 发送缓冲
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

// ======================== VOFA+ FireWater 波形发送 ========================
// 从 adc_src 中均匀下采样 VOFA_BATCH_SIZE 个点 → 转电压值 → 串口发出
// VOFA+ 协议选 "FireWater"，数据格式：每行一个浮点数，\n 结尾
static void VOFA_SendWaveform(uint16_t *adc_src, uint16_t len)
{
    uint16_t step = len / VOFA_BATCH_SIZE;
    if (step < 1) step = 1;

    int total = 0;
    for (uint16_t i = 0; i < VOFA_BATCH_SIZE; i++)
    {
        float v = (float)adc_src[i * step] * ADC_REF_VOLTAGE / ADC_MAX_VALUE;
        int n = snprintf(vofa_buf + total, VOFA_BUF_SIZE - total,
                         "%.3f\n", v);
        if (n <= 0 || total + n >= VOFA_BUF_SIZE - 10) break;
        total += n;
    }

    HAL_UART_Transmit(&huart1, (uint8_t *)vofa_buf, total, HAL_MAX_DELAY);
}

// ======================== ADC DMA 半传输完成回调 ========================
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef *hadc)
{
    if (hadc == &hadc1) halfReady = 1;
}

// ======================== ADC DMA 全传输完成回调 ========================
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    if (hadc == &hadc1) fullReady = 1;
}

// ======================== printf 重定向（调试用，VOFA 模式下不使用）=====================
int fputc(int ch, FILE *f)
{
    while (__HAL_UART_GET_FLAG(&huart1, UART_FLAG_TXE) == RESET);
    HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
    return ch;
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_USART1_UART_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */

  // ---- ADC 自校准 ----
  if ((hadc1.Instance->CR2 & ADC_CR2_ADON) != 0)
      hadc1.Instance->CR2 &= ~ADC_CR2_ADON;
  hadc1.Instance->CR2 |= 0x00000008U;         // RSTCAL = 1
  while (hadc1.Instance->CR2 & 0x00000008U);   // 等待硬件清零
  hadc1.Instance->CR2 |= 0x00000004U;          // CAL = 1
  while (hadc1.Instance->CR2 & 0x00000004U);   // 等待校准完成

  // 启动 TIM3 触发 + ADC DMA 循环采集
  HAL_TIM_Base_Start(&htim3);
  HAL_ADC_Start_DMA(&hadc1, (uint32_t *)adc_raw, ADC_BUFFER_SIZE);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    // 前半缓冲就绪：立即拷贝到安全区（~50μs），防止 DMA 覆盖
    if (halfReady)
    {
      halfReady = 0;
      memcpy(adc_safe, adc_raw, HALF_BUF_SIZE * 2);
      VOFA_SendWaveform(adc_safe, HALF_BUF_SIZE);
    }

    // 后半缓冲就绪：同上
    if (fullReady)
    {
      fullReady = 0;
      memcpy(adc_safe, &adc_raw[HALF_BUF_SIZE], HALF_BUF_SIZE * 2);
      VOFA_SendWaveform(adc_safe, HALF_BUF_SIZE);
    }

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
