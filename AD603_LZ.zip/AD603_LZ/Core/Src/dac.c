/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    dac.c
  * @brief   This file provides code for the configuration
  *          of the DAC instances.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "dac.h"

/* USER CODE BEGIN 0 */

/* -------------------------------------------------------------------------- */
/* AD603 Gain Control — DAC reference voltage                                 */
/* -------------------------------------------------------------------------- */
#define VREF_MV         3300U   /* DAC reference voltage (measure VDDA pin)  */
#define AD603_MIN_GAIN  (-20)   /* Minimum gain (dB), Vg ≈ 2134mV            */
#define AD603_MAX_GAIN  (60)    /* Maximum gain (dB), Vg ≈ 134mV             */

/* USER CODE END 0 */

DAC_HandleTypeDef hdac;
DMA_HandleTypeDef hdma_dac1;

/* DAC init function */
void MX_DAC_Init(void)
{

  /* USER CODE BEGIN DAC_Init 0 */

  /* USER CODE END DAC_Init 0 */

  DAC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN DAC_Init 1 */

  /* USER CODE END DAC_Init 1 */

  /** DAC Initialization
  */
  hdac.Instance = DAC;
  if (HAL_DAC_Init(&hdac) != HAL_OK)
  {
    Error_Handler();
  }

  /** DAC channel OUT1 config
  */
  sConfig.DAC_Trigger = DAC_TRIGGER_NONE;
  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  if (HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DAC_Init 2 */

  /* Disable DMA and DMA underrun interrupt for Channel 1 (using software trigger) */
  CLEAR_BIT(hdac.Instance->CR, DAC_CR_DMAEN1);
  __HAL_DAC_DISABLE_IT(&hdac, DAC_IT_DMAUDR1);

  /* Start DAC Channel 1 immediately (DC output mode) */
  HAL_DAC_Start(&hdac, DAC_CHANNEL_1);

  /* USER CODE END DAC_Init 2 */

}

void HAL_DAC_MspInit(DAC_HandleTypeDef* dacHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(dacHandle->Instance==DAC)
  {
  /* USER CODE BEGIN DAC_MspInit 0 */

  /* USER CODE END DAC_MspInit 0 */
    /* DAC clock enable */
    __HAL_RCC_DAC_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**DAC GPIO Configuration
    PA4     ------> DAC_OUT1
    */
    GPIO_InitStruct.Pin = GPIO_PIN_4;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* DAC DMA Init */
    /* DAC1 Init */
    hdma_dac1.Instance = DMA1_Stream5;
    hdma_dac1.Init.Channel = DMA_CHANNEL_7;
    hdma_dac1.Init.Direction = DMA_MEMORY_TO_PERIPH;
    hdma_dac1.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_dac1.Init.MemInc = DMA_MINC_ENABLE;
    hdma_dac1.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    hdma_dac1.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    hdma_dac1.Init.Mode = DMA_CIRCULAR;
    hdma_dac1.Init.Priority = DMA_PRIORITY_LOW;
    hdma_dac1.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    if (HAL_DMA_Init(&hdma_dac1) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(dacHandle,DMA_Handle1,hdma_dac1);

  /* USER CODE BEGIN DAC_MspInit 1 */

  /* USER CODE END DAC_MspInit 1 */
  }
}

void HAL_DAC_MspDeInit(DAC_HandleTypeDef* dacHandle)
{

  if(dacHandle->Instance==DAC)
  {
  /* USER CODE BEGIN DAC_MspDeInit 0 */

  /* USER CODE END DAC_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_DAC_CLK_DISABLE();

    /**DAC GPIO Configuration
    PA4     ------> DAC_OUT1
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_4);

    /* DAC DMA DeInit */
    HAL_DMA_DeInit(dacHandle->DMA_Handle1);
  /* USER CODE BEGIN DAC_MspDeInit 1 */

  /* USER CODE END DAC_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */

/**
 * @brief  设置 AD603 增益，通过 DAC 通道1 输出对应直流电压。
 * @param  gain_db: 目标增益 (dB)，范围 [-20, 60]。
 * @retval 无
 * @note   参考 V4.1/V4.2 用户手册：
 *           理论推导（理想电路值）：
 *             VG = 0.567 - VDA/2           (VDA = DAC 输出电压, 单位 V)
 *             G(dB) = 40VG+10-6 + 40VG+10+6 = 80VG+20
 *                   = 80*(0.567 - VDA/2) + 20
 *                   = -40*VDA + 65.36      (VDA 单位 V)
 *           实测标定（实际测量）：
 *             G(dB) = -0.0458 * Vg(mV) + 64.539   (R² = 0.9997)
 *           反解（代码使用）：
 *             Vg(mV) = (64.539 - G) / 0.0402
 */
void AD603_SetGain(int8_t gain_db)
{
    int32_t voltage_mv;
    uint32_t digital;

    /* 限幅到有效增益范围 */
    if (gain_db < AD603_MIN_GAIN) gain_db = AD603_MIN_GAIN;
    if (gain_db > AD603_MAX_GAIN) gain_db = AD603_MAX_GAIN;

    /* 用 §5.2.3 实测标定公式计算 DAC 输出电压 (mV) */
    voltage_mv = (int32_t)((64.539f - (float)gain_db) / 0.0458f);

    /* 限幅到有效 Vg 范围 (手册: 134mV ~ 2134mV) */
    if (voltage_mv < 134)  voltage_mv = 134;
    if (voltage_mv > 2134) voltage_mv = 2134;

    /* mV 转为 12-bit DAC 码值 */
    digital = (uint32_t)voltage_mv * 4095UL / VREF_MV;

    /* 写入 DAC 通道1 */
    HAL_DAC_SetValue(&hdac, DAC_CHANNEL_1, DAC_ALIGN_12B_R, digital);
}

/* USER CODE END 1 */

