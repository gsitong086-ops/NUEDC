/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dac.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
#define ADC_SAMPLE_COUNT       400U
#define ADC_VDDA_MV            3300U
#define ADC_INPUT_SCALE_NUM    1U
#define ADC_INPUT_SCALE_DEN    1U

#define TARGET_VPP_LOW_MV      2160U
#define TARGET_VPP_HIGH_MV     2240U
#define SIGNAL_PRESENT_MV      100U

#define DAC_START_MV           0U
#define DAC_MIN_MV             0U
#define DAC_MAX_MV             1000U
#define CONTROL_WINDOW_DIVIDER 4U
#define PRINT_CONTROL_DIVIDER  4U

static uint16_t ADC_Value[ADC_SAMPLE_COUNT];
static volatile uint8_t dmaCompleteFlag = 0U;
static uint16_t dacControlMv = DAC_START_MV;
static uint32_t filteredVppMv = 0U;
static uint8_t controlWindowCount = 0U;
static uint8_t printControlCount = 0U;

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    if(hadc == &hadc1){
        dmaCompleteFlag = 1U;
    }
}

static uint32_t ADC_CalculateVppMv(const uint16_t *samples, uint16_t count)
{
    uint16_t adcMin = 4095U;
    uint16_t adcMax = 0U;

    for(uint16_t i = 0U; i < count; i++){
        if(samples[i] < adcMin){
            adcMin = samples[i];
        }
        if(samples[i] > adcMax){
            adcMax = samples[i];
        }
    }

    return (((uint32_t)(adcMax - adcMin) * ADC_VDDA_MV + 2047U) /
            4095U) * ADC_INPUT_SCALE_NUM / ADC_INPUT_SCALE_DEN;
}

static void DAC_ApplyControlMv(int32_t requestedMv)
{
    if(requestedMv < (int32_t)DAC_MIN_MV){
        requestedMv = DAC_MIN_MV;
    }
    if(requestedMv > (int32_t)DAC_MAX_MV){
        requestedMv = DAC_MAX_MV;
    }

    dacControlMv = (uint16_t)requestedMv;
    DAC_SetDC(dacControlMv);
}

static void AmplitudeControl_Update(uint32_t vppMv)
{
    int32_t stepMv = 0;

    if(vppMv < SIGNAL_PRESENT_MV){
        DAC_ApplyControlMv(0);
        return;
    }

    if(vppMv < 1800U){
        stepMv = 20;
    }
    else if(vppMv < 2100U){
        stepMv = 8;
    }
    else if(vppMv < TARGET_VPP_LOW_MV){
        stepMv = 2;
    }
    else if(vppMv > 2600U){
        stepMv = -20;
    }
    else if(vppMv > 2300U){
        stepMv = -8;
    }
    else if(vppMv > TARGET_VPP_HIGH_MV){
        stepMv = -2;
    }

    if(stepMv != 0){
        DAC_ApplyControlMv((int32_t)dacControlMv + stepMv);
    }
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_DAC_Init();
  MX_USART1_UART_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  /* USER CODE BEGIN 2 */
    {
        static const uint8_t startMessage[] = "START\r\n";
        HAL_UART_Transmit(&huart1, (uint8_t *)startMessage,
                          sizeof(startMessage) - 1U, 100U);
    }
    DAC_ApplyControlMv(DAC_START_MV);

    if(HAL_ADC_Start_DMA(&hadc1, (uint32_t *)ADC_Value, ADC_SAMPLE_COUNT) != HAL_OK){
        Error_Handler();
    }
    if(HAL_TIM_Base_Start(&htim3) != HAL_OK){
        Error_Handler();
    }
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    if(dmaCompleteFlag){
        uint32_t measuredVppMv;

        dmaCompleteFlag = 0U;
        HAL_TIM_Base_Stop(&htim3);
        HAL_ADC_Stop_DMA(&hadc1);

        measuredVppMv = ADC_CalculateVppMv(ADC_Value, ADC_SAMPLE_COUNT);
        if(filteredVppMv == 0U){
            filteredVppMv = measuredVppMv;
        }
        else{
            filteredVppMv = (3U * filteredVppMv + measuredVppMv + 2U) / 4U;
        }

        controlWindowCount++;
        if(controlWindowCount >= CONTROL_WINDOW_DIVIDER){
            controlWindowCount = 0U;
            AmplitudeControl_Update(filteredVppMv);

            printControlCount++;
            if(printControlCount >= PRINT_CONTROL_DIVIDER){
                printControlCount = 0U;
                char txBuffer[48];
                int txLength = snprintf(txBuffer, sizeof(txBuffer),
                                        "Vpp=%lu mV, DAC=%u mV\r\n",
                                        (unsigned long)filteredVppMv,
                                        (unsigned int)dacControlMv);
                if(txLength > 0){
                    HAL_UART_Transmit(&huart1, (uint8_t *)txBuffer,
                                      (uint16_t)txLength, 100U);
                }
            }
        }

        if(HAL_ADC_Start_DMA(&hadc1, (uint32_t *)ADC_Value, ADC_SAMPLE_COUNT) != HAL_OK){
            Error_Handler();
        }
        if(HAL_TIM_Base_Start(&htim3) != HAL_OK){
            Error_Handler();
        }
    }

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
int fputc(int c, FILE *stream)
{
    uint8_t ch = (uint8_t)c;
    (void)stream;
    HAL_UART_Transmit(&huart1, &ch, 1U, 0xFFFFU);
    return c;
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
