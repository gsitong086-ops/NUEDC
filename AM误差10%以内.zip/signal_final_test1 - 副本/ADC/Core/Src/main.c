/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <math.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define ADC_BUFFER_SIZE  2048     // DMA 双缓冲（2 × 1024）
#define HALF_BUF_SIZE    1024     // 半缓冲大小
#define ADC_REF_VOLTAGE  3.3f     // ADC 参考电压
#define ADC_MAX_VALUE    4095.0f  // 12 位 ADC 最大值

// ---- VOFA+ FireWater 波形输出 ----
// VOFA+ 设置：协议 = FireWater，波特率 = 115200
#define VOFA_BATCH_SIZE  150      // 每帧点数（150点≈900字节，适合115200）
#define VOFA_BUF_SIZE    1200     // 发送缓冲区
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
volatile uint8_t halfReady = 0;                   // 前半缓冲就绪标志
volatile uint8_t fullReady = 0;                   // 后半缓冲就绪标志
uint16_t adc_raw[ADC_BUFFER_SIZE] = {0};           // DMA 双缓冲
uint16_t adc_safe[HALF_BUF_SIZE];                  // 安全拷贝区（防止 DMA 撕裂）
char vofa_buf[VOFA_BUF_SIZE];                      // VOFA+ 发送缓冲
float mod_index = 0.0f;                            // AM 调制度 ma（平滑后，单位 %）
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

// ═══════════════ OLED SSD1306 软件 I2C 驱动 (SCL=PF1, SDA=PF0) ═══════════════
#define OLED_SCL_PORT   GPIOF
#define OLED_SCL_PIN    GPIO_PIN_1
#define OLED_SDA_PORT   GPIOF
#define OLED_SDA_PIN    GPIO_PIN_0
#define OLED_ADDR       0x78
#define OLED_WIDTH      128
#define OLED_HEIGHT     64
#define OLED_PAGES      (OLED_HEIGHT / 8)

static uint8_t oled_buf[OLED_WIDTH * OLED_PAGES];

#define SDA_H()   HAL_GPIO_WritePin(OLED_SDA_PORT, OLED_SDA_PIN, GPIO_PIN_SET)
#define SDA_L()   HAL_GPIO_WritePin(OLED_SDA_PORT, OLED_SDA_PIN, GPIO_PIN_RESET)
#define SCL_H()   HAL_GPIO_WritePin(OLED_SCL_PORT, OLED_SCL_PIN, GPIO_PIN_SET)
#define SCL_L()   HAL_GPIO_WritePin(OLED_SCL_PORT, OLED_SCL_PIN, GPIO_PIN_RESET)
#define SDA_IN()  {GPIOF->MODER &= ~(3<<(0*2)); GPIOF->MODER |= (0<<(0*2));}
#define SDA_OUT() {GPIOF->MODER &= ~(3<<(0*2)); GPIOF->MODER |= (1<<(0*2));}

static void i2c_dly(void)  { for(volatile int i=0;i<20;i++); }
static void i2c_start(void){ SDA_OUT(); SDA_H();SCL_H();i2c_dly();SDA_L();i2c_dly();SCL_L(); }
static void i2c_stop(void) { SDA_OUT(); SDA_L();SCL_H();i2c_dly();SDA_H();i2c_dly(); }
static uint8_t i2c_ack(void){ SDA_IN(); SCL_H();i2c_dly(); uint8_t a=(GPIOF->IDR&GPIO_PIN_0)?1:0; SCL_L();SDA_OUT(); return a; }
static void i2c_byte(uint8_t d){
    SDA_OUT();
    for(uint8_t i=0;i<8;i++){ if(d&0x80)SDA_H();else SDA_L(); d<<=1; SCL_H();i2c_dly();SCL_L();i2c_dly(); }
    i2c_ack();
}
static void oled_cmd(uint8_t c){ i2c_start();i2c_byte(OLED_ADDR);i2c_byte(0x00);i2c_byte(c);i2c_stop(); }
static void oled_dat(uint8_t d){ i2c_start();i2c_byte(OLED_ADDR);i2c_byte(0x40);i2c_byte(d);i2c_stop(); }

// 6x8 font (ASCII 32~126)
static const uint8_t f6x8[][6]={
    {0x00,0x00,0x00,0x00,0x00,0x00},{0x00,0x00,0x5F,0x00,0x00,0x00},
    {0x00,0x07,0x00,0x07,0x00,0x00},{0x14,0x7F,0x14,0x7F,0x14,0x00},
    {0x24,0x2A,0x7F,0x2A,0x12,0x00},{0x23,0x13,0x08,0x64,0x62,0x00},
    {0x36,0x49,0x55,0x22,0x50,0x00},{0x00,0x05,0x03,0x00,0x00,0x00},
    {0x00,0x1C,0x22,0x41,0x00,0x00},{0x00,0x41,0x22,0x1C,0x00,0x00},
    {0x08,0x2A,0x1C,0x2A,0x08,0x00},{0x08,0x08,0x3E,0x08,0x08,0x00},
    {0x00,0x50,0x30,0x00,0x00,0x00},{0x08,0x08,0x08,0x08,0x08,0x00},
    {0x00,0x60,0x60,0x00,0x00,0x00},{0x20,0x10,0x08,0x04,0x02,0x00},
    {0x3E,0x51,0x49,0x45,0x3E,0x00},{0x00,0x42,0x7F,0x40,0x00,0x00},
    {0x42,0x61,0x51,0x49,0x46,0x00},{0x21,0x41,0x45,0x4B,0x31,0x00},
    {0x18,0x14,0x12,0x7F,0x10,0x00},{0x27,0x45,0x45,0x45,0x39,0x00},
    {0x3C,0x4A,0x49,0x49,0x30,0x00},{0x01,0x71,0x09,0x05,0x03,0x00},
    {0x36,0x49,0x49,0x49,0x36,0x00},{0x06,0x49,0x49,0x29,0x1E,0x00},
    {0x00,0x36,0x36,0x00,0x00,0x00},{0x00,0x56,0x36,0x00,0x00,0x00},
    {0x00,0x08,0x14,0x22,0x41,0x00},{0x14,0x14,0x14,0x14,0x14,0x00},
    {0x41,0x22,0x14,0x08,0x00,0x00},{0x02,0x01,0x51,0x09,0x06,0x00},
    {0x32,0x49,0x79,0x41,0x3E,0x00},{0x7E,0x11,0x11,0x11,0x7E,0x00},
    {0x7F,0x49,0x49,0x49,0x36,0x00},{0x3E,0x41,0x41,0x41,0x22,0x00},
    {0x7F,0x41,0x41,0x22,0x1C,0x00},{0x7F,0x49,0x49,0x49,0x41,0x00},
    {0x7F,0x09,0x09,0x01,0x01,0x00},{0x3E,0x41,0x41,0x51,0x32,0x00},
    {0x7F,0x08,0x08,0x08,0x7F,0x00},{0x00,0x41,0x7F,0x41,0x00,0x00},
    {0x20,0x40,0x41,0x3F,0x01,0x00},{0x7F,0x08,0x14,0x22,0x41,0x00},
    {0x7F,0x40,0x40,0x40,0x40,0x00},{0x7F,0x02,0x04,0x02,0x7F,0x00},
    {0x7F,0x04,0x08,0x10,0x7F,0x00},{0x3E,0x41,0x41,0x41,0x3E,0x00},
    {0x7F,0x09,0x09,0x09,0x06,0x00},{0x3E,0x41,0x51,0x21,0x5E,0x00},
    {0x7F,0x09,0x19,0x29,0x46,0x00},{0x46,0x49,0x49,0x49,0x31,0x00},
    {0x01,0x01,0x7F,0x01,0x01,0x00},{0x3F,0x40,0x40,0x40,0x3F,0x00},
    {0x1F,0x20,0x40,0x20,0x1F,0x00},{0x7F,0x20,0x18,0x20,0x7F,0x00},
    {0x63,0x14,0x08,0x14,0x63,0x00},{0x03,0x04,0x78,0x04,0x03,0x00},
    {0x61,0x51,0x49,0x45,0x43,0x00},{0x00,0x00,0x7F,0x41,0x41,0x00},
    {0x02,0x04,0x08,0x10,0x20,0x00},{0x41,0x41,0x7F,0x00,0x00,0x00},
    {0x04,0x02,0x01,0x02,0x04,0x00},{0x40,0x40,0x40,0x40,0x40,0x00},
    {0x00,0x01,0x02,0x04,0x00,0x00},{0x20,0x54,0x54,0x54,0x78,0x00},
    {0x7F,0x48,0x44,0x44,0x38,0x00},{0x38,0x44,0x44,0x44,0x20,0x00},
    {0x38,0x44,0x44,0x48,0x7F,0x00},{0x38,0x54,0x54,0x54,0x18,0x00},
    {0x08,0x7E,0x09,0x01,0x02,0x00},{0x08,0x14,0x54,0x54,0x3C,0x00},
    {0x7F,0x08,0x04,0x04,0x78,0x00},{0x00,0x44,0x7D,0x40,0x00,0x00},
    {0x20,0x40,0x44,0x3D,0x00,0x00},{0x00,0x7F,0x10,0x28,0x44,0x00},
    {0x00,0x41,0x7F,0x40,0x00,0x00},{0x7C,0x04,0x18,0x04,0x78,0x00},
    {0x7C,0x08,0x04,0x04,0x78,0x00},{0x38,0x44,0x44,0x44,0x38,0x00},
    {0x7C,0x14,0x14,0x14,0x08,0x00},{0x08,0x14,0x14,0x18,0x7C,0x00},
    {0x7C,0x08,0x04,0x04,0x08,0x00},{0x48,0x54,0x54,0x54,0x20,0x00},
    {0x04,0x3F,0x44,0x40,0x20,0x00},{0x3C,0x40,0x40,0x20,0x7C,0x00},
    {0x1C,0x20,0x40,0x20,0x1C,0x00},{0x3C,0x40,0x30,0x40,0x3C,0x00},
    {0x44,0x28,0x10,0x28,0x44,0x00},{0x0C,0x50,0x50,0x50,0x3C,0x00},
    {0x44,0x64,0x54,0x4C,0x44,0x00},{0x00,0x08,0x36,0x41,0x00,0x00},
    {0x00,0x00,0x7F,0x00,0x00,0x00},{0x00,0x41,0x36,0x08,0x00,0x00},
    {0x08,0x04,0x08,0x10,0x08,0x00},
};

static void oled_px(uint8_t x,uint8_t y,uint8_t c){
    if(x>=OLED_WIDTH||y>=OLED_HEIGHT)return;
    uint8_t pg=y/8, bt=y%8;
    if(c) oled_buf[pg*OLED_WIDTH+x]|=(1<<bt);
    else  oled_buf[pg*OLED_WIDTH+x]&=~(1<<bt);
}
static void oled_ch(uint8_t x,uint8_t y,char ch){
    if(ch<32||ch>126)ch=' ';
    const uint8_t *p=f6x8[ch-32];
    for(uint8_t c=0;c<6;c++){ uint8_t ln=p[c];
        for(uint8_t r=0;r<8;r++) oled_px(x+c,y+r,(ln>>r)&1); }
}
static void oled_str(uint8_t x,uint8_t y,const char *s){
    while(*s){ oled_ch(x,y,*s); x+=6; if(x+6>OLED_WIDTH){x=0;y+=8;} s++; }
}
static void oled_flt(uint8_t x,uint8_t y,float v,uint8_t d){
    char b[16]; int ip=(int)v, fp=(int)((v-ip)*(d==1?10:(d==2?100:1000))+0.5f);
    if(fp<0)fp=-fp;
    if(d==1) snprintf(b,16,"%d.%01d",ip,fp);
    else if(d==2) snprintf(b,16,"%d.%02d",ip,fp);
    else snprintf(b,16,"%d",ip);
    oled_str(x,y,b);
}

static void OLED_Init(void){
    __HAL_RCC_GPIOF_CLK_ENABLE();
    GPIO_InitTypeDef g={0};
    g.Pin=OLED_SCL_PIN|OLED_SDA_PIN; g.Mode=GPIO_MODE_OUTPUT_OD;
    g.Pull=GPIO_PULLUP; g.Speed=GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOF,&g); SDA_H();SCL_H();
    HAL_Delay(100);
    oled_cmd(0xAE);oled_cmd(0xD5);oled_cmd(0x80);oled_cmd(0xA8);oled_cmd(0x3F);
    oled_cmd(0xD3);oled_cmd(0x00);oled_cmd(0x40);oled_cmd(0x8D);oled_cmd(0x14);
    oled_cmd(0x20);oled_cmd(0x00);oled_cmd(0xA1);oled_cmd(0xC8);oled_cmd(0xDA);
    oled_cmd(0x12);oled_cmd(0x81);oled_cmd(0xCF);oled_cmd(0xD9);oled_cmd(0xF1);
    oled_cmd(0xDB);oled_cmd(0x40);oled_cmd(0xA4);oled_cmd(0xA6);oled_cmd(0xAF);
    memset(oled_buf,0,sizeof(oled_buf));
    for(uint8_t pg=0;pg<OLED_PAGES;pg++){oled_cmd(0xB0+pg);oled_cmd(0x00);oled_cmd(0x10);
        i2c_start();i2c_byte(OLED_ADDR);i2c_byte(0x40);
        for(uint16_t c=0;c<OLED_WIDTH;c++) i2c_byte(oled_buf[pg*OLED_WIDTH+c]);
        i2c_stop();}
}
static void OLED_Clear(void){ memset(oled_buf,0,sizeof(oled_buf)); }
static void OLED_Refresh(void){
    for(uint8_t pg=0;pg<OLED_PAGES;pg++){oled_cmd(0xB0+pg);oled_cmd(0x00);oled_cmd(0x10);
        i2c_start();i2c_byte(OLED_ADDR);i2c_byte(0x40);
        for(uint16_t c=0;c<OLED_WIDTH;c++) i2c_byte(oled_buf[pg*OLED_WIDTH+c]);
        i2c_stop();}
}
// ═══════════════ OLED 驱动结束 ═══════════════

// ======================== AM 调制度计算（RMS 法）========================
// ma = sqrt(2) × RMS(AC) / DC × 100%
// 利用全部采样点计算，比峰值法更抗噪、更不受包络畸变影响
// 如需微调可修改 MA_CALIB（默认 1.00，50%读成60%时改为 50/60≈0.833）
#define MA_CALIB  1.00f
static float CalcModIndex(uint16_t *buf, uint16_t len)
{
    // DC 分量（均值）
    float sum = 0.0f;
    for (uint16_t i = 0; i < len; i++)
        sum += (float)buf[i];
    float dc = sum / (float)len;
    if (dc < 1.0f) return 0.0f;

    // AC 分量 RMS
    float sum_sq = 0.0f;
    for (uint16_t i = 0; i < len; i++)
    {
        float ac = (float)buf[i] - dc;
        sum_sq += ac * ac;
    }
    float rms = sqrtf(sum_sq / (float)len);

    // 正弦包络: ma = sqrt(2) × Vrms(ac) / Vdc
    return 1.41421356f * rms / dc * 100.0f * MA_CALIB;
}

// ======================== VOFA+ FireWater 波形发送 ========================
// 从 adc_src 中均匀下采样 VOFA_BATCH_SIZE 个点 → 转电压值 → 串口发出
// VOFA+ 协议选 "FireWater"，数据格式：每行一个浮点数，\n 结尾
static void VOFA_SendWaveform(uint16_t *adc_src, uint16_t len)
{
    uint16_t step = len / VOFA_BATCH_SIZE;
    if (step < 1) step = 1;

    int total = 0;
    for (uint16_t i = 0; i < VOFA_BATCH_SIZE; i++)
    {
        float v = (float)adc_src[i * step] * ADC_REF_VOLTAGE / ADC_MAX_VALUE;
        int n = snprintf(vofa_buf + total, VOFA_BUF_SIZE - total,
                         "%.3f\n", v);
        if (n <= 0 || total + n >= VOFA_BUF_SIZE - 10) break;
        total += n;
    }

    HAL_UART_Transmit(&huart1, (uint8_t *)vofa_buf, total, HAL_MAX_DELAY);
}

// ======================== ADC DMA 半传输完成回调 ========================
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef *hadc)
{
    if (hadc == &hadc1) halfReady = 1;
}

// ======================== ADC DMA 全传输完成回调 ========================
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    if (hadc == &hadc1) fullReady = 1;
}

// ======================== printf 重定向（调试用，VOFA 模式下不使用）=====================
int fputc(int ch, FILE *f)
{
    while (__HAL_UART_GET_FLAG(&huart1, UART_FLAG_TXE) == RESET);
    HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
    return ch;
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_USART1_UART_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */

  // ---- ADC 自校准 ----
  if ((hadc1.Instance->CR2 & ADC_CR2_ADON) != 0)
      hadc1.Instance->CR2 &= ~ADC_CR2_ADON;
  hadc1.Instance->CR2 |= 0x00000008U;         // RSTCAL = 1
  while (hadc1.Instance->CR2 & 0x00000008U);   // 等待硬件清零
  hadc1.Instance->CR2 |= 0x00000004U;          // CAL = 1
  while (hadc1.Instance->CR2 & 0x00000004U);   // 等待校准完成

  // 启动 TIM3 触发 + ADC DMA 循环采集
  HAL_TIM_Base_Start(&htim3);
  HAL_ADC_Start_DMA(&hadc1, (uint32_t *)adc_raw, ADC_BUFFER_SIZE);

  // OLED 初始化
  OLED_Init();
  oled_str(0, 0, "Modulation Index");
  oled_str(0, 16, "  waiting...");
  OLED_Refresh();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    // 前半缓冲就绪：立即拷贝到安全区（~50μs），防止 DMA 覆盖
    if (halfReady)
    {
      halfReady = 0;
      memcpy(adc_safe, adc_raw, HALF_BUF_SIZE * 2);

      // 计算 AM 调制度（EMA 平滑，显示更稳定）
      float m_now = CalcModIndex(adc_safe, HALF_BUF_SIZE);
      mod_index = mod_index * 0.7f + m_now * 0.3f;

      // 更新 OLED 显示
      OLED_Clear();
      oled_str(0, 0, "Modulation Index");
      oled_flt(0, 20, mod_index, 1);
      oled_str(42, 20, "%");
      OLED_Refresh();

      VOFA_SendWaveform(adc_safe, HALF_BUF_SIZE);
    }

    // 后半缓冲就绪：同上
    if (fullReady)
    {
      fullReady = 0;
      memcpy(adc_safe, &adc_raw[HALF_BUF_SIZE], HALF_BUF_SIZE * 2);

      // 计算 AM 调制度
      float m_now = CalcModIndex(adc_safe, HALF_BUF_SIZE);
      mod_index = mod_index * 0.7f + m_now * 0.3f;

      // 更新 OLED 显示
      OLED_Clear();
      oled_str(0, 0, "Modulation Index");
      oled_flt(0, 20, mod_index, 1);
      oled_str(42, 20, "%");
      OLED_Refresh();

      VOFA_SendWaveform(adc_safe, HALF_BUF_SIZE);
    }

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
