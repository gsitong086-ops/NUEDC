/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "AD9833.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define ADC_BUFFER_SIZE  2048
#define HALF_BUF_SIZE    1024
#define ADC_REF_VOLTAGE  3.3f
#define ADC_MAX_VALUE    4095.0f
#define SAMPLE_RATE      700000.0f   // ADC 采样率 Hz
#define FREQ_RES          (SAMPLE_RATE / HALF_BUF_SIZE)  // ≈683.6 Hz/bin

// VOFA+
#define VOFA_BATCH_SIZE  150
#define VOFA_BUF_SIZE    1200

// 调制度校准
#define MA_CALIB         1.00f

// ---- 测量模式 ----
#define MEASURE_FM       1        // 0=AM(包络检波)  1=FM(NE564鉴频)
// FFT 测频
#define FFT_SIZE         1024
#define M_PI             3.14159265358979323846f
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
volatile uint8_t halfReady = 0;
volatile uint8_t fullReady = 0;
uint16_t adc_raw[ADC_BUFFER_SIZE] = {0};
uint16_t adc_safe[HALF_BUF_SIZE];
char vofa_buf[VOFA_BUF_SIZE];
float mod_index = 0.0f;    // AM 调制度 ma（%）
float freq_hz   = 0.0f;    // 调制频率 fm（Hz，EMA平滑）
float fm_raw    = 0.0f;    // fm 原始值
float df_peak_hz= 0.0f;    // 峰值频偏 Δf（Hz）
float f_if_hz    = 15000.0f;// 中频频率 Hz
float f_dev_rms  = 0.0f;    // 频偏 RMS Hz（FM_Demodulate 实测）
uint8_t oled_tick = 0;     // OLED 刷新分频
float dds_last_f = 0.0f;   // AD9833 上次写入频率
// FFT 缓冲
float fft_r[FFT_SIZE], fft_i[FFT_SIZE], fft_m[FFT_SIZE/2];
float hann[FFT_SIZE]; uint8_t hann_ok = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

// ═══════════════ OLED SSD1306 (SCL=PF1, SDA=PF0) ═══════════════
#define OLED_SCL_PORT   GPIOF
#define OLED_SCL_PIN    GPIO_PIN_1
#define OLED_SDA_PORT   GPIOF
#define OLED_SDA_PIN    GPIO_PIN_0
#define OLED_ADDR       0x78
#define OLED_WIDTH      128
#define OLED_HEIGHT     64
#define OLED_PAGES      (OLED_HEIGHT / 8)

static uint8_t oled_buf[OLED_WIDTH * OLED_PAGES];

#define SDA_H()   HAL_GPIO_WritePin(OLED_SDA_PORT, OLED_SDA_PIN, GPIO_PIN_SET)
#define SDA_L()   HAL_GPIO_WritePin(OLED_SDA_PORT, OLED_SDA_PIN, GPIO_PIN_RESET)
#define SCL_H()   HAL_GPIO_WritePin(OLED_SCL_PORT, OLED_SCL_PIN, GPIO_PIN_SET)
#define SCL_L()   HAL_GPIO_WritePin(OLED_SCL_PORT, OLED_SCL_PIN, GPIO_PIN_RESET)
#define SDA_IN()  {GPIOF->MODER &= ~(3<<(0*2)); GPIOF->MODER |= (0<<(0*2));}
#define SDA_OUT() {GPIOF->MODER &= ~(3<<(0*2)); GPIOF->MODER |= (1<<(0*2));}

static void i2c_dly(void)  { for(volatile int i=0;i<20;i++); }
static void i2c_start(void){ SDA_OUT(); SDA_H();SCL_H();i2c_dly();SDA_L();i2c_dly();SCL_L(); }
static void i2c_stop(void) { SDA_OUT(); SDA_L();SCL_H();i2c_dly();SDA_H();i2c_dly(); }
static uint8_t i2c_ack(void){ SDA_IN(); SCL_H();i2c_dly(); uint8_t a=(GPIOF->IDR&GPIO_PIN_0)?1:0; SCL_L();SDA_OUT(); return a; }
static void i2c_byte(uint8_t d){
    SDA_OUT();
    for(uint8_t i=0;i<8;i++){ if(d&0x80)SDA_H();else SDA_L(); d<<=1; SCL_H();i2c_dly();SCL_L();i2c_dly(); }
    i2c_ack();
}
static void oled_cmd(uint8_t c){ i2c_start();i2c_byte(OLED_ADDR);i2c_byte(0x00);i2c_byte(c);i2c_stop(); }
static void oled_dat(uint8_t d){ i2c_start();i2c_byte(OLED_ADDR);i2c_byte(0x40);i2c_byte(d);i2c_stop(); }

static const uint8_t f6x8[][6]={
    {0x00,0x00,0x00,0x00,0x00,0x00},{0x00,0x00,0x5F,0x00,0x00,0x00},
    {0x00,0x07,0x00,0x07,0x00,0x00},{0x14,0x7F,0x14,0x7F,0x14,0x00},
    {0x24,0x2A,0x7F,0x2A,0x12,0x00},{0x23,0x13,0x08,0x64,0x62,0x00},
    {0x36,0x49,0x55,0x22,0x50,0x00},{0x00,0x05,0x03,0x00,0x00,0x00},
    {0x00,0x1C,0x22,0x41,0x00,0x00},{0x00,0x41,0x22,0x1C,0x00,0x00},
    {0x08,0x2A,0x1C,0x2A,0x08,0x00},{0x08,0x08,0x3E,0x08,0x08,0x00},
    {0x00,0x50,0x30,0x00,0x00,0x00},{0x08,0x08,0x08,0x08,0x08,0x00},
    {0x00,0x60,0x60,0x00,0x00,0x00},{0x20,0x10,0x08,0x04,0x02,0x00},
    {0x3E,0x51,0x49,0x45,0x3E,0x00},{0x00,0x42,0x7F,0x40,0x00,0x00},
    {0x42,0x61,0x51,0x49,0x46,0x00},{0x21,0x41,0x45,0x4B,0x31,0x00},
    {0x18,0x14,0x12,0x7F,0x10,0x00},{0x27,0x45,0x45,0x45,0x39,0x00},
    {0x3C,0x4A,0x49,0x49,0x30,0x00},{0x01,0x71,0x09,0x05,0x03,0x00},
    {0x36,0x49,0x49,0x49,0x36,0x00},{0x06,0x49,0x49,0x29,0x1E,0x00},
    {0x00,0x36,0x36,0x00,0x00,0x00},{0x00,0x56,0x36,0x00,0x00,0x00},
    {0x00,0x08,0x14,0x22,0x41,0x00},{0x14,0x14,0x14,0x14,0x14,0x00},
    {0x41,0x22,0x14,0x08,0x00,0x00},{0x02,0x01,0x51,0x09,0x06,0x00},
    {0x32,0x49,0x79,0x41,0x3E,0x00},{0x7E,0x11,0x11,0x11,0x7E,0x00},
    {0x7F,0x49,0x49,0x49,0x36,0x00},{0x3E,0x41,0x41,0x41,0x22,0x00},
    {0x7F,0x41,0x41,0x22,0x1C,0x00},{0x7F,0x49,0x49,0x49,0x41,0x00},
    {0x7F,0x09,0x09,0x01,0x01,0x00},{0x3E,0x41,0x41,0x51,0x32,0x00},
    {0x7F,0x08,0x08,0x08,0x7F,0x00},{0x00,0x41,0x7F,0x41,0x00,0x00},
    {0x20,0x40,0x41,0x3F,0x01,0x00},{0x7F,0x08,0x14,0x22,0x41,0x00},
    {0x7F,0x40,0x40,0x40,0x40,0x00},{0x7F,0x02,0x04,0x02,0x7F,0x00},
    {0x7F,0x04,0x08,0x10,0x7F,0x00},{0x3E,0x41,0x41,0x41,0x3E,0x00},
    {0x7F,0x09,0x09,0x09,0x06,0x00},{0x3E,0x41,0x51,0x21,0x5E,0x00},
    {0x7F,0x09,0x19,0x29,0x46,0x00},{0x46,0x49,0x49,0x49,0x31,0x00},
    {0x01,0x01,0x7F,0x01,0x01,0x00},{0x3F,0x40,0x40,0x40,0x3F,0x00},
    {0x1F,0x20,0x40,0x20,0x1F,0x00},{0x7F,0x20,0x18,0x20,0x7F,0x00},
    {0x63,0x14,0x08,0x14,0x63,0x00},{0x03,0x04,0x78,0x04,0x03,0x00},
    {0x61,0x51,0x49,0x45,0x43,0x00},{0x00,0x00,0x7F,0x41,0x41,0x00},
    {0x02,0x04,0x08,0x10,0x20,0x00},{0x41,0x41,0x7F,0x00,0x00,0x00},
    {0x04,0x02,0x01,0x02,0x04,0x00},{0x40,0x40,0x40,0x40,0x40,0x00},
    {0x00,0x01,0x02,0x04,0x00,0x00},{0x20,0x54,0x54,0x54,0x78,0x00},
    {0x7F,0x48,0x44,0x44,0x38,0x00},{0x38,0x44,0x44,0x44,0x20,0x00},
    {0x38,0x44,0x44,0x48,0x7F,0x00},{0x38,0x54,0x54,0x54,0x18,0x00},
    {0x08,0x7E,0x09,0x01,0x02,0x00},{0x08,0x14,0x54,0x54,0x3C,0x00},
    {0x7F,0x08,0x04,0x04,0x78,0x00},{0x00,0x44,0x7D,0x40,0x00,0x00},
    {0x20,0x40,0x44,0x3D,0x00,0x00},{0x00,0x7F,0x10,0x28,0x44,0x00},
    {0x00,0x41,0x7F,0x40,0x00,0x00},{0x7C,0x04,0x18,0x04,0x78,0x00},
    {0x7C,0x08,0x04,0x04,0x78,0x00},{0x38,0x44,0x44,0x44,0x38,0x00},
    {0x7C,0x14,0x14,0x14,0x08,0x00},{0x08,0x14,0x14,0x18,0x7C,0x00},
    {0x7C,0x08,0x04,0x04,0x08,0x00},{0x48,0x54,0x54,0x54,0x20,0x00},
    {0x04,0x3F,0x44,0x40,0x20,0x00},{0x3C,0x40,0x40,0x20,0x7C,0x00},
    {0x1C,0x20,0x40,0x20,0x1C,0x00},{0x3C,0x40,0x30,0x40,0x3C,0x00},
    {0x44,0x28,0x10,0x28,0x44,0x00},{0x0C,0x50,0x50,0x50,0x3C,0x00},
    {0x44,0x64,0x54,0x4C,0x44,0x00},{0x00,0x08,0x36,0x41,0x00,0x00},
    {0x00,0x00,0x7F,0x00,0x00,0x00},{0x00,0x41,0x36,0x08,0x00,0x00},
    {0x08,0x04,0x08,0x10,0x08,0x00},
};

static void oled_px(uint8_t x,uint8_t y,uint8_t c){
    if(x>=OLED_WIDTH||y>=OLED_HEIGHT)return;
    uint8_t pg=y/8, bt=y%8;
    if(c) oled_buf[pg*OLED_WIDTH+x]|=(1<<bt);
    else  oled_buf[pg*OLED_WIDTH+x]&=~(1<<bt);
}
static void oled_ch(uint8_t x,uint8_t y,char ch){
    if(ch<32||ch>126)ch=' ';
    const uint8_t *p=f6x8[ch-32];
    for(uint8_t c=0;c<6;c++){ uint8_t ln=p[c];
        for(uint8_t r=0;r<8;r++) oled_px(x+c,y+r,(ln>>r)&1); }
}
static void oled_str(uint8_t x,uint8_t y,const char *s){
    while(*s){ oled_ch(x,y,*s); x+=6; if(x+6>OLED_WIDTH){x=0;y+=8;} s++; }
}
static void oled_flt(uint8_t x,uint8_t y,float v,uint8_t d){
    char b[16]; int ip=(int)v, fp=(int)((v-ip)*(d==1?10:(d==2?100:1000))+0.5f);
    if(fp<0)fp=-fp;
    if(d==1) snprintf(b,16,"%d.%01d",ip,fp);
    else if(d==2) snprintf(b,16,"%d.%02d",ip,fp);
    else snprintf(b,16,"%d",ip);
    oled_str(x,y,b);
}
static void OLED_Init(void){
    __HAL_RCC_GPIOF_CLK_ENABLE();
    GPIO_InitTypeDef g={0};
    g.Pin=OLED_SCL_PIN|OLED_SDA_PIN; g.Mode=GPIO_MODE_OUTPUT_OD;
    g.Pull=GPIO_PULLUP; g.Speed=GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOF,&g); SDA_H();SCL_H();
    HAL_Delay(100);
    oled_cmd(0xAE);oled_cmd(0xD5);oled_cmd(0x80);oled_cmd(0xA8);oled_cmd(0x3F);
    oled_cmd(0xD3);oled_cmd(0x00);oled_cmd(0x40);oled_cmd(0x8D);oled_cmd(0x14);
    oled_cmd(0x20);oled_cmd(0x00);oled_cmd(0xA1);oled_cmd(0xC8);oled_cmd(0xDA);
    oled_cmd(0x12);oled_cmd(0x81);oled_cmd(0xCF);oled_cmd(0xD9);oled_cmd(0xF1);
    oled_cmd(0xDB);oled_cmd(0x40);oled_cmd(0xA4);oled_cmd(0xA6);oled_cmd(0xAF);
    memset(oled_buf,0,sizeof(oled_buf));
    for(uint8_t pg=0;pg<OLED_PAGES;pg++){oled_cmd(0xB0+pg);oled_cmd(0x00);oled_cmd(0x10);
        i2c_start();i2c_byte(OLED_ADDR);i2c_byte(0x40);
        for(uint16_t c=0;c<OLED_WIDTH;c++) i2c_byte(oled_buf[pg*OLED_WIDTH+c]);
        i2c_stop();}
}
static void OLED_Clear(void){ memset(oled_buf,0,sizeof(oled_buf)); }
static void OLED_Refresh(void){
    for(uint8_t pg=0;pg<OLED_PAGES;pg++){oled_cmd(0xB0+pg);oled_cmd(0x00);oled_cmd(0x10);
        i2c_start();i2c_byte(OLED_ADDR);i2c_byte(0x40);
        for(uint16_t c=0;c<OLED_WIDTH;c++) i2c_byte(oled_buf[pg*OLED_WIDTH+c]);
        i2c_stop();}
}

// ======================== AM 调制度（RMS 法）========================
static float CalcModIndex(uint16_t *buf, uint16_t len)
{
    float sum = 0.0f;
    for (uint16_t i = 0; i < len; i++) sum += (float)buf[i];
    float dc = sum / (float)len;
    if (dc < 1.0f) return 0.0f;

    float sum_sq = 0.0f;
    for (uint16_t i = 0; i < len; i++) {
        float ac = (float)buf[i] - dc;
        sum_sq += ac * ac;
    }
    float rms = sqrtf(sum_sq / (float)len);
    return 1.41421356f * rms / dc * 100.0f * MA_CALIB;
}

// ======================== FM 软件鉴频（过零频率计法）========================
// 测每个中频周期 → 瞬时频率 → 频偏即调制信号
// 输入 buf[] 原地替换为解调后的调制信号（ADC量程）
static void FM_Demodulate(uint16_t *buf, uint16_t len)
{
    // 过零基准 = 中值
    float sum = 0.0f;
    for (uint16_t i = 0; i < len; i++) sum += (float)buf[i];
    float dc = sum / len;

    // 找所有上升过零点 + 线性插值精确定位（亚样本精度）
    float zc_f[300]; uint16_t n = 0;
    uint8_t below = (buf[0] < dc) ? 1 : 0;
    for (uint16_t i = 1; i < len && n < 300; i++) {
        uint8_t cur = (buf[i] < dc) ? 1 : 0;
        if (below && !cur) {
            float frac = (dc - (float)buf[i-1]) / (float)(buf[i] - buf[i-1]);
            zc_f[n++] = (float)(i - 1) + frac;
        }
        below = cur;
    }
    if (n < 3) return;

    // 多周期平均测频（10个IF周期一组，不重叠，误差降10倍）
    #define FM_AVG 10
    uint16_t m = 0;
    for (uint16_t i = 0; i + FM_AVG < n; i += FM_AVG) {
        fft_i[m++] = (float)FM_AVG * SAMPLE_RATE / (zc_f[i+FM_AVG] - zc_f[i]);
    }
    if (m < 3) return;

    // 平均 IF（中心频率）
    float f_if = 0.0f;
    for (uint16_t i = 0; i < m; i++) f_if += fft_i[i];
    f_if /= m;
    if (f_if < 1000.0f) return;
    f_if_hz = f_if;

    // 直接从瞬时频率算频偏 RMS
    float dev_sum_sq = 0.0f;
    for (uint16_t i = 0; i < m; i++) {
        float d = fft_i[i] - f_if;
        dev_sum_sq += d * d;
    }
    f_dev_rms = sqrtf(dev_sum_sq / (float)m);

    // 频偏 → 缩放到 ADC 量程（仅用于VOFA+显示解调波形）
    float scale = 2048.0f / (f_if * 2.00f);

    // 插值回原始采样网格（fft_i[k]位置 = zc_f[k*FM_AVG]）
    uint16_t zi = 0;
    for (uint16_t i = 0; i < len; i++) {
        while (zi + 1 < m && zc_f[(zi + 1) * FM_AVG] <= (float)i) zi++;
        float df = fft_i[zi] - f_if;
        int16_t v = (int16_t)(2048.0f + df * scale);
        fft_r[i] = (float)(v < 0 ? 0 : (v > 4095 ? 4095 : v));
    }

    // 32点滑动平均 → 滤除插值阶梯/中频伪影（corner≈3.5kHz @700k采样）
    #define FM_MA 32
    float mas = 0.0f;
    for (uint16_t i = 0; i < FM_MA && i < len; i++) mas += fft_r[i];
    for (uint16_t i = 0; i < len; i++) {
        float avg = mas / (float)FM_MA;
        int16_t v = (int16_t)(avg + 0.5f);
        buf[i] = (uint16_t)(v < 0 ? 0 : (v > 4095 ? 4095 : v));
        mas -= fft_r[i];
        if (i + FM_MA < len) mas += fft_r[i + FM_MA];
    }
}

// 获取 AC 分量 RMS（ADC 原始单位，FM 计算用）
static float GetRMS_AC(uint16_t *buf, uint16_t len)
{
    float sum = 0.0f;
    for (uint16_t i = 0; i < len; i++) sum += (float)buf[i];
    float dc = sum / (float)len;
    float sum_sq = 0.0f;
    for (uint16_t i = 0; i < len; i++) {
        float ac = (float)buf[i] - dc;
        sum_sq += ac * ac;
    }
    return sqrtf(sum_sq / (float)len);
}

// ======================== FFT（Radix-2 DIT, 1024点）========================
static void InitHann(void){
    for(uint16_t i=0;i<FFT_SIZE;i++) hann[i]=0.5f*(1.0f-cosf(2.0f*M_PI*i/(FFT_SIZE-1)));
    hann_ok=1;
}
static void BitRev(float *r,float *im,uint16_t n){
    uint16_t i,j=0;
    for(i=1;i<n;i++){uint16_t b=n>>1;for(;j&b;b>>=1)j^=b;j^=b;
        if(i<j){float tr=r[i];r[i]=r[j];r[j]=tr;tr=im[i];im[i]=im[j];im[j]=tr;}}
}
static void FFT_R2(float *r,float *im,uint16_t n){
    BitRev(r,im,n);
    for(uint16_t s=1;(1u<<s)<=n;s++){uint16_t m=1u<<s;
        float wR=cosf(2.0f*M_PI/m),wI=-sinf(2.0f*M_PI/m);
        for(uint16_t k=0;k<n;k+=m){float wr=1.0f,wi=0.0f;
            for(uint16_t j=0;j<m/2;j++){uint16_t a=k+j,b=k+j+m/2;
                float tR=wr*r[b]-wi*im[b],tI=wr*im[b]+wi*r[b];
                r[b]=r[a]-tR; im[b]=im[a]-tI; r[a]=r[a]+tR; im[a]=im[a]+tI;
                float nR=wr*wR-wi*wI; wi=wr*wI+wi*wR; wr=nR;}}}
}
static void MagSpec(float *r,float *im,float *mag,uint16_t n){
    mag[0]=sqrtf(r[0]*r[0]+im[0]*im[0])/n;
    for(uint16_t i=1;i<n/2;i++) mag[i]=sqrtf(r[i]*r[i]+im[i]*im[i])*2.0f/n;
}
// ======================== 调制频率（FFT + 抛物线插值）========================
static float CalcFreq(uint16_t *buf, uint16_t len)
{
    if(!hann_ok) InitHann();
    float sum=0.0f;
    for(uint16_t i=0;i<len;i++) sum+=(float)buf[i];
    float dc=sum/len;
    for(uint16_t i=0;i<len;i++){fft_r[i]=((float)buf[i]-dc)*hann[i]; fft_i[i]=0.0f;}
    FFT_R2(fft_r,fft_i,FFT_SIZE);
    MagSpec(fft_r,fft_i,fft_m,FFT_SIZE);

    // FM: fm在3~5kHz，搜2k~6k；AM: 200Hz~20kHz
#if MEASURE_FM
    float res=SAMPLE_RATE/FFT_SIZE;
    uint16_t lo=(uint16_t)(2000.0f/res+0.5f), hi=(uint16_t)(6000.0f/res+0.5f);
#else
    float res=SAMPLE_RATE/FFT_SIZE;
    uint16_t lo=(uint16_t)(200.0f/res+0.5f), hi=(uint16_t)(20000.0f/res+0.5f);
#endif
    if(hi>FFT_SIZE/2) hi=FFT_SIZE/2;
    float mx=0.0f; uint16_t bi=lo;
    for(uint16_t i=lo;i<=hi;i++){if(fft_m[i]>mx){mx=fft_m[i];bi=i;}}
    if(bi<1||bi>=FFT_SIZE/2-1) return 0.0f;

    // 3点抛物线插值: delta = (y[+1]-y[-1]) / (2*(2*y[0]-y[-1]-y[+1]))
    float ym=fft_m[bi-1], y0=fft_m[bi], yp=fft_m[bi+1];
    float denom=2.0f*(2.0f*y0-ym-yp);
    float delta=(fabsf(denom)<1e-12f)?0.0f:(yp-ym)/denom;
    if(delta>0.5f)delta=0.5f; if(delta<-0.5f)delta=-0.5f;
    return ((float)bi+delta)*res;
}

// ======================== VOFA+ FireWater 波形发送 ========================
static void VOFA_SendWaveform(uint16_t *adc_src, uint16_t len)
{
    uint16_t step = len / VOFA_BATCH_SIZE;
    if (step < 1) step = 1;
    int total = 0;
    for (uint16_t i = 0; i < VOFA_BATCH_SIZE; i++) {
        float v = (float)adc_src[i * step] * ADC_REF_VOLTAGE / ADC_MAX_VALUE;
        int n = snprintf(vofa_buf + total, VOFA_BUF_SIZE - total, "%.3f\n", v);
        if (n <= 0 || total + n >= VOFA_BUF_SIZE - 10) break;
        total += n;
    }
    HAL_UART_Transmit(&huart1, (uint8_t *)vofa_buf, total, HAL_MAX_DELAY);
}

// ======================== ADC DMA 回调 ========================
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef *hadc)
{ if (hadc == &hadc1) halfReady = 1; }

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{ if (hadc == &hadc1) fullReady = 1; }

// ======================== printf 重定向 ========================
int fputc(int ch, FILE *f)
{
    while (__HAL_UART_GET_FLAG(&huart1, UART_FLAG_TXE) == RESET);
    HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
    return ch;
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_USART1_UART_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */

  // ADC 自校准
  if ((hadc1.Instance->CR2 & ADC_CR2_ADON) != 0)
      hadc1.Instance->CR2 &= ~ADC_CR2_ADON;
  hadc1.Instance->CR2 |= 0x00000008U;
  while (hadc1.Instance->CR2 & 0x00000008U);
  hadc1.Instance->CR2 |= 0x00000004U;
  while (hadc1.Instance->CR2 & 0x00000004U);

  HAL_TIM_Base_Start(&htim3);
  HAL_ADC_Start_DMA(&hadc1, (uint32_t *)adc_raw, ADC_BUFFER_SIZE);

  // AD9833A 初始化（PB0=FSYNC, PB1=SCLK, PB2=SDATA）
  AD9833_Reset(AD9833A_PORT, AD9833A_FSYNC_PIN, AD9833A_SCLK_PIN, AD9833A_SDATA_PIN);
  HAL_Delay(1);
  AD9833_ClearReset(AD9833A_PORT, AD9833A_FSYNC_PIN, AD9833A_SCLK_PIN, AD9833A_SDATA_PIN);
  HAL_Delay(1);
  AD9833_SetFrequencyQuick(1000.0f, AD9833_OUT_SINUS,
      AD9833A_PORT, AD9833A_FSYNC_PIN, AD9833A_SCLK_PIN, AD9833A_SDATA_PIN);

  // OLED
  OLED_Init();
#if MEASURE_FM
  oled_str(0, 0, "mf:");
#else
  oled_str(0, 0, "ma:");
#endif
#if MEASURE_FM
  freq_hz = 4000.0f;  // FM 初始值，避免从0爬升
#endif
  oled_str(0, 24, "fm:");
  OLED_Refresh();
  OLED_Clear();  // 进主循环前清掉启动标签

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    if (halfReady)
    {
      halfReady = 0;
      memcpy(adc_safe, adc_raw, HALF_BUF_SIZE * 2);

      // FM: 先鉴频再测；AM: 直接测
#if MEASURE_FM
      FM_Demodulate(adc_safe, HALF_BUF_SIZE);
#endif
      float fm_now = CalcFreq(adc_safe, HALF_BUF_SIZE);
#if MEASURE_FM
      freq_hz = freq_hz * 0.95f + fm_now * 0.05f;  // FM 更稳
#else
      freq_hz = freq_hz * 0.7f + fm_now * 0.3f;
#endif

#if MEASURE_FM
      float df_peak = 1.41421356f * f_dev_rms;  // 直接从过零频率计取频偏
      float m_now = (freq_hz > 1.0f) ? df_peak / freq_hz : 0.0f;
      mod_index = mod_index * 0.85f + m_now * 0.15f;
      fm_raw = fm_now;                              // 原始 fm
      df_peak_hz = df_peak_hz * 0.7f + df_peak * 0.3f; // Δf EMA
#else
      float m_now = CalcModIndex(adc_safe, HALF_BUF_SIZE);
      mod_index = mod_index * 0.7f + m_now * 0.3f;
#endif

      // AD9833A 频率追踪（变化 >3Hz 才更新）
      if (freq_hz > 10.0f && (freq_hz - dds_last_f > 3.0f || dds_last_f - freq_hz > 3.0f)) {
          AD9833_SetFrequencyQuick(freq_hz, AD9833_OUT_SINUS,
              AD9833A_PORT, AD9833A_FSYNC_PIN, AD9833A_SCLK_PIN, AD9833A_SDATA_PIN);
          dds_last_f = freq_hz;
      }

      // OLED 每4帧刷新一次（不闪）
      if (++oled_tick >= 4) { oled_tick = 0; }
      if (oled_tick == 0) {
#if MEASURE_FM
      oled_str(0, 0, "mf:");
      oled_flt(24, 0, mod_index, 2);
      oled_str(0, 16, "df:");
      oled_flt(24, 16, df_peak_hz / 1000.0f, 2);
      oled_str(66, 16, "kHz");
      oled_str(0, 32, "fm:");
      oled_flt(24, 32, freq_hz / 1000.0f, 2);
      oled_str(66, 32, "kHz");
#else
      oled_str(0, 0, "ma:");
      oled_flt(24, 0, mod_index, 1);
      oled_str(60, 0, "%");
      oled_str(0, 24, "fm:");
      if (freq_hz < 1000.0f)
          oled_flt(24, 24, freq_hz, 1);
      else {
          oled_flt(24, 24, freq_hz / 1000.0f, 2);
          oled_str(66, 24, "kHz");
      }
#endif
      OLED_Refresh();
      }  // oled_tick==0 block end

      VOFA_SendWaveform(adc_safe, HALF_BUF_SIZE);
    }

    if (fullReady)
    {
      fullReady = 0;
      memcpy(adc_safe, &adc_raw[HALF_BUF_SIZE], HALF_BUF_SIZE * 2);

#if MEASURE_FM
      FM_Demodulate(adc_safe, HALF_BUF_SIZE);
#endif
      float fm_now = CalcFreq(adc_safe, HALF_BUF_SIZE);
#if MEASURE_FM
      freq_hz = freq_hz * 0.95f + fm_now * 0.05f;  // FM 更稳
#else
      freq_hz = freq_hz * 0.7f + fm_now * 0.3f;
#endif

#if MEASURE_FM
      float df_peak = 1.41421356f * f_dev_rms;  // 直接从过零频率计取频偏
      float m_now = (freq_hz > 1.0f) ? df_peak / freq_hz : 0.0f;
      mod_index = mod_index * 0.85f + m_now * 0.15f;
      fm_raw = fm_now;
      df_peak_hz = df_peak_hz * 0.7f + df_peak * 0.3f;
#else
      float m_now = CalcModIndex(adc_safe, HALF_BUF_SIZE);
      mod_index = mod_index * 0.7f + m_now * 0.3f;
#endif

      // AD9833A 频率追踪（每帧更新）
      if (freq_hz > 10.0f) {
          AD9833_SetFrequencyQuick(freq_hz, AD9833_OUT_SINUS,
              AD9833A_PORT, AD9833A_FSYNC_PIN, AD9833A_SCLK_PIN, AD9833A_SDATA_PIN);
      }

#if MEASURE_FM
      oled_str(0, 0, "mf:");
      oled_flt(24, 0, mod_index, 2);
      oled_str(0, 16, "df:");
      oled_flt(24, 16, df_peak_hz / 1000.0f, 2);
      oled_str(66, 16, "kHz");
      oled_str(0, 32, "fm:");
      oled_flt(24, 32, freq_hz / 1000.0f, 2);
      oled_str(66, 32, "kHz");
#else
      oled_str(0, 0, "ma:");
      oled_flt(24, 0, mod_index, 1);
      oled_str(60, 0, "%");
      oled_str(0, 24, "fm:");
      if (freq_hz < 1000.0f)
          oled_flt(24, 24, freq_hz, 1);
      else {
          oled_flt(24, 24, freq_hz / 1000.0f, 2);
          oled_str(66, 24, "kHz");
      }
#endif
      OLED_Refresh();

      VOFA_SendWaveform(adc_safe, HALF_BUF_SIZE);
    }

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    Error_Handler();

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
    Error_Handler();
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

void Error_Handler(void)
{
  __disable_irq();
  while (1) { }
}
#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{ }
#endif
