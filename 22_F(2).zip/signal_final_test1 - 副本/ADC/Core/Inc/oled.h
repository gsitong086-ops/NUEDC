#ifndef __OLED_H__
#define __OLED_H__

#include "main.h"

/* OLED 引脚定义 — 软件 I2C */
#define OLED_SCL_PORT   GPIOF
#define OLED_SCL_PIN    GPIO_PIN_1
#define OLED_SDA_PORT   GPIOF
#define OLED_SDA_PIN    GPIO_PIN_0

/* SSD1306 参数 */
#define OLED_ADDR       0x78   // 7-bit=0x3C, 左移1位=0x78
#define OLED_WIDTH      128
#define OLED_HEIGHT     64
#define OLED_PAGES      (OLED_HEIGHT / 8)

/* 公开接口 */
void OLED_Init(void);
void OLED_Clear(void);
void OLED_Refresh(void);
void OLED_ShowString(uint8_t x, uint8_t y, const char *str);
void OLED_ShowFloat(uint8_t x, uint8_t y, float val, uint8_t decimal);

#endif
