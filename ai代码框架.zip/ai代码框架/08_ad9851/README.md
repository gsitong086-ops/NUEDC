# 08_ad9851 - AD9851 DDS频率合成模块驱动

## 功能概述

AD9851是ADI公司的DDS（直接数字频率合成）芯片，180MHz最高参考时钟，输出频率范围 **0 ~ 70MHz**，频率分辨率约 **0.04Hz**。本驱动支持单频输出、FSK调制和扫频三种工作模式。

## 工作原理

```
参考时钟 180MHz → AD9851 DDS核心 → 10位DAC → 低通滤波 → 正弦波输出
                     ↑
            频率控制字 FTW (32bit)
            相位控制字 (5bit)
            FTW = f_out × 2^32 / 180MHz
```

## 文件列表

| 文件 | 说明 |
|------|------|
| `ad9851.h` | 头文件：句柄结构体、宏定义、接口声明 |
| `ad9851.c` | 源文件：频率设置、FSK、扫频、硬件通信 |

## 硬件接线 (并行模式)

| AD9851引脚 | STM32引脚 | 说明 |
|-----------|-----------|------|
| D0~D7 | GPIOA0~7 | 8位数据总线 |
| W_CLK | GPIOB0 | 写时钟 |
| FQ_UD | GPIOB1 | 频率更新 |
| RESET | GPIOB2 | 复位 |
| FSK/BPSK | GPIOB3 | FSK频率选择 (可选) |

## 40位控制字格式

```
发送顺序 (W0先发, LSB first):
┌─────────────────────────────────────────┬──────┬─────────┬──────┐
│  W0 ~ W31: 频率控制字 FTW (32bit)        │ W32  │W33~W37  │W38~39│
│  f_out × 2^32 / 180M                    │省电   │相位5bit │保留=0│
└─────────────────────────────────────────┴──────┴─────────┴──────┘
```

### 频率计算公式

```
FTW = f_out × 2^32 / f_clk

示例：
  f_out = 1MHz → FTW = 1e6 × 2^32 / 180e6 = 23,860,930
  f_out = 10MHz → FTW = 10e6 × 2^32 / 180e6 = 238,609,294
```

### 相位计算公式

```
Phase_word = phase(deg) × 32 / 360

示例：
  phase = 0° → Phase_word = 0
  phase = 90° → Phase_word = 8
  phase = 180° → Phase_word = 16
```

## 使用示例

```c
#include "ad9851.h"

AD9851_Handle dds;

// 初始化 (默认输出1MHz)
AD9851_Init(&dds);

// === 单频模式 ===
AD9851_SetFreq(&dds, 10000000.0f, 0.0f);  // 10MHz, 0°相位

// === FSK模式 ===
AD9851_SetFSK(&dds, 1000000.0f, 1100000.0f, 0.0f);  // 1MHz/1.1MHz
// 在定时器中断中切换
AD9851_FSK_Select(&dds, 1);  // 切换到1.1MHz
AD9851_FSK_Select(&dds, 0);  // 切换回1MHz

// === 扫频模式 ===
AD9851_Sweep_Config(&dds, 100000.0f, 10000000.0f, 10000.0f, 10.0f);
//  起始100kHz, 终止10MHz, 步进10kHz, 每步10ms
AD9851_Sweep_Start(&dds);

// 在主循环或定时器中断中定期调用
while (sweep_running) {
    AD9851_Sweep_Process(&dds);
    HAL_Delay(10);  // 等于驻留时间
}

// === 省电模式 ===
AD9851_PowerDown(&dds, 1);   // 进入省电
AD9851_PowerDown(&dds, 0);   // 恢复正常
```

## 接口说明

| 函数 | 说明 |
|------|------|
| `AD9851_Init(h)` | 初始化模块，输出默认1MHz |
| `AD9851_SetFreq(h, freq, phase)` | 设置单频输出 |
| `AD9851_SetFSK(h, f1, f2, phase)` | 配置FSK双频 |
| `AD9851_FSK_Select(h, select)` | FSK频率切换 |
| `AD9851_Sweep_Config(h, start, stop, step, dwell)` | 配置扫频参数 |
| `AD9851_Sweep_Start(h)` | 启动扫频 |
| `AD9851_Sweep_Stop(h)` | 停止扫频 |
| `AD9851_Sweep_Process(h)` | 扫频步进处理 |
| `AD9851_PowerDown(h, en)` | 省电控制 |
| `AD9851_Reset()` | 硬件复位 |

## 电赛应用场景

| 场景 | 用法 |
|------|------|
| **信号发生器** | 单频输出作为激励源 |
| **阻抗测量** | 扫频 + AD630解调 → 频率响应曲线 |
| **滤波器测试** | 扫频输出 + ADC采集 → 幅频特性 |
| **FSK通信** | 二进制数据调制 |
| **外差式接收** | 作为本振信号 |

## 频率精度

```
180MHz时钟: 分辨率 = 180M / 2^32 ≈ 0.0419 Hz
30MHz有源晶振×6倍频: 分辨率 ≈ 0.007 Hz
```

## 注意事项

1. **输出需要低通滤波**：DDS输出有量化噪声和镜像频率，需在输出端加7阶椭圆低通滤波器（截止频率约70MHz）
2. **GPIO速度**：数据总线GPIO需配置为最高速度（Very High）
3. **扫频定时**：建议在定时器中断中调用 `AD9851_Sweep_Process()`，定时周期 = dwell_ms
4. **FSK切换**：如果使用FSK引脚硬件切换，无需软件参与

## 依赖

- `dsp_common.h` (更新 `g_params.ad9851_*`)
- HAL库 (GPIO)
- `math.h`
