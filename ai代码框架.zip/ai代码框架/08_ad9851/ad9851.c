/**
 * @file    ad9851.c
 * @brief   AD9851 DDS频率合成模块驱动实现
 * 
 * 控制字格式 (40位，W0先发送):
 *   W0~W31: 频率控制字 FTW (32bit, LSB first)
 *   W32: 省电控制 (1=省电)
 *   W33~W37: 相位控制字 (5bit)
 *   W38~W39: 保留 (写0)
 * 
 * 频率计算公式:
 *   FTW = f_out × 2^32 / f_clk
 *   f_out = FTW × f_clk / 2^32
 * 
 * 相位计算公式:
 *   Phase_word = phase(deg) × 2^5 / 360
 */

#include "ad9851.h"
#include <math.h>

/* ================================================================
 * GPIO引脚定义 (需根据实际接线修改)
 * ================================================================ */

/* 数据总线 D0~D7 使用 GPIOA 低8位 */
#define AD9851_DATA_PORT    GPIOA
#define AD9851_DATA_PIN_MASK 0x00FF

/* 控制引脚 */
#define AD9851_WCLK_PORT    GPIOB
#define AD9851_WCLK_PIN     GPIO_PIN_0
#define AD9851_FQUD_PORT    GPIOB
#define AD9851_FQUD_PIN     GPIO_PIN_1
#define AD9851_RESET_PORT   GPIOB
#define AD9851_RESET_PIN    GPIO_PIN_2

/* FSK选择引脚 (可选) */
#define AD9851_FSK_PORT     GPIOB
#define AD9851_FSK_PIN      GPIO_PIN_3

/* ================================================================
 * 宏：控制引脚操作
 * ================================================================ */
#define WCLK_H()    HAL_GPIO_WritePin(AD9851_WCLK_PORT,  AD9851_WCLK_PIN,  GPIO_PIN_SET)
#define WCLK_L()    HAL_GPIO_WritePin(AD9851_WCLK_PORT,  AD9851_WCLK_PIN,  GPIO_PIN_RESET)
#define FQUD_H()    HAL_GPIO_WritePin(AD9851_FQUD_PORT,  AD9851_FQUD_PIN,  GPIO_PIN_SET)
#define FQUD_L()    HAL_GPIO_WritePin(AD9851_FQUD_PORT,  AD9851_FQUD_PIN,  GPIO_PIN_RESET)
#define RESET_H()   HAL_GPIO_WritePin(AD9851_RESET_PORT, AD9851_RESET_PIN, GPIO_PIN_SET)
#define RESET_L()   HAL_GPIO_WritePin(AD9851_RESET_PORT, AD9851_RESET_PIN, GPIO_PIN_RESET)
#define FSK_H()     HAL_GPIO_WritePin(AD9851_FSK_PORT,   AD9851_FSK_PIN,   GPIO_PIN_SET)
#define FSK_L()     HAL_GPIO_WritePin(AD9851_FSK_PORT,   AD9851_FSK_PIN,   GPIO_PIN_RESET)

/* ================================================================
 * 静态函数声明
 * ================================================================ */
static void AD9851_WriteByte(uint8_t data);
static void AD9851_SendControlWord(uint32_t ftw, uint8_t phase, uint8_t power_down);
static uint32_t AD9851_CalcFTW(float freq);

/* ================================================================
 * 初始化
 * ================================================================ */

/**
 * @brief  初始化AD9851模块
 */
void AD9851_Init(AD9851_Handle *h)
{
    /* GPIO初始化已在CubeMX中完成，此处仅做软件初始化 */

    /* 复位DDS芯片 */
    AD9851_Reset();

    h->mode          = AD9851_MODE_SINGLE_TONE;
    h->freq          = 1000000.0f;   /* 默认 1MHz */
    h->phase         = 0.0f;
    h->fsk_freq      = 1100000.0f;
    h->fsk_select    = 0;
    h->power_down    = 0;
    h->sweep_running = 0;
    h->initialized   = 1;

    /* 输出默认频率 */
    AD9851_SetFreq(h, h->freq, h->phase);

    /* 同步全局参数 */
    g_params.ad9851_freq  = h->freq;
    g_params.ad9851_phase = h->phase;
}

/* ================================================================
 * 单频输出
 * ================================================================ */

/**
 * @brief  设置输出频率和相位
 */
int AD9851_SetFreq(AD9851_Handle *h, float freq, float phase)
{
    if (!h->initialized) return -1;
    if (freq < AD9851_FREQ_MIN || freq > AD9851_FREQ_MAX) return -1;
    if (phase < 0.0f || phase > 360.0f) return -1;

    /* 计算频率控制字 */
    uint32_t ftw = AD9851_CalcFTW(freq);

    /* 计算相位控制字 (5bit) */
    uint8_t phase_word = (uint8_t)(phase * 32.0f / 360.0f) & 0x1F;

    /* 发送控制字 */
    AD9851_SendControlWord(ftw, phase_word, h->power_down);

    h->mode  = AD9851_MODE_SINGLE_TONE;
    h->freq  = freq;
    h->phase = phase;

    /* 更新全局参数 */
    g_params.ad9851_freq  = h->freq;
    g_params.ad9851_phase = h->phase;

    return 0;
}

/* ================================================================
 * FSK调制
 * ================================================================ */

/**
 * @brief  设置FSK双频率
 */
int AD9851_SetFSK(AD9851_Handle *h, float freq1, float freq2, float phase)
{
    if (!h->initialized) return -1;

    h->freq     = freq1;
    h->fsk_freq = freq2;
    h->phase    = phase;
    h->mode     = AD9851_MODE_FSK;
    h->fsk_select = 0;

    /* 先输出主频率 */
    AD9851_SetFreq(h, freq1, phase);

    g_params.ad9851_mode     = h->mode;
    g_params.ad9851_fsk_freq = h->fsk_freq;

    return 0;
}

/**
 * @brief  FSK频率切换
 */
void AD9851_FSK_Select(AD9851_Handle *h, uint8_t select)
{
    if (!h->initialized) return;

    if (select) {
        /* 切换到FSK频率 */
        uint32_t ftw = AD9851_CalcFTW(h->fsk_freq);
        uint8_t phase_word = (uint8_t)(h->phase * 32.0f / 360.0f) & 0x1F;
        AD9851_SendControlWord(ftw, phase_word, h->power_down);
    } else {
        /* 切换到主频率 */
        uint32_t ftw = AD9851_CalcFTW(h->freq);
        uint8_t phase_word = (uint8_t)(h->phase * 32.0f / 360.0f) & 0x1F;
        AD9851_SendControlWord(ftw, phase_word, h->power_down);
    }

    h->fsk_select = select;
}

/* ================================================================
 * 扫频模式
 * ================================================================ */

/**
 * @brief  配置扫频参数
 */
int AD9851_Sweep_Config(AD9851_Handle *h, float start_freq, float stop_freq,
                        float step_freq, float dwell_ms)
{
    if (!h->initialized) return -1;
    if (start_freq < AD9851_FREQ_MIN || stop_freq > AD9851_FREQ_MAX) return -1;
    if (step_freq <= 0.0f) return -1;

    h->mode          = AD9851_MODE_SWEEP;
    h->sweep_start   = start_freq;
    h->sweep_stop    = stop_freq;
    h->sweep_step    = step_freq;
    h->sweep_dwell   = dwell_ms;
    h->sweep_current = start_freq;
    h->sweep_dir     = 0;  /* 正向 */
    h->sweep_running = 0;

    /* 更新全局参数 */
    g_params.ad9851_mode        = h->mode;
    g_params.ad9851_sweep_start = h->sweep_start;
    g_params.ad9851_sweep_stop  = h->sweep_stop;
    g_params.ad9851_sweep_step  = h->sweep_step;
    g_params.ad9851_sweep_dwell = h->sweep_dwell;

    return 0;
}

/**
 * @brief  启动扫频
 */
void AD9851_Sweep_Start(AD9851_Handle *h)
{
    if (!h->initialized) return;

    h->sweep_current = h->sweep_start;
    h->sweep_dir     = 0;
    h->sweep_running = 1;

    /* 输出起始频率 */
    AD9851_SetFreq(h, h->sweep_start, h->phase);
}

/**
 * @brief  停止扫频
 */
void AD9851_Sweep_Stop(AD9851_Handle *h)
{
    h->sweep_running = 0;
}

/**
 * @brief  扫频处理 (需在定时器中断或主循环中定期调用)
 * 
 * @note   建议在定时器中断中调用，定时周期 = dwell_ms
 *         或者记录上次切换时间，在主循环中检查是否到达驻留时间
 */
void AD9851_Sweep_Process(AD9851_Handle *h)
{
    if (!h->initialized || !h->sweep_running) return;

    /* 计算下一频率 */
    float next_freq;
    if (h->sweep_dir == 0) {
        /* 正向扫频 */
        next_freq = h->sweep_current + h->sweep_step;
        if (next_freq > h->sweep_stop) {
            next_freq = h->sweep_stop;
            h->sweep_dir = 1;  /* 反向 */
        }
    } else {
        /* 反向扫频 */
        next_freq = h->sweep_current - h->sweep_step;
        if (next_freq < h->sweep_start) {
            next_freq = h->sweep_start;
            h->sweep_dir = 0;  /* 正向 */
        }
    }

    /* 更新频率 */
    AD9851_SetFreq(h, next_freq, h->phase);
    h->sweep_current = next_freq;
}

/* ================================================================
 * 省电模式
 * ================================================================ */

/**
 * @brief  进入/退出省电模式
 */
void AD9851_PowerDown(AD9851_Handle *h, uint8_t en)
{
    if (!h->initialized) return;

    h->power_down = en;

    /* 重新发送控制字 (保持频率不变) */
    uint32_t ftw = AD9851_CalcFTW(h->freq);
    uint8_t phase_word = (uint8_t)(h->phase * 32.0f / 360.0f) & 0x1F;
    AD9851_SendControlWord(ftw, phase_word, en);

    g_params.ad9851_power_down = en;
}

/* ================================================================
 * 硬件控制函数
 * ================================================================ */

/**
 * @brief  复位AD9851
 */
void AD9851_Reset(void)
{
    RESET_H();
    HAL_Delay(1);       /* 至少5个REFCLK周期 */
    RESET_L();
    HAL_Delay(1);
}

/**
 * @brief  向AD9851发送一个字节 (并行模式)
 * @param  data  8位数据
 * 
 * 时序: 数据准备好 → W_CLK上升沿锁存
 */
static void AD9851_WriteByte(uint8_t data)
{
    /* 将数据放到数据总线 D0~D7 */
    GPIOA->ODR = (GPIOA->ODR & ~AD9851_DATA_PIN_MASK) | data;

    /* 产生写脉冲 */
    WCLK_H();
    /* 延迟约10ns (168MHz下约2个NOP) */
    __NOP(); __NOP();
    WCLK_L();
    __NOP(); __NOP();
}

/**
 * @brief  发送40位控制字
 * @param  ftw         32位频率控制字
 * @param  phase       5位相位控制字
 * @param  power_down  省电位
 * 
 * 发送顺序 (W0 first):
 *   先发 W0~W31 (频率控制字，LSB first)
 *   再发 W32 (省电) + W33~W37 (相位) + W38~W39 (保留=0)
 */
static void AD9851_SendControlWord(uint32_t ftw, uint8_t phase, uint8_t power_down)
{
    uint8_t i;

    /* 发送 W0~W31: 频率控制字 (32bit, LSB first) */
    for (i = 0; i < 4; i++) {
        AD9851_WriteByte((uint8_t)(ftw >> (i * 8)));
    }

    /* 发送 W32~W39: 控制字节 */
    /* [W32]=power_down, [W33~W37]=phase, [W38~W39]=00 */
    uint8_t ctrl_byte = (power_down & 0x01) | ((phase & 0x1F) << 1);
    AD9851_WriteByte(ctrl_byte);

    /* 产生频率更新脉冲 */
    FQUD_H();
    __NOP(); __NOP(); __NOP(); __NOP();
    FQUD_L();
}

/**
 * @brief  计算频率控制字
 * @param  freq  目标频率 (Hz)
 * @return 32位频率控制字
 */
static uint32_t AD9851_CalcFTW(float freq)
{
    /* FTW = f_out × 2^32 / f_clk */
    double ftw = (double)freq * 4294967296.0 / AD9851_CLK_FREQ;

    if (ftw > 4294967295.0) ftw = 4294967295.0;
    if (ftw < 0.0) ftw = 0.0;

    return (uint32_t)ftw;
}
