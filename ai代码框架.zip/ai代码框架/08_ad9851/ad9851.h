/**
 * @file    ad9851.h
 * @brief   AD9851 DDS频率合成模块驱动
 * @author  电赛DSP通用库
 * @date    2025-07
 * 
 * AD9851是ADI公司的DDS频率合成器芯片，180MHz最大时钟，
 * 输出频率范围 0 ~ 70MHz，频率分辨率 0.04Hz @ 180MHz时钟。
 * 
 * 本驱动支持：
 *   - 单频输出模式
 *   - FSK调制模式
 *   - 扫频模式
 *   - 省电模式
 * 
 * 硬件接线 (并行模式)：
 *   STM32 GPIO → AD9851 D0~D7  (8位数据总线)
 *   STM32 GPIO → AD9851 W_CLK   (写时钟)
 *   STM32 GPIO → AD9851 FQ_UD   (频率更新)
 *   STM32 GPIO → AD9851 RESET   (复位)
 * 
 * 控制字格式 (40位)：
 *   [W0~W31: 频率控制字(32bit)] [W32~W36: 相位(5bit)] [W37: 省电] [W38~W39: 保留]
 *   频率控制字 = f_out × 2^32 / f_clk
 *   相位偏移 = phase(deg) × 2^5 / 360
 */

#ifndef __AD9851_H
#define __AD9851_H

#include "dsp_common.h"

/* ================================================================
 * 配置宏
 * ================================================================ */
#define AD9851_CLK_FREQ     180000000.0f    // AD9851参考时钟 (Hz)，取决于外部晶振
#define AD9851_FREQ_MIN     1.0f            // 最小输出频率 (Hz)
#define AD9851_FREQ_MAX     70000000.0f     // 最大输出频率 (Hz)
#define AD9851_FREQ_RES     (AD9851_CLK_FREQ / 4294967296.0)  // 频率分辨率 ~0.04Hz

#define AD9851_FTW_BITS     32              // 频率控制字位数
#define AD9851_PHASE_BITS   5               // 相位控制字位数

/* ================================================================
 * AD9851句柄
 * ================================================================ */
typedef struct {
    AD9851_Mode mode;           // 当前工作模式
    float   freq;               // 当前输出频率 (Hz)
    float   phase;              // 相位偏移 (度)
    float   fsk_freq;           // FSK第二频率 (Hz)
    uint8_t fsk_select;         // FSK频率选择 (0=主频, 1=FSK频)
    uint8_t power_down;         // 省电标志

    /* 扫频参数 */
    float   sweep_start;        // 扫频起始频率 (Hz)
    float   sweep_stop;         // 扫频终止频率 (Hz)
    float   sweep_step;         // 频率步进 (Hz)
    float   sweep_current;      // 当前扫频频率 (Hz)
    float   sweep_dwell;        // 每步驻留时间 (ms)
    uint8_t sweep_dir;          // 扫频方向 (0=正向, 1=反向)
    uint8_t sweep_running;      // 扫频运行标志

    uint8_t initialized;        // 初始化标志
} AD9851_Handle;

/* ================================================================
 * 接口函数
 * ================================================================ */

/**
 * @brief  初始化AD9851模块
 * @param  h  AD9851句柄指针
 * @note   配置GPIO、复位DDS芯片
 */
void AD9851_Init(AD9851_Handle *h);

/**
 * @brief  设置输出频率和相位 (单频模式)
 * @param  h      AD9851句柄指针
 * @param  freq   输出频率 (Hz)，1 ~ 70M
 * @param  phase  相位偏移 (度)，0 ~ 360
 * @return 0=成功, -1=参数超范围
 */
int AD9851_SetFreq(AD9851_Handle *h, float freq, float phase);

/**
 * @brief  设置FSK双频率
 * @param  h         AD9851句柄指针
 * @param  freq1     主频率 (Hz)
 * @param  freq2     FSK第二频率 (Hz)
 * @param  phase     相位偏移 (度)
 * @return 0=成功
 */
int AD9851_SetFSK(AD9851_Handle *h, float freq1, float freq2, float phase);

/**
 * @brief  FSK频率切换
 * @param  h       AD9851句柄指针
 * @param  select  0=主频率, 1=FSK频率
 */
void AD9851_FSK_Select(AD9851_Handle *h, uint8_t select);

/**
 * @brief  配置扫频参数
 * @param  h          AD9851句柄指针
 * @param  start_freq 起始频率 (Hz)
 * @param  stop_freq  终止频率 (Hz)
 * @param  step_freq  频率步进 (Hz)
 * @param  dwell_ms   每步驻留时间 (ms)
 * @return 0=成功
 */
int AD9851_Sweep_Config(AD9851_Handle *h, float start_freq, float stop_freq,
                        float step_freq, float dwell_ms);

/**
 * @brief  启动扫频
 * @param  h  AD9851句柄指针
 */
void AD9851_Sweep_Start(AD9851_Handle *h);

/**
 * @brief  停止扫频
 * @param  h  AD9851句柄指针
 */
void AD9851_Sweep_Stop(AD9851_Handle *h);

/**
 * @brief  扫频处理函数 (需在主循环或定时器中定期调用)
 * @param  h  AD9851句柄指针
 * @note   自动根据驻留时间切换频率
 */
void AD9851_Sweep_Process(AD9851_Handle *h);

/**
 * @brief  进入/退出省电模式
 * @param  h      AD9851句柄指针
 * @param  en     1=省电, 0=正常
 */
void AD9851_PowerDown(AD9851_Handle *h, uint8_t en);

/**
 * @brief  复位AD9851
 */
void AD9851_Reset(void);

#endif /* __AD9851_H */
