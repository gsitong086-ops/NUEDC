/**
 * @file    adc_sample.h
 * @brief   AD采样模块 - 定时器触发ADC + DMA双缓冲采集
 * @author  电赛DSP通用库
 * @date    2025-07
 * 
 * 使用TIM定时器周期性触发ADC采样，DMA循环模式搬运数据。
 * 双缓冲机制：DMA搬运半完成/全完成时分别处理，实现无间断采集。
 */

#ifndef __ADC_SAMPLE_H
#define __ADC_SAMPLE_H

#include "dsp_common.h"

/* ================================================================
 * 配置宏定义
 * ================================================================ */
#define ADC_DMA_LEN     2048        // DMA缓冲总长度 (双缓冲，一半=1024)
#define ADC_HALF_LEN    (ADC_DMA_LEN / 2)   // 半缓冲长度
#define FFT_N           1024        // FFT点数 (与半缓冲长度一致)

/* ================================================================
 * 接口函数
 * ================================================================ */

/**
 * @brief  初始化ADC+DMA+定时器触发
 * @note   需先在CubeMX中配置好ADC、DMA(循环模式)、TIM触发
 */
void ADC_Init(void);

/**
 * @brief  启动ADC采样
 */
void ADC_Start(void);

/**
 * @brief  停止ADC采样
 */
void ADC_Stop(void);

/**
 * @brief  检查是否有新的一帧数据就绪
 * @return 1=有新帧, 0=无新帧
 */
uint8_t ADC_FrameReady(void);

/**
 * @brief  获取最新一帧浮点电压数据
 * @param  buf  输出缓冲区 (长度至少 FFT_N)
 * @return 0=成功, -1=暂无数据
 */
int ADC_GetFrame(float *buf);

/**
 * @brief  获取原始ADC缓冲区指针 (调试用)
 * @return DMA缓冲区地址
 */
uint16_t* ADC_GetRawBuffer(void);

#endif /* __ADC_SAMPLE_H */
