/**
 * @file    adc_sample.c
 * @brief   AD采样模块实现
 * 
 * 依赖CubeMX配置：
 *   - ADC1 (或ADCx) 使能，分辨率12bit
 *   - TIMx TRGO触发ADC
 *   - DMA2 Stream0 循环模式，半字到半字
 */

#include "adc_sample.h"

/* ---- 内部变量 ---- */
static uint16_t adc_dma_buf[ADC_DMA_LEN];  // DMA原始数据缓冲
static float    adc_frame[FFT_N];           // 当前帧浮点数据
static volatile uint8_t frame_ready = 0;    // 帧就绪标志
static volatile uint8_t current_half = 0;   // 当前半缓冲索引

/* ---- 外部变量声明 (main.c中由CubeMX生成) ---- */
extern ADC_HandleTypeDef hadc1;
extern TIM_HandleTypeDef htim3;     // 触发ADC的定时器
extern DMA_HandleTypeDef hdma_adc1;

/**
 * @brief  初始化ADC采样系统
 */
void ADC_Init(void)
{
    /* 启动DMA */
    HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_dma_buf, ADC_DMA_LEN);
    /* 启动定时器触发 */
    HAL_TIM_Base_Start(&htim3);
}

/**
 * @brief  启动ADC采样
 */
void ADC_Start(void)
{
    frame_ready = 0;
    HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_dma_buf, ADC_DMA_LEN);
}

/**
 * @brief  停止ADC采样
 */
void ADC_Stop(void)
{
    HAL_ADC_Stop_DMA(&hadc1);
    HAL_TIM_Base_Stop(&htim3);
}

/**
 * @brief  检查是否有新帧就绪
 */
uint8_t ADC_FrameReady(void)
{
    return frame_ready;
}

/**
 * @brief  获取最新一帧浮点电压数据
 */
int ADC_GetFrame(float *buf)
{
    if (!frame_ready) return -1;
    for (int i = 0; i < FFT_N; i++) {
        buf[i] = adc_frame[i];
    }
    frame_ready = 0;
    return 0;
}

/**
 * @brief  获取原始DMA缓冲区指针
 */
uint16_t* ADC_GetRawBuffer(void)
{
    return adc_dma_buf;
}

/**
 * @brief  将半缓冲的原始ADC值转换为浮点电压
 * @param  src   原始ADC值数组起始地址
 * @param  dst   浮点电压输出数组
 * @param  len   数据长度
 */
static void ADC_ConvertHalf(uint16_t *src, float *dst, uint16_t len)
{
    for (uint16_t i = 0; i < len; i++) {
        dst[i] = (float)src[i] * 3.3f / 4096.0f;
    }
}

/* ================================================================
 * DMA回调函数 (在 stm32f4xx_it.c 或本文件中实现)
 * ================================================================ */

/**
 * @brief  DMA半传输完成回调 - 处理前半缓冲
 */
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef *hadc)
{
    ADC_ConvertHalf(&adc_dma_buf[0], adc_frame, ADC_HALF_LEN);
    frame_ready = 1;
    current_half = 0;
}

/**
 * @brief  DMA传输完成回调 - 处理后半缓冲
 */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    ADC_ConvertHalf(&adc_dma_buf[ADC_HALF_LEN], adc_frame, ADC_HALF_LEN);
    frame_ready = 1;
    current_half = 1;
}

/**
 * @brief  ADC错误回调
 */
void HAL_ADC_ErrorCallback(ADC_HandleTypeDef *hadc)
{
    /* 可在此处添加错误处理逻辑 */
    ADC_Start();  // 尝试重新启动
}
