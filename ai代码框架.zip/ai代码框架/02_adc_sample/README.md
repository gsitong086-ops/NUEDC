# 02_adc_sample - AD采样模块

## 功能概述

使用定时器触发ADC周期性采样，通过DMA循环模式自动搬运数据。采用**双缓冲机制**：DMA缓冲区分为前后两半，半传输完成和全传输完成时分别将数据转换为浮点电压，实现无CPU干预的连续采集。

## 工作原理

```
TIM触发 ──→ ADC转换 ──→ DMA循环搬运 ──→ 双缓冲交替
                                          ├─ 前半满 → 转浮点 → frame_ready=1
                                          └─ 后半满 → 转浮点 → frame_ready=1
```

## 文件列表

| 文件 | 说明 |
|------|------|
| `adc_sample.h` | 头文件：宏定义、接口声明 |
| `adc_sample.c` | 源文件：初始化、DMA回调、数据获取 |

## 关键宏定义

```c
#define ADC_DMA_LEN  2048    // DMA缓冲总长度 = FFT_N * 2
#define FFT_N        1024    // FFT点数 (每帧长度)
```

> **设计原则**：DMA缓冲区 = FFT点数 × 2，保证处理一帧时另一帧在采集。

## CubeMX 配置要点

| 外设 | 配置 |
|------|------|
| **ADC1** | 分辨率 12bit，扫描模式，连续转换 |
| **TIM3** | TRGO输出触发ADC (Update Event) |
| **DMA2 Stream0** | 循环模式，半字→半字，指向 `adc_dma_buf` |

### 定时器频率计算

```
TIM_ARR = (TIM_CLK / (PSC+1)) / fs_target - 1
```

示例：168MHz时钟，目标采样率20kHz：
```
PSC = 83      →  TIM_CLK = 168M/84 = 2MHz
ARR = 2000000/20000 - 1 = 99
```

## 使用示例

```c
#include "adc_sample.h"

// 初始化并启动
ADC_Init();
ADC_Start();

float data[FFT_N];

while (1) {
    if (ADC_FrameReady()) {
        ADC_GetFrame(data);  // 获取一帧浮点电压数据
        
        // 此处对data[]进行FFT、滤波等处理
        FFT_Process(data, g_params.fs_actual);
    }
}
```

## 接口说明

| 函数 | 说明 |
|------|------|
| `ADC_Init()` | 初始化DMA+定时器 |
| `ADC_Start()` | 启动采集 |
| `ADC_Stop()` | 停止采集 |
| `ADC_FrameReady()` | 查询是否有新帧 (返回1=有) |
| `ADC_GetFrame(buf)` | 获取浮点电压数据 |
| `ADC_GetRawBuffer()` | 获取原始uint16缓冲指针 |

## 电压转换公式

```
V_float = ADC_raw × 3.3V / 4096
```

## 依赖

- `dsp_common.h` (使用 `g_params.fs_actual`)
- HAL库 (ADC, TIM, DMA)
- CubeMX生成的 `hadc1`, `htim3`, `hdma_adc1`
