# 电赛DSP通用代码框架 (STM32F407ZGT6)

## 项目简介

面向电赛仪器仪表类题目的通用DSP模块库，基于 **STM32F407ZGT6** (Cortex-M4, 168MHz, FPU+DSP指令) 平台，**Keil MDK** 编译环境。

## 模块架构

```
代码框架/
├── 01_dsp_common/      # 公共参数管理 (全局参数结构体)
├── 02_adc_sample/      # AD采样模块 (定时器触发 + DMA双缓冲)
├── 03_fft_proc/        # FFT频谱分析 (CMSIS-DSP实数FFT)
├── 04_filter/          # 数字滤波 (IIR Biquad级联)
├── 05_lockin/          # 数字锁相放大 (NCO + I/Q解调)
├── 06_dac_output/      # DDS波形输出 (正弦/方波/三角波)
├── 07_ad603/           # AD603程控增益放大器驱动
├── 08_ad9851/          # AD9851 DDS频率合成模块驱动
├── 09_ad630/           # AD630平衡调制/解调器驱动
├── main.c              # 应用层示例代码
└── README.md           # 本文件
```

## 完整信号链路

```
┌─────────┐    ┌──────────┐    ┌─────────┐    ┌──────────┐    ┌─────────┐
│ AD9851  │───→│   DUT    │───→│  AD603  │───→│  AD630   │───→│   LPF   │
│ 激励源  │    │ 被测网络  │    │ 程控增益 │    │ 同步解调  │    │ 低通滤波 │
└─────────┘    └──────────┘    └─────────┘    └──────────┘    └────┬────┘
                     ↑              ↑                ↑              │
                 (信号)      (幅度调节)      (参考方波)        STM32 ADC
                                                               │
                    ┌──────────────────────────────────────────┘
                    ↓
              ┌──────────┐    ┌──────────┐    ┌──────────┐
              │ 数字滤波  │───→│   FFT    │───→│ 结果输出  │
              │ (可选)   │    │ 频谱分析  │    │ 串口/USB │
              └──────────┘    └──────────┘    └──────────┘
```

## 模块依赖关系

```
01_dsp_common  ←── 所有模块 (全局参数)
     ↑
02_adc_sample  →  03_fft_proc  →  04_filter (可选)
     ↓              ↓              ↓
07_ad603 (前端增益)  05_lockin (数字锁相)  09_ad630 (模拟锁相)
                         ↓                    ↑
                   08_ad9851 (激励源) ────────┘
                         ↓
                   06_dac_output (板载DAC输出)
```

## 快速开始

### 1. CubeMX 配置清单

| 外设 | 用途 | 关键配置 |
|------|------|---------|
| ADC1 | 信号采集 | 12bit, TIM3 TRGO触发 |
| ADC2 | 第二路采集 (可选) | 12bit, TIM3 TRGO触发 |
| TIM3 | ADC触发源 | PSC=83, ARR=99 → 20kHz采样 |
| DMA2 Stream0 | ADC1搬运 | 循环模式, 半字→半字 |
| DMA2 Stream2 | ADC2搬运 (可选) | 循环模式, 半字→半字 |
| DAC1 | AD603增益控制 | Channel 1 (PA4) |
| DAC2 | 板载信号输出 (可选) | Channel 2 (PA5) |
| TIM4 | DAC触发源 | PSC=83, ARR=99 → 20kHz更新 |
| DMA1 Stream5 | DAC搬运 | 循环模式, 半字→半字 |
| GPIOA[0:7] | AD9851数据总线 | 推挽输出, Very High速度 |
| GPIOB[0:3] | AD9851控制线 | WCLK/FQUD/RESET/FSK |
| USART1 | 调试输出 | 115200-8-N-1 |

### 2. Keil 工程配置

**Manage Run-Time Environment:**
- 勾选 `CMSIS → DSP`

**Options → C/C++ → Define:**
```
ARM_MATH_CM4,__FPU_PRESENT=1,__FPU_USED=1
```

**Options → Target → Floating Point Hardware:**
```
Single Precision
```

### 3. 文件添加

将所有模块的 `.c` 文件添加到 Keil 工程的 Source Group，所有模块文件夹添加到 Include Paths。

### 4. 典型代码框架

```c
#include "dsp_common.h"
#include "adc_sample.h"
#include "fft_proc.h"
#include "filter.h"
#include "lockin.h"
#include "dac_output.h"
#include "ad603.h"
#include "ad9851.h"
#include "ad630.h"

FFT_Handle   fft_h;
FilterHandle flt_h;
LockIn       lockin;
DacOutput    dac;
AD603_Handle ad603;
AD9851_Handle dds;
AD630_Handle ad630;

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    // ... CubeMX生成的初始化 ...

    DspParams_Init();
    ADC_Init();
    FFT_Init(&fft_h, g_params.fs_actual);
    LockIn_Init(&lockin, 1000.0f, g_params.fs_actual, 0.01f);
    DAC_Init(&dac);
    
    // 外置模块初始化
    AD603_Init(&ad603);
    AD9851_Init(&dds);
    AD630_Init(&ad630);

    // 配置信号链路: AD9851输出1kHz → 被测网络 → AD603增益20dB → AD630解调
    AD9851_SetFreq(&dds, 1000.0f, 0.0f);
    AD603_SetGain(&ad603, 20.0f);
    AD630_SetRefFreq(&ad630, 1000.0f);
    AD630_SetSystemGain(&ad630, 10.0f);

    float adc_buf[FFT_N];

    while (1) {
        if (ADC_FrameReady()) {
            ADC_GetFrame(adc_buf);
            
            // FFT频谱分析
            FFT_Process(&fft_h, adc_buf);
            
            // 锁相放大
            LockIn_ProcessBlock(&lockin, adc_buf, FFT_N);
            
            // AD630解调结果计算
            float signal_vpp = AD630_CalcInputLevel(&ad630, 
                lockin.amplitude);
            
            // AGC: 根据信号幅度自动调整AD603增益
            AD603_AGC(&ad603, signal_vpp, 1.5f);
            
            // 串口输出结果
            printf("Freq:%.1fHz Vpp:%.3fV Gain:%.1fdB\r\n",
                   fft_h.peak_freq, signal_vpp, ad603.gain_db);
        }
    }
}
```

## 各模块详细说明

| 模块 | 核心功能 | 适用场景 |
|------|---------|---------|
| `01_dsp_common` | 参数统一管理 | 串口调参、AI参数优化 |
| `02_adc_sample` | DMA双缓冲采集 | 连续无间断采样 |
| `03_fft_proc` | 实数FFT频谱分析 | 频谱分析、示波器 |
| `04_filter` | IIR Biquad级联滤波 | 去噪、频段选择 |
| `05_lockin` | 数字锁相放大 | 微弱信号检测、阻抗测量 |
| `06_dac_output` | DDS波形输出 | 板载信号发生器 |
| `07_ad603` | 程控增益放大器 | 前端信号调理、AGC |
| `08_ad9851` | DDS频率合成 | 高频激励源、扫频 |
| `09_ad630` | 模拟锁相解调 | 微弱信号提取、阻抗分析 |

## 外置模块硬件清单

| 模块 | 型号 | 通信接口 | 供电 | 用途 |
|------|------|---------|------|------|
| 程控放大器 | AD603 | DAC电压控制 | ±5V或+5V | 信号幅度调节 |
| DDS模块 | AD9851 | 8位并行/SPI | +5V | 高频信号发生 |
| 调制解调器 | AD630 | 模拟器件 | ±15V或±5V | 同步解调 |

## 参数调优建议

| 场景 | 推荐采样率 | AD9851频率 | AD603增益 | 低通τ |
|------|-----------|-----------|----------|-------|
| 音频分析 | 20kHz | 1kHz | 0dB | — |
| 电网谐波 | 5kHz | 50Hz | 10dB | — |
| 超声波 | 200kHz | 40kHz | 20dB | — |
| 微弱信号 | 20kHz | 1kHz | 30dB | 10ms |
| 阻抗扫描 | 20kHz | 100k~10M扫频 | AGC自动 | 1ms |

## 硬件平台

- **MCU**: STM32F407ZGT6
- **内核**: ARM Cortex-M4
- **主频**: 168MHz
- **FPU**: 单精度硬件浮点
- **DSP指令**: 单周期MAC
- **Flash**: 1MB
- **RAM**: 192KB
