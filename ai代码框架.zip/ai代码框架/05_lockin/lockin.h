/**
 * @file    lockin.h
 * @brief   数字锁相放大模块 - NCO + I/Q解调 + 低通滤波
 * @author  电赛DSP通用库
 * @date    2025-07
 * 
 * 实现原理：
 *   1. NCO产生与参考频率同频的正交信号 (sin/cos)
 *   2. 输入信号分别与 sin 和 cos 相乘 (I/Q解调)
 *   3. 乘积通过一阶低通滤波提取直流分量
 *   4. 幅值 = 2√(I² + Q²)，相位 = atan2(Q, I)
 * 
 * 适用于微弱信号检测、阻抗测量等场景。
 */

#ifndef __LOCKIN_H
#define __LOCKIN_H

#include "dsp_common.h"
#include "arm_math.h"

/* ================================================================
 * 锁相放大句柄
 * ================================================================ */
typedef struct {
    float   ref_freq;       // 参考频率 (Hz)
    float   fs;             // 采样率 (Hz)
    float   phase;          // 当前相位 (弧度)
    float   phase_inc;      // 相位增量 = 2π × ref_freq / fs
    float   alpha;          // 低通系数 = 1 - exp(-Ts/τ)
    float   i_accum;        // I路累加值
    float   q_accum;        // Q路累加值
    float   amplitude;      // 输出幅度
    float   phase_deg;      // 输出相位 (度)
    float   tau;            // 低通时间常数 (s)
} LockIn;

/* ================================================================
 * 接口函数
 * ================================================================ */

/**
 * @brief  初始化锁相放大器
 * @param  lock     锁相句柄指针
 * @param  ref_freq 参考频率 (Hz)
 * @param  fs       采样率 (Hz)
 * @param  tau      低通时间常数 (s)，越小响应越快但噪声越大
 */
void LockIn_Init(LockIn *lock, float ref_freq, float fs, float tau);

/**
 * @brief  设置参考频率 (运行时动态调整)
 * @param  lock     锁相句柄指针
 * @param  ref_freq 新的参考频率 (Hz)
 */
void LockIn_SetFreq(LockIn *lock, float ref_freq);

/**
 * @brief  逐点处理锁相放大
 * @param  lock    锁相句柄指针
 * @param  sample  输入采样值 (浮点电压)
 * 
 * @note   每次调用处理一个采样点，I/Q累加值不断更新。
 *         可通过 lock->amplitude 和 lock->phase_deg 读取当前结果。
 */
void LockIn_ProcessPoint(LockIn *lock, float sample);

/**
 * @brief  批量处理锁相放大
 * @param  lock   锁相句柄指针
 * @param  input  输入数据数组
 * @param  len    数据长度
 */
void LockIn_ProcessBlock(LockIn *lock, float *input, uint32_t len);

/**
 * @brief  重置锁相放大器状态
 */
void LockIn_Reset(LockIn *lock);

#endif /* __LOCKIN_H */
