# 05_lockin - 数字锁相放大模块

## 功能概述

实现数字锁相放大器（Lock-in Amplifier），用于从强噪声背景中提取与参考信号同频的微弱信号幅度和相位。核心算法：NCO正交混频 + I/Q解调 + 一阶低通滤波。

## 工作原理

```
输入信号 s(t) = A·sin(ωt + θ)
                │
        ┌───────┴───────┐
        ▼               ▼
   × sin(ωt)        × cos(ωt)      ← NCO产生
        │               │
        ▼               ▼
   一阶低通          一阶低通
        │               │
        ▼               ▼
    I = A/2·cos(Δθ)  Q = A/2·sin(Δθ)
        │               │
        └───────┬───────┘
                ▼
    幅度 = 2√(I² + Q²)
    相位 = atan2(Q, I) × 180°/π
```

## 文件列表

| 文件 | 说明 |
|------|------|
| `lockin.h` | 头文件：锁相句柄、接口声明 |
| `lockin.c` | 源文件：NCO、I/Q解调、低通滤波实现 |

## 核心数据结构

```c
typedef struct {
    float ref_freq;      // 参考频率 (Hz)
    float fs;            // 采样率 (Hz)
    float phase;         // NCO当前相位 (弧度)
    float phase_inc;     // 相位增量 = 2π×fref/fs
    float alpha;         // 低通系数 = 1-exp(-Ts/τ)
    float i_accum;       // I路直流分量
    float q_accum;       // Q路直流分量
    float amplitude;     // 输出幅度
    float phase_deg;     // 输出相位 (度)
    float tau;           // 时间常数 (s)
} LockIn;
```

## 参数选择指南

### 时间常数 τ

| τ (s) | 等效带宽 | 响应速度 | 噪声抑制 | 适用场景 |
|-------|---------|---------|---------|---------|
| 0.001 | 250 Hz | 极快 | 弱 | 快速跟踪 |
| 0.01 | 25 Hz | 快 | 中 | 通用 |
| 0.1 | 2.5 Hz | 慢 | 强 | 微弱信号 |
| 1.0 | 0.25 Hz | 很慢 | 极强 | 超微弱信号 |

> 低通截止频率 = 1/(2πτ)

## 使用示例

```c
#include "lockin.h"

LockIn lockin;

// 初始化：参考频率1kHz，采样率20kHz，时间常数10ms
LockIn_Init(&lockin, 1000.0f, 20000.0f, 0.01f);

// 逐点实时处理
float adc_data[FFT_N];
ADC_GetFrame(adc_data);

LockIn_ProcessBlock(&lockin, adc_data, FFT_N);

printf("Amplitude: %.4f V, Phase: %.1f°\r\n",
       lockin.amplitude, lockin.phase_deg);

// 动态改变参考频率 (扫频)
LockIn_SetFreq(&lockin, 2000.0f);
```

## 接口说明

| 函数 | 说明 |
|------|------|
| `LockIn_Init(lock, ref_freq, fs, tau)` | 初始化锁相放大器 |
| `LockIn_SetFreq(lock, ref_freq)` | 运行时改变参考频率 |
| `LockIn_ProcessPoint(lock, sample)` | 逐点处理 (实时) |
| `LockIn_ProcessBlock(lock, input, len)` | 批量处理 |
| `LockIn_Reset(lock)` | 重置所有状态 |

## 应用场景

1. **阻抗测量**：激励信号 → DUT → 锁相解调 → 实部/虚部
2. **LCR表**：正交解调分离电阻/电容/电感分量
3. **微弱光检测**：调制光源 + 光电探测器 + 锁相放大
4. **锁相环**：用相位输出做闭环反馈控制

## 依赖

- `dsp_common.h` (更新 `g_params.lockin_*`)
- `arm_math.h` (使用 `arm_sin_f32`, `arm_cos_f32`)
- `math.h`
