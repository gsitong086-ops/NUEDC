/**
 * @file    lockin.c
 * @brief   数字锁相放大模块实现
 * 
 * 算法流程：
 *   NCO产生 sin(ωt+φ) 和 cos(ωt+φ)
 *   输入信号 s(t) = A·sin(ωt+θ)
 *   
 *   I = s(t) × sin(ωt+φ) → 低通 → (A/2)·cos(θ-φ)
 *   Q = s(t) × cos(ωt+φ) → 低通 → (A/2)·sin(θ-φ)
 *   
 *   幅度 A = 2√(I²+Q²)
 *   相位 Δθ = atan2(Q, I)
 */

#include "lockin.h"
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif
#define TWO_PI (2.0f * M_PI)

/**
 * @brief  初始化锁相放大器
 */
void LockIn_Init(LockIn *lock, float ref_freq, float fs, float tau)
{
    lock->ref_freq   = ref_freq;
    lock->fs         = fs;
    lock->tau        = tau;
    lock->phase      = 0.0f;
    lock->phase_inc  = TWO_PI * ref_freq / fs;
    
    /* 一阶低通系数: α = 1 - exp(-Ts/τ) */
    float Ts = 1.0f / fs;
    lock->alpha = 1.0f - expf(-Ts / tau);
    
    /* 限制alpha范围，防止数值不稳定 */
    if (lock->alpha > 1.0f)  lock->alpha = 1.0f;
    if (lock->alpha < 0.0f)  lock->alpha = 0.0f;
    
    lock->i_accum    = 0.0f;
    lock->q_accum    = 0.0f;
    lock->amplitude  = 0.0f;
    lock->phase_deg  = 0.0f;
}

/**
 * @brief  动态修改参考频率
 */
void LockIn_SetFreq(LockIn *lock, float ref_freq)
{
    lock->ref_freq  = ref_freq;
    lock->phase_inc = TWO_PI * ref_freq / lock->fs;
}

/**
 * @brief  逐点处理 (实时锁相放大)
 */
void LockIn_ProcessPoint(LockIn *lock, float sample)
{
    float sin_val, cos_val;
    
    /* NCO查表 */
    sin_val = arm_sin_f32(lock->phase);
    cos_val = arm_cos_f32(lock->phase);
    
    /* I/Q解调 */
    float i_demod = sample * sin_val;   // 同相分量
    float q_demod = sample * cos_val;   // 正交分量
    
    /* 一阶低通滤波 */
    lock->i_accum = lock->i_accum + lock->alpha * (i_demod - lock->i_accum);
    lock->q_accum = lock->q_accum + lock->alpha * (q_demod - lock->q_accum);
    
    /* 计算幅度和相位 */
    lock->amplitude = 2.0f * sqrtf(lock->i_accum * lock->i_accum +
                                    lock->q_accum * lock->q_accum);
    lock->phase_deg = atan2f(lock->q_accum, lock->i_accum) * 180.0f / M_PI;
    
    /* 更新NCO相位 */
    lock->phase += lock->phase_inc;
    if (lock->phase > TWO_PI) {
        lock->phase -= TWO_PI;
    }
    
    /* 更新全局参数 */
    g_params.lockin_amplitude = lock->amplitude;
    g_params.lockin_phase     = lock->phase_deg;
}

/**
 * @brief  批量处理
 */
void LockIn_ProcessBlock(LockIn *lock, float *input, uint32_t len)
{
    for (uint32_t i = 0; i < len; i++) {
        LockIn_ProcessPoint(lock, input[i]);
    }
}

/**
 * @brief  重置状态
 */
void LockIn_Reset(LockIn *lock)
{
    lock->phase     = 0.0f;
    lock->i_accum   = 0.0f;
    lock->q_accum   = 0.0f;
    lock->amplitude = 0.0f;
    lock->phase_deg = 0.0f;
}
