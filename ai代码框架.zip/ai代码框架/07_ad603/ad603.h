/**
 * @file    ad603.h
 * @brief   AD603程控增益放大器驱动模块
 * @author  电赛DSP通用库
 * @date    2025-07
 * 
 * AD603是一款低噪声、电压控制的可变增益放大器。
 * 增益范围：-10dB ~ +30dB (共40dB范围)
 * 控制电压Vg范围：-0.5V ~ +0.5V (相对于GNEG引脚)
 * 
 * 典型应用电路：
 *   - 带宽90MHz模式下：增益(dB) = 40×Vg + 10  (Vg单位: V)
 *   - 带宽30MHz模式下：增益(dB) = 40×Vg + 20
 * 
 * 本模块通过STM32的DAC输出经电阻分压后提供Vg控制电压。
 * Vg = (V_DAC - V_GNEG)，其中V_GNEG通常接1/2 VREF
 * 
 * 硬件接线：
 *   STM32 DAC → 低通滤波 → AD603 VGPOS (Pin 1)
 *   AD603 GNEG (Pin 2) → 1.65V (VREF/2)
 *   AD603 VOUT (Pin 7) → 后级ADC或AD630
 */

#ifndef __AD603_H
#define __AD603_H

#include "dsp_common.h"

/* ================================================================
 * 配置宏
 * ================================================================ */
#define AD603_GAIN_MIN      (-10.0f)    // 最小增益 (dB)
#define AD603_GAIN_MAX      (30.0f)     // 最大增益 (dB)
#define AD603_GAIN_SLOPE    (40.0f)     // 增益斜率 (dB/V)
#define AD603_VG_MIN        (-0.5f)     // Vg最小值 (V)
#define AD603_VG_MAX        (0.5f)      // Vg最大值 (V)

/* 控制电压映射到DAC值 */
#define AD603_DAC_MAX       4095
#define AD603_VREF          3.3f
#define AD603_GNEG_VOLTAGE  1.65f       // GNEG偏置电压 = VREF/2

/* ================================================================
 * AD603句柄
 * ================================================================ */
typedef struct {
    float   gain_db;        // 当前增益 (dB)
    float   vctrl;          // 控制电压 Vg (V)
    float   gnvg_voltage;   // GNEG偏置电压 (V)
    uint8_t initialized;    // 初始化标志
} AD603_Handle;

/* ================================================================
 * 接口函数
 * ================================================================ */

/**
 * @brief  初始化AD603
 * @param  h  AD603句柄指针
 * @note   默认增益 0dB, GNEG = 1.65V
 */
void AD603_Init(AD603_Handle *h);

/**
 * @brief  设置增益 (dB)
 * @param  h     AD603句柄指针
 * @param  gain  目标增益 (dB)，范围 -10 ~ +30
 * @return 0=成功, -1=参数超范围
 * 
 * @note   自动计算Vg = (gain - 10) / 40
 *         DAC输出电压 = Vg + V_GNEG
 */
int AD603_SetGain(AD603_Handle *h, float gain);

/**
 * @brief  设置控制电压Vg (直接控制方式)
 * @param  h     AD603句柄指针
 * @param  vg    控制电压 (V)，范围 -0.5 ~ +0.5
 * @return 0=成功, -1=参数超范围
 */
int AD603_SetVg(AD603_Handle *h, float vg);

/**
 * @brief  获取当前增益
 * @param  h  AD603句柄指针
 * @return 当前增益值 (dB)
 */
float AD603_GetGain(AD603_Handle *h);

/**
 * @brief  自动增益控制 (AGC)
 * @param  h            AD603句柄指针
 * @param  input_level  输入信号幅度 (Vpp)
 * @param  target_level 目标输出幅度 (Vpp)
 * @return 0=成功
 * 
 * @note   根据输入幅度自动调整增益使输出接近目标值
 */
int AD603_AGC(AD603_Handle *h, float input_level, float target_level);

#endif /* __AD603_H */
