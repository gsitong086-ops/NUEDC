/**
 * @file    ad603.c
 * @brief   AD603程控增益放大器驱动实现
 * 
 * 增益公式 (90MHz带宽模式):
 *   Gain(dB) = 40 × Vg + 10
 *   其中 Vg = V_GPOS - V_GNEG
 * 
 * DAC输出计算:
 *   V_DAC = Vg + V_GNEG = (Gain - 10)/40 + 1.65
 *   DAC值 = V_DAC / 3.3 × 4095
 * 
 * 硬件接线:
 *   DAC_OUT (PA4) → RC低通(1kΩ+10μF) → AD603 VGPOS(Pin1)
 *   AD603 GNEG(Pin2) → 1.65V (两个10kΩ电阻分压 VREF)
 *   AD603 VOUT(Pin7) → 后级信号链
 */

#include "ad603.h"
#include <math.h>

/* ---- 外部DAC句柄 ---- */
extern DAC_HandleTypeDef hdac;

/* ---- 静态函数声明 ---- */
static void AD603_UpdateDAC(float vctrl);

/**
 * @brief  初始化AD603
 */
void AD603_Init(AD603_Handle *h)
{
    h->gain_db      = 0.0f;
    h->vctrl        = 0.0f;
    h->gnvg_voltage = AD603_GNEG_VOLTAGE;
    h->initialized  = 1;

    /* 输出初始控制电压: Vg=0 → 增益10dB (90MHz模式) */
    AD603_UpdateDAC(AD603_GNEG_VOLTAGE);

    /* 同步全局参数 */
    g_params.ad603_gain_db = h->gain_db;
    g_params.ad603_vctrl   = h->vctrl;
}

/**
 * @brief  设置增益 (dB)
 * 
 * 计算公式: Vg = (Gain - 10) / 40
 * 然后映射为DAC输出
 */
int AD603_SetGain(AD603_Handle *h, float gain)
{
    if (!h->initialized) return -1;
    if (gain < AD603_GAIN_MIN || gain > AD603_GAIN_MAX) return -1;

    /* 计算控制电压 Vg */
    float vg = (gain - 10.0f) / AD603_GAIN_SLOPE;

    /* 限幅 */
    if (vg < AD603_VG_MIN) vg = AD603_VG_MIN;
    if (vg > AD603_VG_MAX) vg = AD603_VG_MAX;

    /* 计算DAC输出电压 */
    float v_dac = vg + h->gnvg_voltage;

    h->gain_db = gain;
    h->vctrl   = vg;

    AD603_UpdateDAC(v_dac);

    /* 更新全局参数 */
    g_params.ad603_gain_db = h->gain_db;
    g_params.ad603_vctrl   = h->vctrl;

    return 0;
}

/**
 * @brief  直接设置控制电压Vg
 */
int AD603_SetVg(AD603_Handle *h, float vg)
{
    if (!h->initialized) return -1;
    if (vg < AD603_VG_MIN || vg > AD603_VG_MAX) return -1;

    /* 反算增益 */
    float gain = AD603_GAIN_SLOPE * vg + 10.0f;

    float v_dac = vg + h->gnvg_voltage;

    h->vctrl   = vg;
    h->gain_db = gain;

    AD603_UpdateDAC(v_dac);

    g_params.ad603_gain_db = h->gain_db;
    g_params.ad603_vctrl   = h->vctrl;

    return 0;
}

/**
 * @brief  获取当前增益
 */
float AD603_GetGain(AD603_Handle *h)
{
    return h->gain_db;
}

/**
 * @brief  自动增益控制 (AGC)
 * 
 * 简易AGC算法：
 *   目标增益 = 20 × log10(target_level / input_level)
 *   将增益限制在 [-10, +30] dB范围内
 */
int AD603_AGC(AD603_Handle *h, float input_level, float target_level)
{
    if (!h->initialized) return -1;
    if (input_level < 0.001f) input_level = 0.001f;  /* 防止除零 */

    /* 计算所需增益 */
    float required_gain = 20.0f * log10f(target_level / input_level);

    /* 限幅到AD603增益范围 */
    if (required_gain < AD603_GAIN_MIN) required_gain = AD603_GAIN_MIN;
    if (required_gain > AD603_GAIN_MAX) required_gain = AD603_GAIN_MAX;

    /* 设置增益 (可加一阶平滑避免剧烈跳变) */
    return AD603_SetGain(h, required_gain);
}

/* ================================================================
 * 私有函数
 * ================================================================ */

/**
 * @brief  更新DAC输出电压
 * @param  v_dac  目标DAC输出电压 (V)，范围 0 ~ 3.3
 */
static void AD603_UpdateDAC(float v_dac)
{
    /* 限幅 */
    if (v_dac < 0.0f)  v_dac = 0.0f;
    if (v_dac > 3.3f)  v_dac = 3.3f;

    uint16_t dac_val = (uint16_t)(v_dac / 3.3f * (float)AD603_DAC_MAX);

    /* 通过DAC输出控制电压 */
    HAL_DAC_SetValue(&hdac, DAC_CHANNEL_1, DAC_ALIGN_12B_R, dac_val);
}
