/**
 * @file    fft_proc.h
 * @brief   FFT频谱分析模块 - 基于CMSIS-DSP实数FFT
 * @author  电赛DSP通用库
 * @date    2025-07
 * 
 * 使用 arm_rfft_fast_f32 进行实数FFT运算，自动计算幅值谱和峰值频率。
 * 相比复数FFT，实数FFT只需 N 个float输入，内存占用减半。
 */

#ifndef __FFT_PROC_H
#define __FFT_PROC_H

#include "dsp_common.h"
#include "arm_math.h"       /* CMSIS-DSP库 */

/* ================================================================
 * 配置宏
 * ================================================================ */
#define FFT_N       1024        // FFT点数 (2的幂次)
#define FFT_N_HALF  (FFT_N / 2) // 有效频谱点数

/* ================================================================
 * FFT句柄结构体
 * ================================================================ */
typedef struct {
    arm_rfft_fast_instance_f32 instance;    // CMSIS-DSP FFT实例
    float   input_buf[FFT_N];               // 输入缓冲 (时域)
    float   fft_buf[FFT_N];                 // FFT运算缓冲
    float   mag_buf[FFT_N_HALF];            // 幅值谱输出
    float   peak_freq;                      // 峰值频率 (Hz)
    float   peak_mag;                       // 峰值幅度
    float   freq_resolution;                // 频率分辨率 (Hz)
} FFT_Handle;

/* ================================================================
 * 接口函数
 * ================================================================ */

/**
 * @brief  初始化FFT实例
 * @param  h     FFT句柄指针
 * @param  fs    采样率 (Hz)
 */
void FFT_Init(FFT_Handle *h, float fs);

/**
 * @brief  执行FFT频谱分析
 * @param  h       FFT句柄指针
 * @param  input  输入时域信号 (长度 FFT_N)
 * @return 0=成功
 * 
 * 处理完成后，可通过 h->peak_freq、h->peak_mag、h->mag_buf 获取结果
 */
int FFT_Process(FFT_Handle *h, float *input);

/**
 * @brief  在幅值谱中查找峰值 (排除DC分量)
 * @param  h      FFT句柄指针
 * @param  mag    幅值谱数组
 * @param  len    有效长度
 */
void FFT_FindPeak(FFT_Handle *h, float *mag, uint32_t len);

#endif /* __FFT_PROC_H */
