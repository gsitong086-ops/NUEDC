# 03_fft_proc - FFT频谱分析模块

## 功能概述

基于CMSIS-DSP库的 `arm_rfft_fast_f32` 实现实数FFT频谱分析。相比复数FFT，实数FFT只需N个float输入（内存减半），输出为交错复数格式，自动计算幅值谱和峰值频率。

## 文件列表

| 文件 | 说明 |
|------|------|
| `fft_proc.h` | 头文件：FFT句柄结构体、接口声明 |
| `fft_proc.c` | 源文件：FFT初始化、执行、峰值查找 |

## 核心数据结构

```c
typedef struct {
    arm_rfft_fast_instance_f32 instance;  // CMSIS-DSP FFT实例
    float input_buf[FFT_N];               // 时域输入
    float fft_buf[FFT_N];                 // FFT运算缓冲
    float mag_buf[FFT_N_HALF];            // 幅值谱 [0, N/2)
    float peak_freq;                      // 峰值频率 (Hz)
    float peak_mag;                       // 峰值幅度
    float freq_resolution;                // 频率分辨率 (Hz)
} FFT_Handle;
```

## 处理流程

```
输入信号 → arm_rfft_fast_f32 (实数FFT)
         → 交错复数格式: [re0, re1, im1, re2, im2, ...]
         → 幅值计算: sqrt(re² + im²) / N × 2
         → 峰值查找 (跳过DC)
         → 输出 peak_freq, peak_mag, mag_buf[]
```

## 频率分辨率

```
Δf = fs / N

示例: fs=20kHz, N=1024 → Δf ≈ 19.5 Hz
```

## 幅值谱计算

| 索引 | 公式 | 说明 |
|------|------|------|
| 0 (DC) | `|fft_buf[0]| / N` | 直流分量 |
| 1 ~ N/2-1 | `√(re²+im²) / N × 2` | 正频率分量 |
| N/2 | `|fft_buf[1]| / N` | 奈奎斯特频率 |

## Keil 配置要点

1. **Manage Run-Time Environment** → CMSIS → **DSP** 勾选
2. **Options → C/C++ → Define** 添加：
   ```
   ARM_MATH_CM4,__FPU_PRESENT=1,__FPU_USED=1
   ```
3. **Floating Point Hardware**: Single Precision

## 使用示例

```c
#include "fft_proc.h"

FFT_Handle fft_h;

// 初始化 (采样率 20kHz)
FFT_Init(&fft_h, 20000.0f);

// 获取ADC数据并FFT
float adc_data[FFT_N];
if (ADC_FrameReady()) {
    ADC_GetFrame(adc_data);
    FFT_Process(&fft_h, adc_data);
    
    printf("Peak: %.1f Hz, Mag: %.3f\r\n",
           fft_h.peak_freq, fft_h.peak_mag);
    
    // 也可访问完整幅值谱 fft_h.mag_buf[]
}
```

## 性能参考 (STM32F407 @168MHz)

| FFT点数 | 耗时 (近似) |
|---------|------------|
| 256 | ~0.05 ms |
| 512 | ~0.12 ms |
| 1024 | ~0.28 ms |
| 2048 | ~0.62 ms |

## 依赖

- `dsp_common.h` (更新 `g_params.fft_peak_freq/mag`)
- `arm_math.h` (CMSIS-DSP库)
- `math.h` (sqrtf, fabsf)
