/**
 * @file    fft_proc.c
 * @brief   FFT频谱分析模块实现
 * 
 * 依赖：Keil RTE中勾选 CMSIS → DSP
 * 宏定义需添加：ARM_MATH_CM4, __FPU_PRESENT=1
 */

#include "fft_proc.h"
#include <math.h>

/**
 * @brief  初始化FFT实例
 */
void FFT_Init(FFT_Handle *h, float fs)
{
    /* 初始化CMSIS-DSP实数FFT实例 */
    arm_rfft_fast_init_f32(&h->instance, FFT_N);
    
    h->peak_freq = 0.0f;
    h->peak_mag  = 0.0f;
    h->freq_resolution = fs / (float)FFT_N;
    
    /* 清零缓冲区 */
    memset(h->input_buf, 0, sizeof(h->input_buf));
    memset(h->fft_buf,   0, sizeof(h->fft_buf));
    memset(h->mag_buf,   0, sizeof(h->mag_buf));
}

/**
 * @brief  执行FFT频谱分析
 * 
 * 处理流程：
 *   1. 将输入信号复制到内部缓冲
 *   2. 调用 arm_rfft_fast_f32 进行实数FFT
 *   3. 输出为交错复数格式：[re0, re1, im1, re2, im2, ...]
 *   4. 计算幅值谱：sqrt(re^2 + im^2) / N * 2
 *   5. 查找峰值频率
 */
int FFT_Process(FFT_Handle *h, float *input)
{
    if (!h || !input) return -1;
    
    /* 复制输入信号 */
    memcpy(h->input_buf, input, FFT_N * sizeof(float));
    
    /* 执行实数FFT (输入被破坏为交错复数输出) */
    arm_rfft_fast_f32(&h->instance, h->input_buf, h->fft_buf, 0);
    
    /* 计算幅值谱 */
    /* DC分量 (index=0) */
    h->mag_buf[0] = fabsf(h->fft_buf[0]) / (float)FFT_N;
    
    /* 正频率分量 */
    for (uint32_t i = 1; i < FFT_N_HALF; i++) {
        float re = h->fft_buf[2 * i];       // 实部
        float im = h->fft_buf[2 * i + 1];   // 虚部
        h->mag_buf[i] = sqrtf(re * re + im * im) / (float)FFT_N * 2.0f;
    }
    
    /* 查找峰值 */
    FFT_FindPeak(h, h->mag_buf, FFT_N_HALF);
    
    /* 更新全局参数 */
    g_params.fft_peak_freq = h->peak_freq;
    g_params.fft_peak_mag  = h->peak_mag;
    
    return 0;
}

/**
 * @brief  在幅值谱中查找峰值 (跳过DC分量 index=0)
 */
void FFT_FindPeak(FFT_Handle *h, float *mag, uint32_t len)
{
    float max_val = 0.0f;
    uint32_t max_idx = 0;
    
    /* 从 index=1 开始，跳过DC分量 */
    for (uint32_t i = 1; i < len; i++) {
        if (mag[i] > max_val) {
            max_val = mag[i];
            max_idx = i;
        }
    }
    
    h->peak_mag  = max_val;
    h->peak_freq = (float)max_idx * h->freq_resolution;
}
