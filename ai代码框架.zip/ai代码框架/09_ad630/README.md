# 09_ad630 - AD630平衡调制/解调器驱动

## 功能概述

AD630是一款高精度平衡调制/解调器，在电赛中主要用于**模拟锁相放大**的信号解调。它通过方波参考信号控制内部开关，将输入信号与参考信号相乘，实现同步解调。

> **注意**：AD630是纯模拟器件，STM32不直接控制其内部逻辑。本驱动模块负责系统级参数管理和信号解算。

## 信号链路

```
AD9851激励 → DUT(被测网络) → AD603(增益控制) → AD630(解调) → LPF(低通) → ADC
                  ↓                                    ↑
            (信号输入)                          (参考方波, 同频)
```

## 锁相放大原理

### 数学模型

```
输入信号:  Vin = A·sin(ωt + θ)
参考信号:  Vref = square(ωt)  (方波)

方波傅里叶展开:
  square(t) = 4/π × [sin(ωt) + sin(3ωt)/3 + sin(5ωt)/5 + ...]

AD630输出 (相乘):
  Vout = A·sin(ωt+θ) × (±1)
  
经低通滤波后的直流分量:
  Vdc = (2A/π) × cos(θ)
```

### 信号还原公式

```
信号幅度:  A = Vdc × π / 2   (当 θ=0, 同相时)
信号峰峰值: Vpp = Vdc × π
```

## 文件列表

| 文件 | 说明 |
|------|------|
| `ad630.h` | 头文件：句柄结构体、接口声明 |
| `ad630.c` | 源文件：信号解算、阻抗计算、相位计算 |

## 硬件接线 (典型)

| AD630引脚 | 连接 | 说明 |
|-----------|------|------|
| Pin 1 (RIN A) | 前级信号 (AD603输出) | 通道A输入 |
| Pin 2 (CH A+) | GND | 通道A+ |
| Pin 3 (CH A-) | GND | 通道A- |
| Pin 9 (SEL B) | 参考方波 (AD9851+比较器) | 通道选择控制 |
| Pin 12 (VOUT) | 低通滤波器 → ADC | 解调输出 |
| Pin 13 (COMP) | 反馈补偿 | 接电容到GND |
| Pin 14,15 | ±15V电源 | 双电源供电 |
| Pin 16 (RIN B) | 前级信号 | 通道B输入 (与A同接) |

> **参考方波产生**：AD9851正弦波输出 → 高速比较器 (如LM311) → AD630 SEL B引脚

## 使用示例

### 基本锁相放大

```c
#include "ad630.h"
#include "ad9851.h"

AD630_Handle  ad630;
AD9851_Handle dds;

void setup_lockin(void)
{
    AD9851_Init(&dds);
    AD630_Init(&ad630);

    // 设置AD9851输出1kHz激励信号
    AD9851_SetFreq(&dds, 1000.0f, 0.0f);

    // 配置AD630: 1kHz参考, 系统增益=100
    AD630_SetRefFreq(&ad630, 1000.0f);
    AD630_SetSystemGain(&ad630, 100.0f);
}

void measure_signal(void)
{
    // ADC采集AD630低通滤波后的直流电压
    float demod_dc = read_adc_voltage();  // 假设1.5V

    // 计算原始信号幅度
    float vpp = AD630_CalcInputLevel(&ad630, demod_dc);
    // Vdc=1.5V, gain=100 → Vpp = 1.5×π/(2×100)×2 ≈ 47mVpp

    printf("Signal: %.1f mVpp\r\n", vpp * 1000.0f);
}
```

### 阻抗测量 (需双路AD630)

```c
// I路解调 (同相)
float v_dut_dc = read_adc_ch1();    // DUT电压
float v_rref_dc = read_adc_ch2();   // 电流采样电阻电压

// 计算阻抗
float impedance = AD630_CalcImpedance(&ad630,
    v_dut_dc, v_rref_dc, 1000.0f);  // R_ref=1kΩ

// I/Q双路计算相位
float i_dc = read_adc_ch1();
float q_dc = read_adc_ch3();  // Q路 (90°移相)
float phase = AD630_CalcPhase(i_dc, q_dc);

printf("Z=%.1fΩ, Phase=%.1f°\r\n", impedance, phase);
```

## 接口说明

| 函数 | 说明 |
|------|------|
| `AD630_Init(h)` | 初始化，默认锁相放大模式 |
| `AD630_SetMode(h, mode)` | 设置工作模式 |
| `AD630_SetRefFreq(h, freq)` | 设置参考频率 |
| `AD630_SetSystemGain(h, gain)` | 设置系统总增益 |
| `AD630_CalcInputLevel(h, dc)` | 从解调DC还原信号幅度 |
| `AD630_CalcImpedance(h, v, i, r)` | 计算阻抗模值 |
| `AD630_CalcPhase(i_dc, q_dc)` | 计算相位角 |

## 输出低通滤波器设计

AD630解调后需低通滤波去除2倍频分量：

```
截止频率选择: fc < 2×f_ref (一般取 f_ref/10 ~ f_ref/100)

示例 (f_ref = 1kHz):
  - 快速响应: fc=100Hz (τ≈1.6ms), 4阶Butterworth
  - 高精度: fc=10Hz (τ≈16ms), 4阶Butterworth
```

**推荐滤波器**：4阶Sallen-Key低通，截止频率可通过模拟开关切换。

## 电赛应用场景

| 场景 | 配置 | 说明 |
|------|------|------|
| **微弱信号检测** | AD603+AD630+LPF | nV级信号提取 |
| **LCR表** | AD9851扫频+双路AD630 | 幅值+相位测量 |
| **阻抗分析仪** | 扫频激励+I/Q解调 | 频率响应曲线 |
| **锁相放大器** | AD630+数字锁相(05_lockin) | 模拟+数字混合 |

## 注意事项

1. **双电源供电**：AD630需要±15V或±5V双电源
2. **参考信号幅度**：SEL B引脚需要足够的方波幅度 (>100mV)
3. **输出偏移**：AD630输出有约几mV的直流偏移，需软件校准
4. **低通滤波**：解调后的低通滤波器直接决定系统的等效噪声带宽(ENBW)
5. **PCB布局**：模拟信号走线尽量短，远离数字信号

## 依赖

- `dsp_common.h` (更新 `g_params.ad630_*`)
- `math.h`
