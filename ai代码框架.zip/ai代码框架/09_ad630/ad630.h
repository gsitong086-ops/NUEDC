/**
 * @file    ad630.h
 * @brief   AD630平衡调制/解调器驱动模块
 * @author  电赛DSP通用库
 * @date    2025-07
 * 
 * AD630是一款高精度平衡调制/解调器，可用于：
 *   - 锁相放大 (信号解调)
 *   - 平衡调制
 *   - 同步解调
 *   - 相位敏感检测
 * 
 * 在电赛中的典型应用：
 *   信号输入 ──→ AD603增益控制 ──→ AD630解调 ──→ 低通滤波 ──→ ADC采集
 *                                        ↑
 *                            AD9851参考信号
 * 
 * AD630输出包含：
 *   - 直流分量 = 与参考同频信号的幅度信息
 *   - 高频分量 = 2倍频分量 (需低通滤波去除)
 * 
 * 本驱动模块管理AD630的工作模式切换和系统级增益计算。
 * 实际的信号处理链路：
 *   AD9851 → 被测网络(DUT) → AD603 → AD630 → 低通 → STM32 ADC
 *                ↑                        ↑
 *          (激励信号)              (参考信号, 同频)
 */

#ifndef __AD630_H
#define __AD630_H

#include "dsp_common.h"

/* ================================================================
 * AD630句柄
 * ================================================================ */
typedef struct {
    AD630_Mode  mode;           // 工作模式
    float       ref_freq;       // 参考频率 (Hz)
    float       system_gain;    // 系统总增益 (含AD603)
    float       output_dc;      // 解调直流输出 (V)
    float       input_level;    // 输入信号幅度 (Vpp)
    uint8_t     initialized;    // 初始化标志
} AD630_Handle;

/* ================================================================
 * 接口函数
 * ================================================================ */

/**
 * @brief  初始化AD630模块
 * @param  h  AD630句柄指针
 * @note   默认锁相放大模式
 */
void AD630_Init(AD630_Handle *h);

/**
 * @brief  设置工作模式
 * @param  h     AD630句柄指针
 * @param  mode  工作模式
 */
void AD630_SetMode(AD630_Handle *h, AD630_Mode mode);

/**
 * @brief  设置参考频率 (通常由AD9851提供)
 * @param  h     AD630句柄指针
 * @param  freq  参考频率 (Hz)
 */
void AD630_SetRefFreq(AD630_Handle *h, float freq);

/**
 * @brief  设置系统增益
 * @param  h     AD630句柄指针
 * @param  gain  总增益倍数 (线性)
 * 
 * @note   系统总增益 = AD603增益 × AD630增益 × 后级增益
 *         用于计算原始输入信号幅度
 */
void AD630_SetSystemGain(AD630_Handle *h, float gain);

/**
 * @brief  从解调结果计算原始信号幅度
 * @param  h           AD630句柄指针
 * @param  demod_dc    解调后的直流电压 (V)
 * @return 原始信号幅度 (Vpp)
 * 
 * 公式: V_in = V_dc × π / (2 × system_gain)
 *       对于方波参考信号，需乘以 π/2 系数
 */
float AD630_CalcInputLevel(AD630_Handle *h, float demod_dc);

/**
 * @brief  计算阻抗 (用于阻抗测量)
 * @param  h           AD630句柄指针
 * @param  v_measured  测得的电压 (V)
 * @param  i_measured  测得的电流对应电压 (V)
 * @param  r_ref       电流采样电阻 (Ω)
 * @return 阻抗模值 (Ω)
 * 
 * 典型电路: 激励信号 → DUT → R_ref → GND
 *           测量DUT两端电压和R_ref两端电压
 *           阻抗 = V_dut / I = V_dut × R_ref / V_rref
 */
float AD630_CalcImpedance(AD630_Handle *h, float v_measured,
                          float i_measured, float r_ref);

/**
 * @brief  计算相位角 (需要I/Q两路解调)
 * @param  i_dc  I路解调直流 (同相分量)
 * @param  q_dc  Q路解调直流 (正交分量)
 * @return 相位角 (度)，范围 -180 ~ +180
 * 
 * @note   Q路需要90°移相器或第二路AD630
 */
float AD630_CalcPhase(float i_dc, float q_dc);

#endif /* __AD630_H */
