/**
 * @file    ad630.c
 * @brief   AD630平衡调制/解调器驱动实现
 * 
 * AD630在锁相放大中的工作原理：
 * 
 * 设输入信号:  Vin = A·sin(ωt + θ)
 * 参考信号:    Vref = square_wave(ωt)  (方波, 由比较器产生)
 * 
 * AD630内部开关将输入信号与参考方波相乘 (相当于±1调制):
 *   Vout = Vin × (±1)
 * 
 * 方波傅里叶展开: square(t) = 4/π × Σ sin((2k+1)ωt) / (2k+1)
 * 
 * 输出直流分量:
 *   Vdc = 2A/π × cos(θ)  (经过低通滤波后)
 * 
 * 因此信号幅度: A = Vdc × π/2  (当 θ=0 时)
 * 
 * 完整信号链:
 *   AD9851 → DUT → AD603 → AD630 → LPF → ADC
 *                 ↑                        ↑
 *           (激励)                   (参考, 同频方波)
 * 
 * 注意: AD630本身是模拟器件，STM32不直接控制其内部逻辑。
 * 本驱动模块负责系统级参数管理和信号解算。
 */

#include "ad630.h"
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

/**
 * @brief  初始化AD630模块
 */
void AD630_Init(AD630_Handle *h)
{
    h->mode         = AD630_MODE_LOCKIN;
    h->ref_freq     = 1000.0f;
    h->system_gain  = 1.0f;
    h->output_dc    = 0.0f;
    h->input_level  = 0.0f;
    h->initialized  = 1;

    /* 同步全局参数 */
    g_params.ad630_mode     = h->mode;
    g_params.ad630_ref_freq = h->ref_freq;
    g_params.ad630_gain     = h->system_gain;
    g_params.ad630_output   = h->output_dc;
}

/**
 * @brief  设置工作模式
 */
void AD630_SetMode(AD630_Handle *h, AD630_Mode mode)
{
    if (!h->initialized) return;
    h->mode = mode;
    g_params.ad630_mode = mode;
}

/**
 * @brief  设置参考频率
 */
void AD630_SetRefFreq(AD630_Handle *h, float freq)
{
    if (!h->initialized) return;
    h->ref_freq = freq;
    g_params.ad630_ref_freq = freq;
}

/**
 * @brief  设置系统总增益
 */
void AD630_SetSystemGain(AD630_Handle *h, float gain)
{
    if (!h->initialized) return;
    h->system_gain = gain;
    g_params.ad630_gain = gain;
}

/**
 * @brief  从解调直流电压计算原始信号幅度
 * 
 * 公式推导:
 *   方波参考信号与正弦输入相乘:
 *     Vdc = (2/π) × A × cos(θ) × system_gain
 *   
 *   当 θ=0 (同相) 时:
 *     Vdc = (2/π) × A × system_gain
 *     A = Vdc × π / (2 × system_gain)
 * 
 * @param  demod_dc  经过低通滤波后的直流电压 (V)
 * @return 原始信号幅度 (Vpp = 2A)
 */
float AD630_CalcInputLevel(AD630_Handle *h, float demod_dc)
{
    if (!h->initialized || h->system_gain < 0.001f) return 0.0f;

    /* 计算信号峰值幅度 */
    float a_peak = fabsf(demod_dc) * (float)M_PI / (2.0f * h->system_gain);

    h->output_dc   = demod_dc;
    h->input_level = a_peak * 2.0f;  /* Vpp */

    /* 更新全局参数 */
    g_params.ad630_output = demod_dc;

    return h->input_level;
}

/**
 * @brief  计算阻抗模值
 * 
 * 典型阻抗测量电路:
 *   AD9851激励 ──→ DUT ──→ R_ref ──→ GND
 *                    │        │
 *              V_dut测量    V_rref测量
 * 
 *   I = V_rref / R_ref
 *   Z = V_dut / I = V_dut × R_ref / V_rref
 * 
 * @param  v_measured  DUT两端电压 (经AD630解调后的直流)
 * @param  i_measured  R_ref两端电压 (经AD630解调后的直流)
 * @param  r_ref       电流采样电阻值 (Ω)
 * @return 阻抗模值 |Z| (Ω)
 */
float AD630_CalcImpedance(AD630_Handle *h, float v_measured,
                          float i_measured, float r_ref)
{
    if (!h->initialized) return 0.0f;
    if (fabsf(i_measured) < 1e-9f) return 1e9f;  /* 开路 */

    /* 先还原真实电压值 (去除解调系数) */
    float v_real = v_measured * (float)M_PI / 2.0f;
    float i_real = i_measured * (float)M_PI / 2.0f;

    /* 计算电流和阻抗 */
    float current = i_real / r_ref;
    float impedance = v_real / current;

    return impedance;
}

/**
 * @brief  计算相位角 (需要I/Q双路解调)
 * 
 * 双路AD630配置:
 *   I路: 参考信号与AD9851同相
 *   Q路: 参考信号经过90°移相
 * 
 * 相位计算公式:
 *   θ = atan2(Q_dc, I_dc) × 180/π
 * 
 * @param  i_dc  I路解调直流 (V)
 * @param  q_dc  Q路解调直流 (V)
 * @return 相位角 (度)
 */
float AD630_CalcPhase(float i_dc, float q_dc)
{
    float phase_rad = atan2f(q_dc, i_dc);
    float phase_deg = phase_rad * 180.0f / (float)M_PI;

    return phase_deg;
}
