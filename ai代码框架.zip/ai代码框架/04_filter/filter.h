/**
 * @file    filter.h
 * @brief   数字滤波模块 - IIR Biquad级联滤波器
 * @author  电赛DSP通用库
 * @date    2025-07
 * 
 * 基于CMSIS-DSP的 arm_biquad_cascade_df1_f32 实现。
 * 支持低通/高通/带通/带阻四种类型，最多8阶级联。
 * 
 * 滤波器系数推荐使用Python scipy.signal计算：
 *   from scipy.signal import butter
 *   b, a = butter(order, Wn, btype, analog=False)
 *   将b,a转换为Biquad级联系数
 */

#ifndef __FILTER_H
#define __FILTER_H

#include "dsp_common.h"
#include "arm_math.h"

/* ================================================================
 * 配置宏
 * ================================================================ */
#define FILTER_MAX_ORDER    8       // 最大阶数
#define FILTER_MAX_STAGES   (FILTER_MAX_ORDER / 2)  // 最大级数
#define FILTER_COEFFS_PER_STAGE 5   // 每级系数: [b0, b1, b2, a1, a2]

/* ================================================================
 * 滤波器句柄
 * ================================================================ */
typedef struct {
    arm_biquad_casd_df1_inst_f32 instance;      // CMSIS-DSP Biquad实例
    float state_buf[4 * FILTER_MAX_STAGES];     // 状态缓冲 (每级4个状态)
    float coeffs[5 * FILTER_MAX_STAGES];        // 系数数组
    uint8_t num_stages;                          // 当前级数
    uint8_t enabled;                             // 使能标志
} FilterHandle;

/* ================================================================
 * 接口函数
 * ================================================================ */

/**
 * @brief  初始化滤波器
 * @param  h     滤波器句柄指针
 * @param  order 阶数 (2/4/6/8)
 * @param  type  滤波器类型
 * @param  fc    截止频率 (Hz)
 * @param  fc2   第二截止频率 (Hz, 仅带通/带阻使用)
 * @param  fs    采样率 (Hz)
 * @return 0=成功, -1=参数无效
 * 
 * @note   系数生成逻辑较复杂，建议在PC端用Python预计算系数，
 *         或在此函数中实现完整的模拟滤波器→双线性变换→级联分解
 */
int Filter_Init(FilterHandle *h, uint8_t order, FilterType type,
                float fc, float fc2, float fs);

/**
 * @brief  手动设置滤波器系数 (推荐方式)
 * @param  h         滤波器句柄指针
 * @param  coeffs    系数数组 [b0,b1,b2,a1,a2] × num_stages
 * @param  num_stages 级数
 * @return 0=成功
 * 
 * 系数由Python scipy计算后通过串口下发
 */
int Filter_SetCoeffs(FilterHandle *h, float *coeffs, uint8_t num_stages);

/**
 * @brief  执行滤波
 * @param  h      滤波器句柄指针
 * @param  input  输入数据
 * @param  output 输出数据
 * @param  len    数据长度
 * @return 0=成功
 */
int Filter_Process(FilterHandle *h, float *input, float *output, uint32_t len);

/**
 * @brief  使能/禁用滤波器
 */
void Filter_Enable(FilterHandle *h, uint8_t en);

#endif /* __FILTER_H */
