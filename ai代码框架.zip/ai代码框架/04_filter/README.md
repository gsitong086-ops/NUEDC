# 04_filter - 数字滤波模块

## 功能概述

基于CMSIS-DSP的 `arm_biquad_cascade_df1_f32` 实现IIR双二阶级联滤波器。支持低通、高通、带通、带阻四种类型，最多8阶（4级）级联。

> **推荐工作流**：在PC端用Python `scipy.signal` 计算精确系数，通过串口下发到MCU，调用 `Filter_SetCoeffs()` 加载。

## 文件列表

| 文件 | 说明 |
|------|------|
| `filter.h` | 头文件：滤波器句柄、接口声明 |
| `filter.c` | 源文件：系数设置、滤波执行 |

## 核心数据结构

```c
typedef struct {
    arm_biquad_casd_df1_inst_f32 instance;  // CMSIS-DSP实例
    float state_buf[4 * FILTER_MAX_STAGES]; // 状态缓冲
    float coeffs[5 * FILTER_MAX_STAGES];    // 系数 [b0,b1,b2,a1,a2]×级数
    uint8_t num_stages;                      // 当前级数
    uint8_t enabled;                         // 使能标志
} FilterHandle;
```

## Biquad 系数格式

每级5个系数（a0=1已归一化）：

```
[b0, b1, b2, a1, a2]
```

CMSIS-DSP内部使用的差分方程：
```
y[n] = b0*x[n] + b1*x[n-1] + b2*x[n-2] - a1*y[n-1] - a2*y[n-2]
```

## Python 系数计算

### 低通滤波器

```python
from scipy.signal import butter

# 4阶低通, fc=1kHz, fs=20kHz
sos = butter(4, 1000, btype='low', fs=20000, output='sos')

for row in sos:
    # sos格式: [b0, b1, b2, 1.0, a1, a2]
    # 输出: b0, b1, b2, a1, a2
    print(f"{row[0]:.10f}f, {row[1]:.10f}f, {row[2]:.10f}f, "
          f"{row[4]:.10f}f, {row[5]:.10f}f")
```

### 带通滤波器

```python
from scipy.signal import butter

# 4阶带通, fc=[500, 2000]Hz, fs=20kHz
sos = butter(4, [500, 2000], btype='bandpass', fs=20000, output='sos')

for row in sos:
    print(f"{row[0]:.10f}f, {row[1]:.10f}f, {row[2]:.10f}f, "
          f"{row[4]:.10f}f, {row[5]:.10f}f")
```

## 使用示例

```c
#include "filter.h"

FilterHandle lp_filter;

// 方式1：简化初始化 (仅2阶低通)
Filter_Init(&lp_filter, 2, FILTER_LOWPASS, 1000.0f, 0, 20000.0f);

// 方式2：手动设置系数 (推荐)
float coeffs_4th_lp[] = {
    // 第1级: [b0, b1, b2, a1, a2]
    0.02008337f, 0.04016673f, 0.02008337f, -1.56101808f, 0.64135154f,
    // 第2级
    0.02008337f, 0.04016673f, 0.02008337f, -1.56101808f, 0.64135154f
};
Filter_SetCoeffs(&lp_filter, coeffs_4th_lp, 2);

// 执行滤波
float input[1024], output[1024];
// ... 填充input ...
Filter_Process(&lp_filter, input, output, 1024);
```

## 接口说明

| 函数 | 说明 |
|------|------|
| `Filter_Init(h, order, type, fc, fc2, fs)` | 自动初始化 (仅支持2阶低通) |
| `Filter_SetCoeffs(h, coeffs, stages)` | **推荐**：手动设置精确系数 |
| `Filter_Process(h, input, output, len)` | 执行滤波 |
| `Filter_Enable(h, en)` | 使能/禁用 |

## 滤波器类型

| 枚举 | 说明 | fc参数 | fc2参数 |
|------|------|--------|---------|
| `FILTER_LOWPASS` | 低通 | 截止频率 | 忽略 |
| `FILTER_HIGHPASS` | 高通 | 截止频率 | 忽略 |
| `FILTER_BANDPASS` | 带通 | 下限频率 | 上限频率 |
| `FILTER_BANDSTOP` | 带阻 | 下限频率 | 上限频率 |

## 依赖

- `dsp_common.h` (使用 `g_params.filter_*` 参数)
- `arm_math.h` (CMSIS-DSP库)
- `math.h`
