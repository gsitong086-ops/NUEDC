/**
 * @file    filter.c
 * @brief   数字滤波模块实现
 * 
 * 系数计算说明：
 *   本模块提供滤波器框架，推荐在PC端用Python预计算系数，
 *   然后通过 Filter_SetCoeffs() 手动设置。
 * 
 *   Python示例代码：
 *   ```
 *   from scipy.signal import butter, tf2sos
 *   
 *   # 设计4阶低通, fc=1kHz, fs=20kHz
 *   sos = butter(4, 1000, btype='low', fs=20000, output='sos')
 *   
 *   # sos格式: [b0, b1, b2, 1.0, a1, a2] 每行一级
 *   # 转换为本模块格式: [b0, b1, b2, a1, a2]  (去掉a0=1.0)
 *   for row in sos:
 *       print(f"{row[0]:.10f}, {row[1]:.10f}, {row[2]:.10f}, "
 *             f"{row[4]:.10f}, {row[5]:.10f}")
 *   ```
 */

#include "filter.h"
#include <string.h>
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

/**
 * @brief  初始化滤波器 (自动计算系数)
 * 
 * @note   当前为简化实现，仅计算2阶低通。
 *         推荐使用 Filter_SetCoeffs() 手动设置精确系数。
 */
int Filter_Init(FilterHandle *h, uint8_t order, FilterType type,
                float fc, float fc2, float fs)
{
    if (!h || order < 2 || order > FILTER_MAX_ORDER || order % 2 != 0)
        return -1;
    
    uint8_t stages = order / 2;
    
    /* 简化实现：仅支持2阶低通 */
    if (stages == 1 && type == FILTER_LOWPASS) {
        /* 2阶低通 - 双线性变换法 */
        float omega = 2.0f * M_PI * fc / fs;
        float sn = sinf(omega);
        float cs = cosf(omega);
        float alpha = sn / (2.0f * 0.7071f);  // Q = 0.7071 (Butterworth)
        
        float b0 = (1.0f - cs) / 2.0f;
        float b1 =  1.0f - cs;
        float b2 = (1.0f - cs) / 2.0f;
        float a0 =  1.0f + alpha;
        float a1 = -2.0f * cs;
        float a2 =  1.0f - alpha;
        
        /* 归一化 */
        h->coeffs[0] = b0 / a0;
        h->coeffs[1] = b1 / a0;
        h->coeffs[2] = b2 / a0;
        h->coeffs[3] = -a1 / a0;  /* CMSIS-DSP用负的反馈系数 */
        h->coeffs[4] = -a2 / a0;
        
        h->num_stages = 1;
    } else {
        /* 高阶或其他类型请使用 Filter_SetCoeffs() */
        return -1;
    }
    
    /* 初始化CMSIS-DSP Biquad实例 */
    arm_biquad_cascade_df1_init_f32(&h->instance, h->num_stages,
                                     h->coeffs, h->state_buf);
    h->enabled = 1;
    
    return 0;
}

/**
 * @brief  手动设置滤波器系数
 * 
 * @param  coeffs  系数格式: [b0,b1,b2,a1,a2] × num_stages
 *                 其中 a0=1 已归一化
 */
int Filter_SetCoeffs(FilterHandle *h, float *coeffs, uint8_t num_stages)
{
    if (!h || !coeffs || num_stages > FILTER_MAX_STAGES)
        return -1;
    
    memcpy(h->coeffs, coeffs, num_stages * FILTER_COEFFS_PER_STAGE * sizeof(float));
    h->num_stages = num_stages;
    
    arm_biquad_cascade_df1_init_f32(&h->instance, h->num_stages,
                                     h->coeffs, h->state_buf);
    h->enabled = 1;
    
    return 0;
}

/**
 * @brief  执行滤波
 */
int Filter_Process(FilterHandle *h, float *input, float *output, uint32_t len)
{
    if (!h || !input || !output || !h->enabled)
        return -1;
    
    arm_biquad_cascade_df1_f32(&h->instance, input, output, len);
    
    return 0;
}

/**
 * @brief  使能/禁用滤波器
 */
void Filter_Enable(FilterHandle *h, uint8_t en)
{
    if (h) h->enabled = en;
}
