/**
 * @file    dsp_common.c
 * @brief   DSP公共参数管理模块实现 (含外置模块参数)
 */

#include "dsp_common.h"

/* ---- 采样率档位对应的实际频率值 ---- */
static const float fs_table[FS_COUNT] = {
    100.0f,    // FS_100HZ
    500.0f,    // FS_500HZ
    1000.0f,   // FS_1KHZ
    2000.0f,   // FS_2KHZ
    5000.0f,   // FS_5KHZ
    10000.0f,  // FS_10KHZ
    20000.0f,  // FS_20KHZ
    50000.0f,  // FS_50KHZ
    100000.0f, // FS_100KHZ
    200000.0f, // FS_200KHZ
    500000.0f, // FS_500KHZ
    1000000.0f // FS_1MHZ
};

/* ---- 全局参数实例 ---- */
DspParams g_params;

/**
 * @brief  初始化全局参数为默认值
 */
void DspParams_Init(void)
{
    g_params.fs_index     = FS_20KHZ;
    g_params.fs_actual    = fs_table[FS_20KHZ];
    g_params.fft_peak_freq = 0.0f;
    g_params.fft_peak_mag  = 0.0f;
    g_params.filter_type   = FILTER_LOWPASS;
    g_params.filter_cutoff = 1000.0f;
    g_params.filter_cutoff2 = 2000.0f;
    g_params.filter_order  = 4;
    g_params.lockin_ref_freq = 1000.0f;
    g_params.lockin_tau      = 0.01f;
    g_params.lockin_amplitude = 0.0f;
    g_params.lockin_phase     = 0.0f;
    g_params.dac_wave_type    = WAVE_SINE;
    g_params.dac_freq         = 1000.0f;
    g_params.dac_amplitude    = 0.5f;
    g_params.dac_offset       = 0.5f;
    g_params.dac_update_rate  = 20000.0f;

    /* AD603 默认增益 0dB */
    g_params.ad603_gain_db  = 0.0f;
    g_params.ad603_vctrl    = 0.5f;

    /* AD9851 默认 1MHz 单频输出 */
    g_params.ad9851_mode        = AD9851_MODE_SINGLE_TONE;
    g_params.ad9851_freq        = 1000000.0f;
    g_params.ad9851_phase       = 0.0f;
    g_params.ad9851_fsk_freq    = 1100000.0f;
    g_params.ad9851_sweep_start = 100000.0f;
    g_params.ad9851_sweep_stop  = 10000000.0f;
    g_params.ad9851_sweep_step  = 10000.0f;
    g_params.ad9851_sweep_dwell = 10.0f;
    g_params.ad9851_power_down  = 0;

    /* AD630 默认锁相放大模式 */
    g_params.ad630_mode     = AD630_MODE_LOCKIN;
    g_params.ad630_ref_freq = 1000.0f;
    g_params.ad630_gain     = 1.0f;
    g_params.ad630_output   = 0.0f;

    g_params.running = 0;
}

/**
 * @brief  设置采样率档位
 * @param  idx  采样率档位枚举值
 */
void DspParams_SetFs(SampleRateIndex idx)
{
    if (idx < FS_COUNT) {
        g_params.fs_index  = idx;
        g_params.fs_actual = fs_table[idx];
    }
}
