/**
 * @file    dsp_common.h
 * @brief   DSP公共参数管理模块 - 全局参数定义 (含外置模块)
 * @author  电赛DSP通用库
 * @date    2025-07
 * 
 * 本模块定义所有DSP处理模块共享的全局参数结构体，
 * 便于AI/上位机通过串口统一调参。
 * 
 * 新增外置模块参数：AD603、AD9851、AD630
 */

#ifndef __DSP_COMMON_H
#define __DSP_COMMON_H

#include "main.h"

/* ================================================================
 * 采样率档位枚举
 * ================================================================ */
typedef enum {
    FS_100HZ = 0,       // 100 Hz
    FS_500HZ,           // 500 Hz
    FS_1KHZ,            // 1 kHz
    FS_2KHZ,            // 2 kHz
    FS_5KHZ,            // 5 kHz
    FS_10KHZ,           // 10 kHz
    FS_20KHZ,           // 20 kHz
    FS_50KHZ,           // 50 kHz
    FS_100KHZ,          // 100 kHz
    FS_200KHZ,          // 200 kHz
    FS_500KHZ,          // 500 kHz
    FS_1MHZ,            // 1 MHz (接近F407极限)
    FS_COUNT
} SampleRateIndex;

/* ================================================================
 * 滤波器类型枚举
 * ================================================================ */
typedef enum {
    FILTER_LOWPASS = 0,     // 低通
    FILTER_HIGHPASS,        // 高通
    FILTER_BANDPASS,        // 带通
    FILTER_BANDSTOP         // 带阻
} FilterType;

/* ================================================================
 * DAC波形类型枚举
 * ================================================================ */
typedef enum {
    WAVE_SINE = 0,      // 正弦波
    WAVE_SQUARE,        // 方波
    WAVE_TRIANGLE       // 三角波
} WaveType;

/* ================================================================
 * AD9851 工作模式枚举
 * ================================================================ */
typedef enum {
    AD9851_MODE_SINGLE_TONE = 0,    // 单频输出
    AD9851_MODE_FSK,                // FSK调制
    AD9851_MODE_SWEEP               // 扫频模式
} AD9851_Mode;

/* ================================================================
 * AD630 工作模式枚举
 * ================================================================ */
typedef enum {
    AD630_MODE_LOCKIN = 0,          // 锁相放大模式
    AD630_MODE_MODULATOR,           // 调制器模式
    AD630_MODE_DEMODULATOR          // 解调器模式
} AD630_Mode;

/* ================================================================
 * 全局参数结构体
 * ================================================================ */
typedef struct {
    /* ---- ADC采样 ---- */
    SampleRateIndex fs_index;       // 采样率档位
    float           fs_actual;      // 实际采样率 (Hz)

    /* ---- FFT ---- */
    float   fft_peak_freq;          // FFT峰值频率 (Hz)
    float   fft_peak_mag;           // FFT峰值幅度

    /* ---- 滤波器 ---- */
    FilterType  filter_type;        // 滤波类型
    float       filter_cutoff;      // 截止频率 (Hz)
    float       filter_cutoff2;     // 第二截止频率 (带通/带阻用)
    uint8_t     filter_order;       // 滤波器阶数 (2/4/6/8)

    /* ---- 锁相放大 ---- */
    float   lockin_ref_freq;        // 参考频率 (Hz)
    float   lockin_tau;             // 低通时间常数 (s)
    float   lockin_amplitude;       // 锁相输出幅度
    float   lockin_phase;           // 锁相输出相位 (度)

    /* ---- DAC输出 ---- */
    WaveType    dac_wave_type;      // 输出波形类型
    float       dac_freq;           // 输出频率 (Hz)
    float       dac_amplitude;      // 输出幅度 (0~1.0)
    float       dac_offset;         // 直流偏置 (0~1.0)
    float       dac_update_rate;    // DAC更新率 (Hz)

    /* ---- AD603 程控增益 ---- */
    float       ad603_gain_db;      // 目标增益 (dB)，范围 -10 ~ +30
    float       ad603_vctrl;        // 当前控制电压 (V)，范围 0 ~ 1.0

    /* ---- AD9851 DDS模块 ---- */
    AD9851_Mode ad9851_mode;        // 工作模式
    float       ad9851_freq;        // 输出频率 (Hz)，范围 1 ~ 70M
    float       ad9851_phase;       // 相位偏移 (度)
    float       ad9851_fsk_freq;    // FSK第二频率 (Hz)
    float       ad9851_sweep_start; // 扫频起始频率 (Hz)
    float       ad9851_sweep_stop;  // 扫频终止频率 (Hz)
    float       ad9851_sweep_step;  // 扫频步进 (Hz)
    float       ad9851_sweep_dwell; // 每步驻留时间 (ms)
    uint8_t     ad9851_power_down;  // 省电模式标志

    /* ---- AD630 平衡调制解调 ---- */
    AD630_Mode  ad630_mode;         // 工作模式
    float       ad630_ref_freq;     // 参考频率 (Hz)，实际由AD9851提供
    float       ad630_gain;         // 系统总增益
    float       ad630_output;       // AD630输出值 (V)

    /* ---- 系统 ---- */
    uint8_t     running;            // 运行状态标志
} DspParams;

/* ================================================================
 * 全局参数实例 (定义在 dsp_common.c)
 * ================================================================ */
extern DspParams g_params;

/* ================================================================
 * 公共接口函数
 * ================================================================ */
void DspParams_Init(void);
void DspParams_SetFs(SampleRateIndex idx);

#endif /* __DSP_COMMON_H */
