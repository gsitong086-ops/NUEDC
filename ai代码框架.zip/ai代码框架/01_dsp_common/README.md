# 01_dsp_common - DSP公共参数管理模块

## 功能概述

定义所有DSP处理模块共享的全局参数结构体，提供统一的参数管理接口。所有模块通过 `g_params` 全局变量访问和修改参数，便于AI或上位机通过串口统一调参。

**已集成外置模块参数：AD603程控增益、AD9851 DDS、AD630平衡调制解调。**

## 文件列表

| 文件 | 说明 |
|------|------|
| `dsp_common.h` | 头文件：参数结构体定义、枚举类型、接口声明 |
| `dsp_common.c` | 源文件：参数初始化、采样率设置等实现 |

## 核心数据结构

### DspParams 结构体 (完整版)

```c
typedef struct {
    /* ---- ADC采样 ---- */
    SampleRateIndex fs_index;       // 采样率档位
    float           fs_actual;      // 实际采样率 (Hz)

    /* ---- FFT ---- */
    float   fft_peak_freq;          // FFT峰值频率
    float   fft_peak_mag;           // FFT峰值幅度

    /* ---- 滤波器 ---- */
    FilterType  filter_type;        // 滤波器类型
    float       filter_cutoff;      // 截止频率1
    float       filter_cutoff2;     // 截止频率2
    uint8_t     filter_order;       // 滤波器阶数

    /* ---- 锁相放大 ---- */
    float   lockin_ref_freq;        // 锁相参考频率
    float   lockin_tau;             // 锁相时间常数
    float   lockin_amplitude;       // 锁相幅度输出
    float   lockin_phase;           // 锁相相位输出

    /* ---- DAC输出 ---- */
    WaveType    dac_wave_type;      // DAC波形类型
    float       dac_freq;           // DAC输出频率
    float       dac_amplitude;      // DAC输出幅度
    float       dac_offset;         // DAC直流偏置
    float       dac_update_rate;    // DAC更新率

    /* ---- AD603 程控增益 ---- */
    float       ad603_gain_db;      // 目标增益 (dB)，-10 ~ +30
    float       ad603_vctrl;        // 控制电压 (V)，0 ~ 1.0

    /* ---- AD9851 DDS模块 ---- */
    AD9851_Mode ad9851_mode;        // 工作模式
    float       ad9851_freq;        // 输出频率 (Hz)
    float       ad9851_phase;       // 相位偏移 (度)
    float       ad9851_fsk_freq;    // FSK第二频率
    float       ad9851_sweep_start; // 扫频起始
    float       ad9851_sweep_stop;  // 扫频终止
    float       ad9851_sweep_step;  // 扫频步进
    float       ad9851_sweep_dwell; // 驻留时间 (ms)
    uint8_t     ad9851_power_down;  // 省电标志

    /* ---- AD630 平衡调制解调 ---- */
    AD630_Mode  ad630_mode;         // 工作模式
    float       ad630_ref_freq;     // 参考频率
    float       ad630_gain;         // 系统总增益
    float       ad630_output;       // 输出值 (V)

    /* ---- 系统 ---- */
    uint8_t     running;            // 运行标志
} DspParams;
```

## 采样率档位

| 档位 | 频率 | 适用场景 |
|------|------|----------|
| FS_100HZ | 100 Hz | 低频信号、温度/压力传感 |
| FS_500HZ | 500 Hz | 生物电信号 |
| FS_1KHZ | 1 kHz | 电网谐波 |
| FS_5KHZ | 5 kHz | 音频低段 |
| FS_10KHZ | 10 kHz | 通用音频 |
| FS_20KHZ | 20 kHz | 音频全频段 |
| FS_50KHZ | 50 kHz | 超声波 |
| FS_100KHZ | 100 kHz | 高频测量 |
| FS_200KHZ | 200 kHz | 高速信号 |
| FS_500KHZ | 500 kHz | 极速采样 |
| FS_1MHZ | 1 MHz | F407极限 |

## 使用示例

```c
#include "dsp_common.h"

// 初始化
DspParams_Init();

// 切换采样率
DspParams_SetFs(FS_50KHZ);

// 设置AD603增益为20dB
g_params.ad603_gain_db = 20.0f;

// 设置AD9851输出10MHz
g_params.ad9851_freq = 10000000.0f;

// 设置AD630为锁相放大模式
g_params.ad630_mode     = AD630_MODE_LOCKIN;
g_params.ad630_ref_freq = 1000.0f;
```

## 依赖

- `main.h` (HAL库)
- 无其他模块依赖（本模块为最底层公共模块）
