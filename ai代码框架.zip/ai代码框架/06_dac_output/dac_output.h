/**
 * @file    dac_output.h
 * @brief   DDS波形输出模块 - 相位累加填表 + 定时器触发DAC DMA
 * @author  电赛DSP通用库
 * @date    2025-07
 * 
 * 支持正弦波、方波、三角波输出。
 * 通过相位累加器实现任意频率的DDS信号生成。
 */

#ifndef __DAC_OUTPUT_H
#define __DAC_OUTPUT_H

#include "dsp_common.h"
#include "arm_math.h"

/* ================================================================
 * 配置宏
 * ================================================================ */
#define DAC_BUF_LEN     256     // DAC波形表长度
#define DAC_MAX_VAL     4095    // 12位DAC最大值

/* ================================================================
 * DAC句柄
 * ================================================================ */
typedef struct {
    uint16_t    wave_table[DAC_BUF_LEN];   // 波形查找表
    float       freq;                       // 当前输出频率 (Hz)
    float       amplitude;                  // 输出幅度 (0~1.0)
    float       offset;                     // 直流偏置 (0~1.0)
    WaveType    wave_type;                  // 波形类型
    float       update_rate;                // DAC更新率 (Hz)
    uint8_t     running;                    // 运行标志
} DacOutput;

/* ================================================================
 * 接口函数
 * ================================================================ */

/**
 * @brief  初始化DAC输出
 * @param  dac  DAC句柄指针
 */
void DAC_Init(DacOutput *dac);

/**
 * @brief  生成波形查找表
 * @param  dac   DAC句柄指针
 * @param  type  波形类型 (正弦/方波/三角波)
 * @param  freq  输出频率 (Hz)
 * @param  amp   幅度 (0~1.0)
 * @param  offset 直流偏置 (0~1.0)
 * @param  update_rate DAC更新率 (Hz)
 * @return 0=成功, -1=频率超过奈奎斯特极限
 */
int DAC_SetWave(DacOutput *dac, WaveType type, float freq,
                float amp, float offset, float update_rate);

/**
 * @brief  启动DAC输出
 */
void DAC_Start(DacOutput *dac);

/**
 * @brief  停止DAC输出
 */
void DAC_Stop(DacOutput *dac);

/**
 * @brief  设置输出幅度 (无需重建波形表)
 * @param  dac  DAC句柄指针
 * @param  amp  幅度 (0~1.0)
 */
void DAC_SetAmplitude(DacOutput *dac, float amp);

/**
 * @brief  设置直流偏置 (无需重建波形表)
 * @param  dac     DAC句柄指针
 * @param  offset  偏置 (0~1.0)
 */
void DAC_SetOffset(DacOutput *dac, float offset);

#endif /* __DAC_OUTPUT_H */
