/**
 * @file    dac_output.c
 * @brief   DDS波形输出模块实现
 * 
 * 依赖CubeMX配置：
 *   - DAC通道使能 (如 DAC1 Channel 1 → PA4)
 *   - TIMx TRGO触发DAC
 *   - DMA循环模式，半字→半字，指向 wave_table
 * 
 * DDS原理：
 *   输出频率 = (频率控制字 / 2^N) × 更新率
 *   频率控制字 = f_out / update_rate × DAC_BUF_LEN
 *   本实现通过改变phase_inc实现频率控制
 */

#include "dac_output.h"
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

/* ---- 外部变量声明 ---- */
extern DAC_HandleTypeDef hdac;
extern TIM_HandleTypeDef htim4;     // 触发DAC的定时器
extern DMA_HandleTypeDef hdma_dac1;

/**
 * @brief  初始化DAC输出模块
 */
void DAC_Init(DacOutput *dac)
{
    memset(dac->wave_table, 0, sizeof(dac->wave_table));
    dac->freq        = 0.0f;
    dac->amplitude   = 0.0f;
    dac->offset      = 0.5f;
    dac->wave_type   = WAVE_SINE;
    dac->update_rate = 20000.0f;
    dac->running     = 0;
}

/**
 * @brief  生成波形查找表
 * 
 * 通过相位累加原理填充波形表：
 *   table[i] = waveform(i × 2π × f_out / update_rate) × amp × DAC_MAX + offset × DAC_MAX
 */
int DAC_SetWave(DacOutput *dac, WaveType type, float freq,
                float amp, float offset, float update_rate)
{
    /* 奈奎斯特检查 */
    if (freq > update_rate / 2.0f)
        return -1;
    
    dac->wave_type   = type;
    dac->freq        = freq;
    dac->amplitude   = amp;
    dac->offset      = offset;
    dac->update_rate = update_rate;
    
    float phase_step = freq / update_rate;
    
    for (int i = 0; i < DAC_BUF_LEN; i++) {
        float phase = (float)i * phase_step;
        float val = 0.0f;
        
        switch (type) {
            case WAVE_SINE:
                val = arm_sin_f32(phase * TWO_PI);  /* sin(2π × phase) */
                break;
                
            case WAVE_SQUARE:
                /* 方波：前50%为高，后50%为低 */
                val = (phase < 0.5f) ? 1.0f : -1.0f;
                break;
                
            case WAVE_TRIANGLE:
                /* 三角波 */
                if (phase < 0.25f) {
                    val = 4.0f * phase;           /* 0 → 1 */
                } else if (phase < 0.75f) {
                    val = 2.0f - 4.0f * phase;    /* 1 → -1 */
                } else {
                    val = 4.0f * phase - 4.0f;     /* -1 → 0 */
                }
                break;
                
            default:
                val = 0.0f;
                break;
        }
        
        /* 映射到DAC输出范围 */
        float dac_val = (val * amp + offset) * (float)DAC_MAX_VAL;
        
        /* 限幅 */
        if (dac_val > (float)DAC_MAX_VAL) dac_val = (float)DAC_MAX_VAL;
        if (dac_val < 0.0f)              dac_val = 0.0f;
        
        dac->wave_table[i] = (uint16_t)dac_val;
    }
    
    return 0;
}

/**
 * @brief  启动DAC输出
 */
void DAC_Start(DacOutput *dac)
{
    HAL_DAC_Start_DMA(&hdac, DAC_CHANNEL_1,
                      (uint32_t*)dac->wave_table, DAC_BUF_LEN,
                      DAC_ALIGN_12B_R);
    HAL_TIM_Base_Start(&htim4);
    dac->running = 1;
}

/**
 * @brief  停止DAC输出
 */
void DAC_Stop(DacOutput *dac)
{
    HAL_DAC_Stop_DMA(&hdac, DAC_CHANNEL_1);
    HAL_TIM_Base_Stop(&htim4);
    dac->running = 0;
}

/**
 * @brief  设置输出幅度 (需重建波形表)
 */
void DAC_SetAmplitude(DacOutput *dac, float amp)
{
    DAC_SetWave(dac, dac->wave_type, dac->freq, amp,
                dac->offset, dac->update_rate);
    /* 如果正在运行，DMA会自动使用新波形表 */
}

/**
 * @brief  设置直流偏置 (需重建波形表)
 */
void DAC_SetOffset(DacOutput *dac, float offset)
{
    DAC_SetWave(dac, dac->wave_type, dac->freq, dac->amplitude,
                offset, dac->update_rate);
}
