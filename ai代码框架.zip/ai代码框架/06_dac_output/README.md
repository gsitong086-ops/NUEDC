# 06_dac_output - DDS波形输出模块

## 功能概述

基于DDS（直接数字频率合成）原理，通过相位累加填表 + 定时器触发DAC DMA循环输出，实现正弦波、方波、三角波的任意频率信号生成。

## DDS 原理

```
相位累加器 ──→ 波形查找表 ──→ DAC ──→ 模拟输出
    ↑
频率控制字 (freq / update_rate)
```

```
输出频率 = freq / DAC_BUF_LEN × update_rate
频率分辨率 = update_rate / DAC_BUF_LEN
```

## 文件列表

| 文件 | 说明 |
|------|------|
| `dac_output.h` | 头文件：DAC句柄、接口声明 |
| `dac_output.c` | 源文件：波形表生成、DAC启动/停止 |

## 核心数据结构

```c
typedef struct {
    uint16_t wave_table[DAC_BUF_LEN];  // 波形查找表 (256点)
    float    freq;                      // 当前输出频率 (Hz)
    float    amplitude;                 // 输出幅度 (0~1.0)
    float    offset;                    // 直流偏置 (0~1.0)
    WaveType wave_type;                 // 波形类型
    float    update_rate;               // DAC更新率 (Hz)
    uint8_t  running;                   // 运行标志
} DacOutput;
```

## CubeMX 配置要点

| 外设 | 配置 |
|------|------|
| **DAC1** | Channel 1 (PA4)，输出缓冲使能 |
| **TIM4** | TRGO触发DAC (Update Event) |
| **DMA1 Stream5** | 循环模式，半字→半字，内存→外设 |

### 定时器频率计算

```
更新率 = TIM_CLK / (PSC+1) / (ARR+1)

示例：168MHz，PSC=83 → 2MHz，ARR=99 → 20kHz更新率
```

## 使用示例

```c
#include "dac_output.h"

DacOutput dac;

// 初始化
DAC_Init(&dac);

// 生成1kHz正弦波，幅度0.8，偏置0.5
DAC_SetWave(&dac, WAVE_SINE, 1000.0f, 0.8f, 0.5f, 20000.0f);

// 启动输出
DAC_Start(&dac);

// 动态改变频率
DAC_Stop(&dac);
DAC_SetWave(&dac, WAVE_SINE, 2000.0f, 0.8f, 0.5f, 20000.0f);
DAC_Start(&dac);

// 动态改变幅度
DAC_SetAmplitude(&dac, 0.3f);

// 停止输出
DAC_Stop(&dac);
```

## 输出映射

```
DAC输出 = (waveform × amplitude + offset) × 4095
```

| 参数 | 范围 | 说明 |
|------|------|------|
| amplitude | 0 ~ 1.0 | 0=无信号, 1.0=满幅 |
| offset | 0 ~ 1.0 | 0.5=中点 (Vref/2) |

### 输出示例 (3.3V参考)

| amplitude | offset | 输出范围 |
|-----------|--------|---------|
| 1.0 | 0.5 | 0 ~ 3.3V (满幅正弦) |
| 0.5 | 0.5 | 0.825 ~ 2.475V |
| 0.3 | 0.2 | 0 ~ 1.32V |
| 0.1 | 0.5 | 1.485 ~ 1.815V (小信号) |

## 接口说明

| 函数 | 说明 |
|------|------|
| `DAC_Init(dac)` | 初始化DAC句柄 |
| `DAC_SetWave(dac, type, freq, amp, offset, rate)` | 生成波形表 |
| `DAC_Start(dac)` | 启动DMA输出 |
| `DAC_Stop(dac)` | 停止输出 |
| `DAC_SetAmplitude(dac, amp)` | 动态改幅度 (重建波形表) |
| `DAC_SetOffset(dac, offset)` | 动态改偏置 (重建波形表) |

## 波形类型

| 枚举 | 波形 | 谐波特征 |
|------|------|---------|
| `WAVE_SINE` | 正弦波 | 无谐波 |
| `WAVE_SQUARE` | 方波 | 奇次谐波丰富 |
| `WAVE_TRIANGLE` | 三角波 | 谐波衰减快 |

## 频率精度

```
更新率20kHz, 表长256:
  频率分辨率 = 20000/256 ≈ 78 Hz
  最大输出频率 = 10 kHz (奈奎斯特)
```

## 依赖

- `dsp_common.h` (使用 `g_params.dac_*`)
- `arm_math.h` (使用 `arm_sin_f32`)
- `math.h`
