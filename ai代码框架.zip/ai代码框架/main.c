/**
 * @file    main.c
 * @brief   电赛DSP通用库 - 应用层示例代码 (集成外置模块)
 * @author  电赛DSP通用库
 * @date    2025-07
 * 
 * 完整信号链路演示:
 *   AD9851激励 → DUT(被测网络) → AD603程控增益 → AD630模拟解调 → LPF → ADC采集
 *                                                                    ↓
 *                                                          FFT频谱 + 数字锁相 → 串口输出
 * 
 * 功能演示：
 *   1. ADC双缓冲采集
 *   2. FFT频谱分析 (峰值频率+幅度)
 *   3. 数字锁相放大 (幅度+相位)
 *   4. AD603自动增益控制 (AGC)
 *   5. AD9851激励信号发生
 *   6. AD630解调信号解算
 *   7. DDS板载信号输出
 *   8. 串口结果上报
 */

#include "main.h"
#include "dsp_common.h"
#include "adc_sample.h"
#include "fft_proc.h"
#include "filter.h"
#include "lockin.h"
#include "dac_output.h"
#include "ad603.h"
#include "ad9851.h"
#include "ad630.h"
#include <stdio.h>

/* ================================================================
 * 模块句柄
 * ================================================================ */
FFT_Handle   fft_h;          // FFT频谱分析
FilterHandle flt_h;          // 数字滤波器
LockIn       lockin;         // 数字锁相放大器
DacOutput    dac_out;        // DDS板载信号输出
AD603_Handle ad603;          // 程控增益放大器
AD9851_Handle dds;           // AD9851 DDS频率合成
AD630_Handle ad630;          // AD630平衡调制解调

/* ================================================================
 * 数据缓冲区
 * ================================================================ */
static float adc_raw[FFT_N];       // ADC原始数据
static float adc_filtered[FFT_N];  // 滤波后数据
static char  uart_buf[256];        // 串口发送缓冲

/* ================================================================
 * 外设句柄 (CubeMX生成，在此声明)
 * ================================================================ */
extern ADC_HandleTypeDef hadc1;
extern ADC_HandleTypeDef hadc2;    // 可选: 第二路ADC
extern DAC_HandleTypeDef hdac;
extern TIM_HandleTypeDef htim3;    // ADC触发
extern TIM_HandleTypeDef htim4;    // DAC触发
extern DMA_HandleTypeDef hdma_adc1;
extern DMA_HandleTypeDef hdma_adc2;  // 可选
extern DMA_HandleTypeDef hdma_dac1;
extern UART_HandleTypeDef huart1;

/* ================================================================
 * 私有函数声明
 * ================================================================ */
static void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_ADC2_Init(void);
static void MX_DAC_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM4_Init(void);
static void MX_DMA_Init(void);
static void MX_USART1_UART_Init(void);
static void UART_PrintResult(void);

/* ================================================================
 * 主函数
 * ================================================================ */
int main(void)
{
    /* ---- HAL初始化 ---- */
    HAL_Init();
    SystemClock_Config();

    /* ---- 外设初始化 (CubeMX生成) ---- */
    MX_GPIO_Init();
    MX_DMA_Init();
    MX_ADC1_Init();
    MX_ADC2_Init();
    MX_DAC_Init();
    MX_TIM3_Init();
    MX_TIM4_Init();
    MX_USART1_UART_Init();

    /* ---- DSP公共参数 ---- */
    DspParams_Init();
    DspParams_SetFs(FS_20KHZ);                      // 采样率 20kHz

    /* ---- 板载模块初始化 ---- */
    ADC_Init();                                     // ADC双缓冲
    FFT_Init(&fft_h, g_params.fs_actual);           // FFT
    LockIn_Init(&lockin, g_params.lockin_ref_freq,
                g_params.fs_actual, g_params.lockin_tau);
    DAC_Init(&dac_out);

    /* ---- 外置模块初始化 ---- */
    AD603_Init(&ad603);                             // 程控增益
    AD9851_Init(&dds);                              // DDS频率合成
    AD630_Init(&ad630);                             // 模拟锁相解调

    /* ---- 配置信号链路 ---- */

    /* 1. AD9851: 输出1kHz正弦波作为激励信号 */
    AD9851_SetFreq(&dds, 1000.0f, 0.0f);

    /* 2. AD603: 初始增益10dB (后续由AGC自动调整) */
    AD603_SetGain(&ad603, 10.0f);

    /* 3. AD630: 配置为锁相放大模式，参考频率1kHz */
    AD630_SetMode(&ad630, AD630_MODE_LOCKIN);
    AD630_SetRefFreq(&ad630, 1000.0f);
    AD630_SetSystemGain(&ad630, 10.0f);  /* 系统总增益 ×10 */

    /* 4. 板载DAC: 辅助输出 (可选) */
    DAC_SetWave(&dac_out, WAVE_SINE, 1000.0f, 0.5f, 0.5f, 20000.0f);

    /* ---- 启动外设 ---- */
    ADC_Start();
    DAC_Start(&dac_out);

    /* ---- 主循环 ---- */
    while (1)
    {
        /* 等待ADC新帧就绪 */
        if (ADC_FrameReady())
        {
            /* 获取浮点电压数据 (AD630解调后的直流信号) */
            ADC_GetFrame(adc_raw);

            /* ---- FFT频谱分析 ---- */
            FFT_Process(&fft_h, adc_raw);

            /* ---- 数字锁相放大 (辅助分析) ---- */
            LockIn_ProcessBlock(&lockin, adc_raw, FFT_N);

            /* ---- AD630信号解算 ---- */
            /* 从解调直流电压还原原始信号幅度 */
            float signal_vpp = AD630_CalcInputLevel(&ad630, lockin.amplitude);

            /* ---- AD603 自动增益控制 ---- */
            /* 目标输出幅度1.5Vpp，根据当前信号自动调整增益 */
            AD603_AGC(&ad603, signal_vpp, 1.5f);

            /* ---- 串口输出结果 ---- */
            UART_PrintResult();

            /* ---- 高级应用示例 ---- */

            /* 示例1: 根据FFT峰值频率自动调整AD9851激励 */
            // if (fft_h.peak_mag > 0.1f) {
            //     AD9851_SetFreq(&dds, fft_h.peak_freq, 0.0f);
            //     AD630_SetRefFreq(&ad630, fft_h.peak_freq);
            // }

            /* 示例2: 扫频阻抗测量 */
            // static uint32_t sweep_tick = 0;
            // if (HAL_GetTick() - sweep_tick >= (uint32_t)g_params.ad9851_sweep_dwell) {
            //     sweep_tick = HAL_GetTick();
            //     AD9851_Sweep_Process(&dds);
            //     // 记录每个频率点的幅值和相位
            // }

            /* 示例3: FSK调制 */
            // static uint32_t fsk_tick = 0;
            // if (HAL_GetTick() - fsk_tick >= 100) {  // 100ms切换
            //     fsk_tick = HAL_GetTick();
            //     static uint8_t fsk_bit = 0;
            //     fsk_bit = !fsk_bit;
            //     AD9851_FSK_Select(&dds, fsk_bit);
            // }
        }

        /* 可在此处处理串口命令，实现AI/上位机远程调参 */
    }
}

/* ================================================================
 * 串口输出结果
 * ================================================================ */
static void UART_PrintResult(void)
{
    int len = snprintf(uart_buf, sizeof(uart_buf),
        "F:%.1fHz M:%.3fV L:%.4fV G:%.1fdB Vpp:%.3fV\r\n",
        g_params.fft_peak_freq,       // FFT峰值频率
        g_params.fft_peak_mag,        // FFT峰值幅度
        g_params.lockin_amplitude,    // 数字锁相幅度
        g_params.ad603_gain_db,       // AD603当前增益
        g_params.ad630_output         // AD630解调输出
    );

    HAL_UART_Transmit(&huart1, (uint8_t*)uart_buf, len, 100);
}

/* ================================================================
 * 以下为CubeMX生成的初始化函数 (简化示例)
 * 实际使用时请用CubeMX生成的完整代码替换
 * ================================================================ */

/**
 * @brief  系统时钟配置 (168MHz)
 */
static void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    /* 使能PWR时钟 */
    __HAL_RCC_PWR_CLK_ENABLE();

    /* 配置HSE */
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState = RCC_HSE_ON;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLM = 8;
    RCC_OscInitStruct.PLL.PLLN = 336;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;  /* 168MHz */
    RCC_OscInitStruct.PLL.PLLQ = 7;
    HAL_RCC_OscConfig(&RCC_OscInitStruct);

    /* 配置时钟树 */
    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;  /* 42MHz */
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;  /* 84MHz */
    HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}

/* ---- 以下函数体需用CubeMX生成代码填充 ---- */

static void MX_GPIO_Init(void)
{
    /* CubeMX生成: GPIO初始化
     * 重点配置:
     *   GPIOA[0:7] → AD9851 D0~D7, 推挽输出, Very High速度
     *   GPIOB[0:2] → AD9851 WCLK/FQUD/RESET
     *   GPIOB[3]   → AD9851 FSK选择 (可选)
     */
}

static void MX_ADC1_Init(void)
{
    /* CubeMX生成: ADC1 12bit, TIM3 TRGO触发
     * 输入引脚: 连接AD630解调输出 (经低通滤波)
     */
}

static void MX_ADC2_Init(void)
{
    /* CubeMX生成: ADC2 12bit, TIM3 TRGO触发 (可选)
     * 用于双路AD630同时采集 (I/Q两路)
     */
}

static void MX_DAC_Init(void)
{
    /* CubeMX生成:
     * DAC1 Channel 1 (PA4) → AD603 VGPOS 增益控制
     * DAC1 Channel 2 (PA5) → 板载信号输出 (可选)
     */
}

static void MX_TIM3_Init(void)
{
    /* CubeMX生成: TIM3 触发ADC
     * PSC = 83, ARR = 99 → 20kHz采样率
     * TRGO = Update Event
     */
}

static void MX_TIM4_Init(void)
{
    /* CubeMX生成: TIM4 触发DAC
     * PSC = 83, ARR = 99 → 20kHz更新率
     * TRGO = Update Event
     */
}

static void MX_DMA_Init(void)
{
    /* CubeMX生成:
     * DMA2 Stream0: ADC1 循环模式 半字→半字
     * DMA2 Stream2: ADC2 循环模式 半字→半字 (可选)
     * DMA1 Stream5: DAC1 循环模式 半字→半字 内存→外设
     */
}

static void MX_USART1_UART_Init(void)
{
    /* CubeMX生成: USART1 115200-8-N-1 */
}

/* ================================================================
 * 错误处理
 * ================================================================ */
void Error_Handler(void)
{
    __disable_irq();
    while (1) {
        /* 可添加LED闪烁指示错误 */
    }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
    /* 断言失败处理 */
}
#endif
