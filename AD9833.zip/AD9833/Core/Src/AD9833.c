/**********************************************************
                       康威电子
功能：STM32F407ZGT6 驱动 AD9833 模块 (HAL库)
接口：模拟SPI，引脚定义见 AD9833.h
时间：2026/07/26
版本：F4-V1.0
作者：适配自商家例程 (原版F103)

淘宝店铺：康威电子
https://kvdz.taobao.com/
**********************************************************/
#include "AD9833.h"

/*
  参考时钟频率 (Hz)
  模块默认板载晶振 25MHz，若使用外部时钟源请修改此处。
  25MHz 时钟下可实现 0.1Hz 分辨率；
   1MHz 时钟下可实现 0.004Hz 分辨率。
*/
#define FCLK        25000000    /* 25MHz 参考时钟 */

/* 频率计算系数: 2^28 / FCLK */
#define RealFreDat  268435456.0 / FCLK

/****************************************************************
** 函数名称: void AD9833_GPIO_Init(void)
** 函数功能: 初始化驱动 AD9833 所需的 GPIO (PB0/PB1/PB2)
** 入口参数: 无
** 出口参数: 无
** 备    注: 使用 HAL 库初始化，推挽输出，无上下拉
*****************************************************************/
void AD9833_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    /* 使能 GPIOB 时钟 */
    __HAL_RCC_GPIOB_CLK_ENABLE();

    /* 配置 PB0(FSYNC), PB1(SCLK), PB2(SDATA) 为推挽输出 */
    GPIO_InitStruct.Pin   = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* 初始电平置高 */
    AD9833_FSYNC_H();
    AD9833_SCLK_H();
    AD9833_SDATA_H();
}

/****************************************************************
** 函数名称: unsigned char AD9833_SPI_Write(unsigned char* data,
**                              unsigned char bytesNumber)
** 函数功能: 模拟 SPI 向 AD9833 写入数据
** 入口参数: *data         : 数据缓冲区(第一个字节是寄存器地址)
**           bytesNumber   : 要写入的字节数
** 出口参数: 写入的字节数
** 备    注: 16位数据，MSB first，SCLK 下降沿写入
*****************************************************************/
unsigned char AD9833_SPI_Write(unsigned char* data, unsigned char bytesNumber)
{
    unsigned char i, j;
    unsigned char writeData[5] = {0, 0, 0, 0, 0};

    AD9833_SCLK_H();
    AD9833_FSYNC_L();                    /* 拉低 FSYNC，开始传输 */

    /* 跳过第一个字节(寄存器地址)，取出实际数据 */
    for (i = 0; i < bytesNumber; i++)
    {
        writeData[i] = data[i + 1];
    }

    /* 逐字节发送，MSB first */
    for (i = 0; i < bytesNumber; i++)
    {
        for (j = 0; j < 8; j++)
        {
            if (writeData[i] & 0x80)
                AD9833_SDATA_H();
            else
                AD9833_SDATA_L();

            AD9833_SCLK_L();             /* SCLK 下降沿 */
            writeData[i] <<= 1;
            AD9833_SCLK_H();             /* SCLK 上升沿 */
        }
    }

    AD9833_SDATA_H();
    AD9833_FSYNC_H();                    /* 拉高 FSYNC，结束传输 */

    return i;
}

/****************************************************************
** 函数名称: void AD9833_Init(void)
** 函数功能: 初始化 AD9833 (GPIO + 复位寄存器)
** 入口参数: 无
** 出口参数: 无
*****************************************************************/
void AD9833_Init(void)
{
    AD9833_GPIO_Init();
    AD9833_SetRegisterValue(AD9833_REG_CMD | AD9833_RESET);
}

/****************************************************************
** 函数名称: void AD9833_Reset(void)
** 函数功能: 置位 AD9833 的复位位
** 入口参数: 无
** 出口参数: 无
*****************************************************************/
void AD9833_Reset(void)
{
    AD9833_SetRegisterValue(AD9833_REG_CMD | AD9833_RESET);
    HAL_Delay(10);
}

/****************************************************************
** 函数名称: void AD9833_ClearReset(void)
** 函数功能: 清除 AD9833 的复位位
** 入口参数: 无
** 出口参数: 无
*****************************************************************/
void AD9833_ClearReset(void)
{
    AD9833_SetRegisterValue(AD9833_REG_CMD);
}

/****************************************************************
** 函数名称: void AD9833_SetRegisterValue(unsigned short regValue)
** 函数功能: 将 16 位值写入寄存器
** 入口参数: regValue: 要写入的寄存器值
** 出口参数: 无
*****************************************************************/
void AD9833_SetRegisterValue(unsigned short regValue)
{
    unsigned char data[5] = {0x03, 0x00, 0x00};

    data[1] = (unsigned char)((regValue & 0xFF00) >> 8);   /* 高字节 */
    data[2] = (unsigned char)((regValue & 0x00FF) >> 0);   /* 低字节 */
    AD9833_SPI_Write(data, 2);
}

/****************************************************************
** 函数名称: void AD9833_SetFrequencyQuick(float fout,
**                              unsigned short type)
** 函数功能: 快速设置频率 (使用 FREQ0 寄存器)
** 入口参数: fout : 输出频率 (Hz)，float 类型保证精度
**           type : 波形类型 (AD9833_OUT_SINUS / TRIANGLE / MSB)
** 出口参数: 无
*****************************************************************/
void AD9833_SetFrequencyQuick(float fout, unsigned short type)
{
    AD9833_SetFrequency(AD9833_REG_FREQ0, fout, type);
}

/****************************************************************
** 函数名称: void AD9833_SetFrequency(unsigned short reg,
**                     float fout, unsigned short type)
** 函数功能: 写入频率寄存器
** 入口参数: reg  : 频率寄存器 (FREQ0 / FREQ1)
**           fout : 输出频率 (Hz)
**           type : 波形类型
** 出口参数: 无
** 备    注: Fout = FCLK / 2^28 * FREQREG
*****************************************************************/
void AD9833_SetFrequency(unsigned short reg, float fout, unsigned short type)
{
    unsigned short freqHi = reg;
    unsigned short freqLo = reg;
    unsigned long  val    = (unsigned long)(RealFreDat * fout);

    freqHi |= (val & 0xFFFC000) >> 14;   /* 高14位 */
    freqLo |= (val & 0x3FFF);            /* 低14位 */

    AD9833_SetRegisterValue(AD9833_B28 | type);   /* 连续写入模式 + 波形选择 */
    AD9833_SetRegisterValue(freqLo);               /* 写低14位 */
    AD9833_SetRegisterValue(freqHi);               /* 写高14位 */
}

/****************************************************************
** 函数名称: void AD9833_SetPhase(unsigned short reg,
**                     unsigned short val)
** 函数功能: 写入相位寄存器
** 入口参数: reg: 相位寄存器 (PHASE0 / PHASE1)
**           val: 相位值 (0~4095, 对应 0°~360°)
** 出口参数: 无
*****************************************************************/
void AD9833_SetPhase(unsigned short reg, unsigned short val)
{
    unsigned short phase = reg;
    phase |= (val & 0x0FFF);             /* 12位相位值 */
    AD9833_SetRegisterValue(phase);
}

/****************************************************************
** 函数名称: void AD9833_Setup(unsigned short freq,
**                 unsigned short phase, unsigned short type)
** 函数功能: 选择频率源、相位源和波形类型
** 入口参数: freq  : 频率选择 (FSEL0 / FSEL1)
**           phase : 相位选择 (PSEL0 / PSEL1)
**           type  : 波形类型
** 出口参数: 无
*****************************************************************/
void AD9833_Setup(unsigned short freq, unsigned short phase, unsigned short type)
{
    unsigned short val = 0;

    val = freq | phase | type;
    AD9833_SetRegisterValue(val);
}

/****************************************************************
** 函数名称: void AD9833_SetWave(unsigned short type)
** 函数功能: 设置波形类型
** 入口参数: type: 波形类型
** 出口参数: 无
*****************************************************************/
void AD9833_SetWave(unsigned short type)
{
    AD9833_SetRegisterValue(type);
}
