#ifndef _AD9833_H_
#define _AD9833_H_

#include "main.h"

/* AD9833 引脚定义 (模拟SPI接口)
   FSYNC -> PB0
   SCLK  -> PB1
   SDATA -> PB2
   可根据实际接线修改以下宏 */
#define AD9833_FSYNC_H()  (GPIOB->BSRR = GPIO_PIN_0)
#define AD9833_FSYNC_L()  (GPIOB->BSRR = (uint32_t)GPIO_PIN_0 << 16)
#define AD9833_SCLK_H()   (GPIOB->BSRR = GPIO_PIN_1)
#define AD9833_SCLK_L()   (GPIOB->BSRR = (uint32_t)GPIO_PIN_1 << 16)
#define AD9833_SDATA_H()  (GPIOB->BSRR = GPIO_PIN_2)
#define AD9833_SDATA_L()  (GPIOB->BSRR = (uint32_t)GPIO_PIN_2 << 16)

/******************************************************************************/
/* AD9833 寄存器定义                                                           */
/******************************************************************************/

#define AD9833_REG_CMD    (0 << 14)
#define AD9833_REG_FREQ0  (1 << 14)
#define AD9833_REG_FREQ1  (2 << 14)
#define AD9833_REG_PHASE0 (6 << 13)
#define AD9833_REG_PHASE1 (7 << 13)

/* 命令控制位 */
#define AD9833_B28        (1 << 13)
#define AD9833_HLB        (1 << 12)
#define AD9833_FSEL0      (0 << 11)
#define AD9833_FSEL1      (1 << 11)
#define AD9833_PSEL0      (0 << 10)
#define AD9833_PSEL1      (1 << 10)
#define AD9833_PIN_SW     (1 << 9)
#define AD9833_RESET      (1 << 8)
#define AD9833_SLEEP1     (1 << 7)
#define AD9833_SLEEP12    (1 << 6)
#define AD9833_OPBITEN    (1 << 5)
#define AD9833_SIGN_PIB   (1 << 4)
#define AD9833_DIV2       (1 << 3)
#define AD9833_MODE       (1 << 1)

/* 波形类型定义 */
#define AD9833_OUT_SINUS      ((0 << 5) | (0 << 1) | (0 << 3))  /* 正弦波 */
#define AD9833_OUT_TRIANGLE   ((0 << 5) | (1 << 1) | (0 << 3))  /* 三角波 */
#define AD9833_OUT_MSB        ((1 << 5) | (0 << 1) | (1 << 3))  /* 方波 */
#define AD9833_OUT_MSB2       ((1 << 5) | (0 << 1) | (0 << 3))

/* 函数声明 */
void AD9833_GPIO_Init(void);           /* 初始化IO口 */
void AD9833_Init(void);                /* 初始化IO口及寄存器 */

void AD9833_Reset(void);               /* 复位AD9833 */
void AD9833_ClearReset(void);          /* 清除AD9833复位 */

void AD9833_SetRegisterValue(unsigned short regValue);                         /* 写寄存器值 */
void AD9833_SetFrequency(unsigned short reg, float fout, unsigned short type);  /* 写频率寄存器 */
void AD9833_SetPhase(unsigned short reg, unsigned short val);                   /* 写相位寄存器 */

void AD9833_Setup(unsigned short freq, unsigned short phase, unsigned short type); /* 选择频率、相位和波形 */
void AD9833_SetFrequencyQuick(float fout, unsigned short type);                     /* 快速设置频率 */

#endif
