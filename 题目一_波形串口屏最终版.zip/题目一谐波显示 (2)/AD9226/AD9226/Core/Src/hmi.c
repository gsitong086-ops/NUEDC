#include "hmi.h"

/**
 * @brief 发送单个字节（等待TC标志，确保数据发出）
 */
static void HMI_SendChar(uint8_t ch)
{
    while(__HAL_UART_GET_FLAG(&huart1, UART_FLAG_TC) == RESET);
    HAL_UART_Transmit(&huart1, &ch, 1, 10);
}

/**
 * @brief 发送原始字符串 + 淘晶驰协议结束符 0xFF 0xFF 0xFF
 */
void HMI_SendRaw(const char *str)
{
    while (*str)
    {
        HMI_SendChar((uint8_t)*str++);
    }
    HMI_SendChar(0xFF);
    HMI_SendChar(0xFF);
    HMI_SendChar(0xFF);
}

/**
 * @brief 设置文本控件内容，格式: obj.txt="text" + FF FF FF
 */
void HMI_SetText(const char *obj, const char *text)
{
    char buf[128];
    snprintf(buf, sizeof(buf), "%s.txt=\"%s\"", obj, text);
    HMI_SendRaw(buf);
}

/**
 * @brief 往波形控件追加数据点，格式: add obj,ch,val + FF FF FF
 */
void HMI_AddWave(const char *wave, uint8_t ch, uint8_t val)
{
    char buf[48];
    snprintf(buf, sizeof(buf), "add %s,%d,%d", wave, ch, val);
    HMI_SendRaw(buf);
}

/**
 * @brief 清除波形控件指定通道，格式: cle obj,ch + FF FF FF
 */
void HMI_ClearWave(const char *wave, uint8_t ch)
{
    char buf[32];
    snprintf(buf, sizeof(buf), "cle %s,%d", wave, ch);
    HMI_SendRaw(buf);
}

/**
 * @brief 切换页面，格式: page id + FF FF FF
 */
void HMI_Page(const char *page)
{
    char buf[16];
    snprintf(buf, sizeof(buf), "page %s", page);
    HMI_SendRaw(buf);
}
