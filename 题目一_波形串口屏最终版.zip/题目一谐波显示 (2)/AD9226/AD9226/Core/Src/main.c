/* USER CODE BEGIN Header */
/**
  * @file    main.c
  * @brief   STM32F407ZGT6 + AD9226 并行ADC采集
  *          淘晶驰串口屏波形显示 (TJC协议, 115200bps)
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include "hmi.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
#define ADC_SAMPLE_LEN    4096       // 采样缓冲区长度
#define ADC_DATA_MASK     0x0FFF     // 12位掩码
#define POINT_INTERVAL_MS 2          // 每点额外延时，降低波形刷新速度

/* 波形控件 — 必须用数字ID！淘晶驰 add 命令不支持名字 */
#define WAVE_CTRL  "8"
#define DISPLAY_POINT_COUNT      512U   // 每帧固定输出点数
#define HZOOM_FULL_WINDOW_LEVEL  1      // g_hzoom=1时显示完整采样窗口

uint16_t adc_buffer[ADC_SAMPLE_LEN]; // DMA采集缓冲区
uint16_t fir_buf[ADC_SAMPLE_LEN];    // FIR滤波后缓冲区
volatile uint8_t dma_complete_flag = 0;
extern TIM_HandleTypeDef htim8;
extern DMA_HandleTypeDef hdma_tim8_up;

/* 串口屏按钮相关 -----------------------------------------*/
volatile uint8_t capture_on = 1;     // 采集/显示开关 (1=运行, 0=暂停)
uint8_t  rx_byte;                    // UART中断接收的单个字节
uint8_t  rx_buf[32];                 // 接收缓冲区
uint8_t  rx_idx = 0;                 // 缓冲区索引

/* X/Y 缩放参数 — 屏幕控件自带缩放功能 */
int g_hzoom = 1;   // 保留串口屏原有X缩放初值
int g_scale = 1;   // Y轴缩放，无上下限
volatile uint8_t zoom_dirty = 0;  // 缩放值已变更，主循环需发送
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void AD9226_GPIO_Init(void);
void AD9226_StartSampling(void);
void AD9226_StopSampling(void);
void HMI_RxHandler(uint8_t b);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/**
 * @brief 配置GPIOD PD0~PD11为输入，读取AD9226的12位并行数据
 */
void AD9226_GPIO_Init(void)
{
    __HAL_RCC_GPIOD_CLK_ENABLE();

    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 |
                          GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7 |
                          GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
}

/**
 * @brief 启动一次DMA采样 (TIM8触发, 采集1024点)
 */
void AD9226_StartSampling(void)
{
    dma_complete_flag = 0;

    // 停止TIM8
    TIM8->CR1 &= ~TIM_CR1_CEN;

    // 禁止DMA, 等待真正停止
    DMA2_Stream1->CR &= ~DMA_SxCR_EN;
    while (DMA2_Stream1->CR & DMA_SxCR_EN);

    // 清除DMA中断标志
    DMA2->LIFCR = 0x3D << 6;

    // 设置源/目标地址和传输长度
    DMA2_Stream1->PAR  = (uint32_t)&GPIOD->IDR;
    DMA2_Stream1->M0AR = (uint32_t)adc_buffer;
    DMA2_Stream1->NDTR = ADC_SAMPLE_LEN;

    // 使能DMA传输完成中断
    DMA2_Stream1->CR |= DMA_SxCR_TCIE;

    // 使能DMA
    DMA2_Stream1->CR |= DMA_SxCR_EN;

    // 使能TIM8 UPDATE触发DMA
    TIM8->DIER |= TIM_DIER_UDE;

    // 清除SR，启动TIM8
    TIM8->SR = 0;
    TIM8->CR1 |= TIM_CR1_CEN;
}

/**
 * @brief 停止采样
 */
void AD9226_StopSampling(void)
{
    TIM8->CR1 &= ~TIM_CR1_CEN;         // 停止TIM8
    DMA2_Stream1->CR &= ~DMA_SxCR_EN;  // 禁止DMA
}

/**
 * @brief 发送缩放指令到波形控件（备用，屏幕不支持则走软件缩放）
 */
static void HMI_ApplyZoom(void)
{
    char zbuf[32];
    snprintf(zbuf, sizeof(zbuf), "%s.hzoom=%d", WAVE_CTRL, g_hzoom);
    HMI_SendRaw(zbuf);
    HAL_Delay(10);
    snprintf(zbuf, sizeof(zbuf), "%s.scale=%d", WAVE_CTRL, g_scale);
    HMI_SendRaw(zbuf);
}

/**
 * @brief 串口屏按钮指令处理
 *
 * 按钮事件: START / PAUSE / CLEAR / XP / XM / YP / YM
 * 也兼容淘晶驰标准触摸事件格式 (0x65前缀, 7字节)
 */
void HMI_RxHandler(uint8_t b)
{
    /* 淘晶驰触摸帧 0x65 — 收齐7字节，处理按钮事件 */
    if (rx_idx == 0 && b == 0x65) { rx_buf[0] = 0x65; rx_idx = 1; return; }
    if (rx_idx > 0 && rx_buf[0] == 0x65)
    {
        rx_buf[rx_idx++] = b;
        if (rx_idx >= 7)
        {
            rx_idx = 0;
            uint8_t cid = rx_buf[2];  // 控件ID
            if      (cid == 1)  { capture_on = 1; }
            else if (cid == 2)  { capture_on = 0; }
            else if (cid == 3)  { capture_on = 0; }
            else if (cid == 13) { g_hzoom--; zoom_dirty = 1; }
            else if (cid == 14) { g_hzoom++; zoom_dirty = 1; }
            else if (cid == 15) { g_scale++; zoom_dirty = 1; }
            else if (cid == 16) { g_scale--; zoom_dirty = 1; }
        }
        return;
    }

    /* printh ASCII字符串 (以 \r 或 \n 结尾) */
    if (b == '\r' || b == '\n')
    {
        if (rx_idx > 0)
        {
            rx_buf[rx_idx] = '\0';
            char *cmd = (char *)rx_buf;

            if      (strcmp(cmd, "START") == 0)
                { capture_on = 1; HMI_ClearWave(WAVE_CTRL, 0); }
            else if (strcmp(cmd, "PAUSE") == 0)
                { capture_on = 0; }
            else if (strcmp(cmd, "CLEAR") == 0)
                { capture_on = 0; HMI_ClearWave(WAVE_CTRL, 0); }
            else if (strcmp(cmd, "XP") == 0)
                { g_hzoom--; zoom_dirty = 1; }
            else if (strcmp(cmd, "XM") == 0)
                { g_hzoom++; zoom_dirty = 1; }
            else if (strcmp(cmd, "YP") == 0)
                { g_scale++; zoom_dirty = 1; }
            else if (strcmp(cmd, "YM") == 0)
                { g_scale--; zoom_dirty = 1; }
        }
        rx_idx = 0;
        return;
    }

    /* 存储普通字符 */
    if (rx_idx < sizeof(rx_buf) - 1)
        rx_buf[rx_idx++] = b;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM8_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */

    AD9226_GPIO_Init();
    HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_1);

    /* 使能USART1接收中断 (用于接收串口屏按钮指令) */
    HAL_NVIC_SetPriority(USART1_IRQn, 1, 0);
    HAL_NVIC_EnableIRQ(USART1_IRQn);
    HAL_UART_Receive_IT(&huart1, &rx_byte, 1);

    /* 等待串口屏启动完成 */
    HAL_Delay(3000);

    /* 确保波形控件启用 + 初始缩放 */
    {
        char ebuf[32];
        snprintf(ebuf, sizeof(ebuf), "%s.en=1", WAVE_CTRL);
        HMI_SendRaw(ebuf);
        HAL_Delay(50);
    }
    HMI_ApplyZoom();
    HAL_Delay(100);

    /* 设置占位文本（验证通信） */
    HMI_SetText("t1_upp",  "---- mV");
    HAL_Delay(50);
    HMI_SetText("t1_urms", "---- mV");
    HAL_Delay(50);
    HMI_SetText("t1_fa1",  "---- Hz");
    HAL_Delay(50);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
    while (1)
    {
        /* ---- 等待采集开关 ---- */
        if (!capture_on)
        {
            HAL_Delay(50);
            continue;
        }

        /* ---- 启动DMA采样 ---- */
        AD9226_StartSampling();

        /* ---- 等待DMA完成 (1秒超时) ---- */
        uint32_t timeout = HAL_GetTick();
        while (!dma_complete_flag)
        {
            if (!capture_on) { AD9226_StopSampling(); break; }
            if (HAL_GetTick() - timeout > 1000)
            {
                AD9226_StopSampling();
                break;
            }
        }

        /* ---- 发送波形数据（hzoom控制步长，scale控制幅度）---- */
        if (dma_complete_flag && capture_on)
        {
            /* X按键调整真实时间窗口，g_hzoom变量本身不设上下限 */
            uint32_t window_samples = ADC_SAMPLE_LEN - 4U;
            int64_t zoom_in = (int64_t)HZOOM_FULL_WINDOW_LEVEL - (int64_t)g_hzoom;
            while ((zoom_in > 0) && (window_samples > 2U))
            {
                window_samples = (window_samples + 1U) / 2U;
                zoom_in--;
            }
            int scale_level = g_scale;

            /* 4抽头FIR滤波：环形边界，首尾无缝无尖峰 */
            for (uint32_t i = 0; i < ADC_SAMPLE_LEN; i++)
            {
                uint32_t i0 = i, i1 = (i >= 1) ? i-1 : ADC_SAMPLE_LEN-1;
                uint32_t i2 = (i >= 2) ? i-2 : ADC_SAMPLE_LEN-2+i;
                uint32_t i3 = (i >= 3) ? i-3 : ADC_SAMPLE_LEN-3+i;
                uint32_t s  = (adc_buffer[i0] & ADC_DATA_MASK)
                            + (adc_buffer[i1] & ADC_DATA_MASK)
                            + (adc_buffer[i2] & ADC_DATA_MASK)
                            + (adc_buffer[i3] & ADC_DATA_MASK);
                fir_buf[i] = (uint16_t)(s / 4);
            }

            /* 每帧独立显示，避免不同采样相位之间被连成尖峰 */
            HMI_ClearWave(WAVE_CTRL, 0);

            for (uint32_t point = 0; point < DISPLAY_POINT_COUNT; point++)
            {
                if (!capture_on) break;

                /* 将当前时间窗口等间隔重采样为固定512个屏幕点 */
                uint64_t pos_num = (uint64_t)point * (window_samples - 1U);
                uint32_t idx0 = 4U + (uint32_t)(pos_num / (DISPLAY_POINT_COUNT - 1U));
                uint32_t frac = (uint32_t)(pos_num % (DISPLAY_POINT_COUNT - 1U));
                uint32_t idx1 = (idx0 + 1U < 4U + window_samples) ? idx0 + 1U : idx0;
                uint32_t raw0 = fir_buf[idx0] & ADC_DATA_MASK;
                uint32_t raw1 = fir_buf[idx1] & ADC_DATA_MASK;
                int32_t raw = (int32_t)((raw0 * (DISPLAY_POINT_COUNT - 1U - frac)
                              + raw1 * frac + (DISPLAY_POINT_COUNT / 2U))
                              / (DISPLAY_POINT_COUNT - 1U));
                /* Y: 以2048为中心反相，补偿模拟采集链极性，使波形恢复正向 */
                int64_t scaled = (int64_t)(2048 - raw) * 6;
                if (scale_level >= 1)
                {
                    scaled *= scale_level;
                }
                else
                {
                    int64_t div_count = 1 - (int64_t)scale_level;
                    while ((div_count > 0) && (scaled != 0))
                    {
                        scaled /= 2;
                        div_count--;
                    }
                }
                int64_t amp64 = scaled + 2048;
                int32_t amp;
                if      (amp64 <    0) amp =    0;
                else if (amp64 > 4095) amp = 4095;
                else                   amp = (int32_t)amp64;
                uint8_t val = (uint8_t)(amp >> 4);

                char buf[40];
                snprintf(buf, sizeof(buf), "add %s,0,%d", WAVE_CTRL, val);
                HMI_SendRaw(buf);

                HAL_Delay(POINT_INTERVAL_MS);
            }
        }
    }
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/**
 * @brief USART1 接收中断回调 (HAL库自动调用)
 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1)
    {
        HMI_RxHandler(rx_byte);
        HAL_UART_Receive_IT(&huart1, &rx_byte, 1);  // 重新开启接收
    }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
