#ifndef __HMI_H
#define __HMI_H

#include "usart.h"
#include "string.h"
#include "stdio.h"

extern UART_HandleTypeDef huart1;

/**
 * @brief 发送原始字符串指令 + 0xFF 0xFF 0xFF 结束符（淘晶驰协议）
 */
void HMI_SendRaw(const char *str);

/**
 * @brief 设置文本控件内容，格式: obj.txt="text" + FFFFFF
 */
void HMI_SetText(const char *obj, const char *text);

/**
 * @brief 往波形控件追加一个数据点，格式: add obj,ch,val + FFFFFF
 * @param wave 波形控件名称，如 "t1_wave"
 * @param ch   通道号（0起始）
 * @param val  数值 0~255
 */
void HMI_AddWave(const char *wave, uint8_t ch, uint8_t val);

/**
 * @brief 清除波形控件指定通道
 * @param wave 波形控件名称，如 "t1_wave"
 * @param ch   通道号（0起始）
 */
void HMI_ClearWave(const char *wave, uint8_t ch);

/**
 * @brief 切换页面
 */
void HMI_Page(const char *page);

#endif /* __HMI_H */
